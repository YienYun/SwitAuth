"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";

/**
 * Account dropdown menu — ported 1:1 from the decompiled workspace header
 * (chunk 3k6a5lhrkscp5.js, component rU). The DOM contract below mirrors the
 * original Radix markup so the extracted `account-menu-module__u2BZwG__*`
 * styles in dash-b.css render untouched (menu width 304px, identity block,
 * "Current plan" row, separator, "Open profile" + "Log out" items with the
 * user-round / log-out icons, red logout highlight via [data-highlighted]).
 */

const EMAIL = "baderialailatul491@gmail.com"; // captured account email (Profile → Account details)

export default function AccountMenu({
  anchor,
  onClose,
  onNavigate,
  onLogout,
}: {
  anchor: HTMLElement;
  onClose: () => void;
  onNavigate: (view: "profile") => void;
  onLogout: () => void;
}) {
  const menuRef = useRef<HTMLDivElement | null>(null);
  const [pos, setPos] = useState<{ top: number; right: number } | null>(null);

  // Position the menu below the trigger, aligned to its right edge (the
  // original used Radix align="end" with collisionPadding 12).
  useLayoutEffect(() => {
    const place = () => {
      const r = anchor.getBoundingClientRect();
      const top = Math.min(r.bottom + 8, window.innerHeight - 12);
      setPos({
        top,
        right: Math.max(12, window.innerWidth - r.right - 0),
      });
    };
    place();
    window.addEventListener("resize", place);
    return () => window.removeEventListener("resize", place);
  }, [anchor]);

  // Outside click + Escape close, arrow-key item navigation (Radix parity).
  useEffect(() => {
    const items = () =>
      Array.from(
        menuRef.current?.querySelectorAll<HTMLElement>('[role="menuitem"]') ?? [],
      );
    const highlight = (el: HTMLElement | null) => {
      items().forEach((it) =>
        it.toggleAttribute("data-highlighted", it === el),
      );
      el?.focus();
    };
    const onPointerOver = (event: Event) => {
      const item = (event.target as HTMLElement | null)?.closest<HTMLElement>(
        '[role="menuitem"]',
      );
      if (item && menuRef.current?.contains(item)) highlight(item);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.stopPropagation();
        event.preventDefault();
        onClose();
        return;
      }
      if (!menuRef.current?.contains(event.target as Node)) return;
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        const list = items();
        if (!list.length) return;
        const current = list.indexOf(
          document.activeElement as HTMLElement,
        );
        const next =
          event.key === "ArrowDown"
            ? list[(current + 1) % list.length]
            : list[(current - 1 + list.length) % list.length];
        highlight(next);
      }
    };
    const onPointerDown = (event: PointerEvent) => {
      const target = event.target as HTMLElement | null;
      if (
        menuRef.current &&
        !menuRef.current.contains(target) &&
        !anchor.contains(target)
      ) {
        onClose();
      }
    };
    window.addEventListener("keydown", onKeyDown, true);
    window.addEventListener("pointerdown", onPointerDown, true);
    menuRef.current?.addEventListener("pointerover", onPointerOver);
    return () => {
      window.removeEventListener("keydown", onKeyDown, true);
      window.removeEventListener("pointerdown", onPointerDown, true);
      menuRef.current?.removeEventListener("pointerover", onPointerOver);
    };
  }, [anchor, onClose]);

  const focusFirst = (el: HTMLButtonElement | null) => {
    if (el && !el.dataset.autofocused) {
      el.dataset.autofocused = "1";
      el.focus();
    }
  };

  return (
    <div
      ref={menuRef}
      className="account-menu-module__u2BZwG__menu"
      data-slot="dropdown-menu-content"
      data-state="open"
      role="menu"
      aria-label="Account"
      style={
        {
          position: "fixed",
          top: pos?.top ?? -9999,
          right: pos?.right ?? -9999,
          zIndex: 10060,
          "--radix-dropdown-menu-content-transform-origin": "top right",
        } as React.CSSProperties
      }
    >
      <div className="account-menu-module__u2BZwG__identity">
        <span className="account-menu-module__u2BZwG__avatar fa-avatar" title="Zed">
          <span
            className="fa-avatar-fallback"
            style={{
              background: "linear-gradient(135deg, rgb(68, 95, 17), rgb(9, 62, 10))",
              color: "rgb(203, 248, 119)",
              borderRadius: "inherit",
            }}
          >
            Z
          </span>
        </span>
        <div className="account-menu-module__u2BZwG__identityText">
          <strong className="account-menu-module__u2BZwG__email">{EMAIL}</strong>
          <span className="account-menu-module__u2BZwG__role">User account</span>
        </div>
      </div>
      <div className="account-menu-module__u2BZwG__plan">
        <span>Current plan</span>
        <span className="account-menu-module__u2BZwG__planBadge">Free</span>
      </div>
      <div className="account-menu-module__u2BZwG__separator" role="separator" />
      <button
        type="button"
        role="menuitem"
        className="account-menu-module__u2BZwG__item"
        data-slot="dropdown-menu-item"
        ref={focusFirst}
        onClick={() => {
          onClose();
          onNavigate("profile");
        }}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="8" r="5" />
          <path d="M20 21a8 8 0 0 0-16 0" />
        </svg>
        <span>Open profile</span>
      </button>
      <button
        type="button"
        role="menuitem"
        className={`account-menu-module__u2BZwG__item account-menu-module__u2BZwG__logout`}
        data-slot="dropdown-menu-item"
        onClick={onLogout}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
          <path d="m16 17 5-5-5-5" />
          <path d="M21 12H9" />
          <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
        </svg>
        <span>Log out</span>
      </button>
    </div>
  );
}
