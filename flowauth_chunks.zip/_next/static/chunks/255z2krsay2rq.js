(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,96101,e=>{e.v({authCard:"auth-theme-module__peW5UW__authCard",authSurface:"auth-theme-module__peW5UW__authSurface",backHome:"auth-theme-module__peW5UW__backHome",subscriptionOption:"auth-theme-module__peW5UW__subscriptionOption"})},30808,e=>{"use strict";var t=e.i(43476),a=e.i(71645),i=e.i(74776),r=e.i(25404),o=e.i(27702);function n({entry:e,onClose:a,busy:l=!1,error:s="",preview:c=!1}){return(0,t.jsx)(i.Modal,{open:!!e,onClose:a,title:e?.title||"What's new",eyebrow:c?"Change log preview":"What's new in FlowAuth",footer:(0,t.jsx)(r.FlowButton,{onClick:a,disabled:l,children:l?"Saving…":c?"Close preview":"Got it"}),children:(0,t.jsxs)("div",{className:o.default.popup,children:[e&&(0,t.jsx)("p",{className:o.default.date,children:new Date(e.created_at).toLocaleDateString(void 0,{year:"numeric",month:"long",day:"numeric"})}),(0,t.jsx)("div",{className:o.default.body,children:e?.body}),s&&(0,t.jsx)("p",{role:"alert",className:o.default.error,children:s}),!c&&(0,t.jsx)("p",{className:o.default.hint,children:"Dismiss once. This update won't appear again on your account."})]})})}e.s(["ChangelogDialog",0,n,"ChangelogPopup",0,function({apiFetch:e}){let[i,r]=(0,a.useState)(null),[o,l]=(0,a.useState)(!1),[s,c]=(0,a.useState)(""),d=(0,a.useRef)(!1),u=(0,a.useRef)(new Set),h=(0,a.useRef)(0);async function _(){if(i&&!d.current){d.current=!0,++h.current,l(!0),c("");try{await e(`/v1/changelog/${i.id}/dismiss`,{method:"POST"}),u.current.add(i.id),r(null)}catch{c("Could not save your dismissal. Please try again.")}finally{d.current=!1,l(!1)}}}return(0,a.useEffect)(()=>{let t=!0,a=async()=>{if("hidden"===document.visibilityState||d.current)return;let a=++h.current;try{let i=await e("/v1/changelog");if(!t||a!==h.current)return;let o=i.changelog;if(!o||u.current.has(o.id))return void r(null);document.querySelector('[role="dialog"], [role="alertdialog"]')||r(o)}catch{}};a();let i=window.setInterval(()=>void a(),3e4);return window.addEventListener("focus",a),window.addEventListener("flowauth-changelog-updated",a),()=>{t=!1,window.clearInterval(i),window.removeEventListener("focus",a),window.removeEventListener("flowauth-changelog-updated",a)}},[e]),(0,t.jsx)(n,{entry:i,onClose:()=>void _(),busy:o,error:s})}])},27702,e=>{e.v({actions:"changelog-module__KC6Kha__actions",body:"changelog-module__KC6Kha__body",date:"changelog-module__KC6Kha__date",error:"changelog-module__KC6Kha__error",hint:"changelog-module__KC6Kha__hint",history:"changelog-module__KC6Kha__history",popup:"changelog-module__KC6Kha__popup"})},74086,e=>{e.v({action:"empty-state-module__V6nUrW__action",body:"empty-state-module__V6nUrW__body",desc:"empty-state-module__V6nUrW__desc",esIn:"empty-state-module__V6nUrW__esIn",mark:"empty-state-module__V6nUrW__mark",root:"empty-state-module__V6nUrW__root",title:"empty-state-module__V6nUrW__title"})},58138,e=>{e.v({card:"stat-card-module__7cOruW__card",label:"stat-card-module__7cOruW__label",mark:"stat-card-module__7cOruW__mark",rule:"stat-card-module__7cOruW__rule",scRule:"stat-card-module__7cOruW__scRule",sub:"stat-card-module__7cOruW__sub",value:"stat-card-module__7cOruW__value"})},72286,e=>{"use strict";var t=e.i(43476),a=e.i(25404);e.i(71645),e.i(73812);var i=e.i(74086);e.i(58138),e.s(["EnhancedEmptyState",0,function({icon:e,title:r,description:o,actionLabel:n="",onAction:l,delay:s=0}){return(0,t.jsx)("div",{className:`enhancedEmptyState ${i.default.root}`,children:(0,t.jsxs)("div",{className:i.default.body,children:[e?(0,t.jsx)("span",{className:i.default.mark,children:(0,t.jsx)(e,{size:21,strokeWidth:1.8})}):null,(0,t.jsx)("h3",{className:i.default.title,children:r}),o?(0,t.jsx)("p",{className:i.default.desc,children:o}):null,n?(0,t.jsx)("div",{className:i.default.action,children:(0,t.jsx)(a.FlowButton,{className:"enhancedEmptyAction",type:"button",onClick:l,children:n})}):null]})})}],72286)},29641,e=>{"use strict";var t=e.i(43476),a=e.i(71645),i=e.i(29372);e.s(["Checkbox",0,function({label:e,description:r,className:o,id:n,checked:l,defaultChecked:s,disabled:c,onChange:d,...u}){let[h]=(0,a.useState)(()=>n??(0,i.uid)("check"));return(0,t.jsxs)("label",{className:(0,i.cx)("fa-check",c&&"fa-check-disabled",o),htmlFor:h,children:[(0,t.jsx)("input",{id:h,type:"checkbox",className:"fa-check-input",checked:l,defaultChecked:s,disabled:c,onChange:e=>d?.(e.target.checked),...u}),(0,t.jsxs)("span",{className:"fa-check-box","aria-hidden":!0,children:[(0,t.jsx)("span",{className:"fa-check-burst"}),(0,t.jsx)("svg",{viewBox:"0 0 24 24",className:"fa-check-mark",fill:"none",stroke:"currentColor",strokeWidth:"3.2",strokeLinecap:"round",strokeLinejoin:"round",children:(0,t.jsx)("path",{d:"m5 12.8 4.6 4.6L19 7"})})]}),(e||r)&&(0,t.jsxs)("span",{className:"fa-check-text",children:[e&&(0,t.jsx)("span",{className:"fa-check-label",children:e}),r&&(0,t.jsx)("span",{className:"fa-check-desc",children:r})]})]})}])},69922,e=>{"use strict";var t=e.i(43476),a=e.i(29372);e.s(["EmptyState",0,function({icon:e,title:i,description:r,action:o,className:n}){return(0,t.jsxs)("div",{className:(0,a.cx)("fa-empty",n),children:[e&&(0,t.jsxs)("div",{className:"fa-empty-orb",children:[(0,t.jsx)("span",{className:"fa-empty-ring","aria-hidden":!0}),(0,t.jsx)("span",{className:"fa-empty-icon",children:e})]}),(0,t.jsx)("h4",{className:"fa-empty-title",children:i}),r&&(0,t.jsx)("p",{className:"fa-empty-desc",children:r}),o&&(0,t.jsx)("div",{className:"fa-empty-action",children:o})]})}])},83169,e=>{"use strict";var t=e.i(43476),a=e.i(71645),i=e.i(29372);e.s(["Input",0,function({label:e,icon:r,error:o,success:n=!1,hint:l,mono:s=!1,className:c,id:d,placeholder:u,...h}){let[_]=(0,a.useState)(()=>d??(0,i.uid)("input"));return(0,t.jsxs)("div",{className:(0,i.cx)("fa-field",!e&&"fa-field-unlabeled",r&&"fa-field-iconed",o&&"fa-field-error",n&&"fa-field-success",c),children:[(0,t.jsxs)("div",{className:"fa-field-frame",children:[r&&(0,t.jsx)("span",{className:"fa-field-icon",children:r}),(0,t.jsx)("input",{id:_,className:(0,i.cx)("fa-field-input",s&&"fa-mono"),placeholder:e?" ":u,"aria-invalid":!!o||void 0,...h}),e&&(0,t.jsx)("label",{className:"fa-field-label",htmlFor:_,children:e}),(0,t.jsx)("span",{className:"fa-field-charge","aria-hidden":!0})]}),(o||l)&&(0,t.jsx)("span",{className:(0,i.cx)("fa-field-msg",o&&"fa-field-msg-error"),children:o??l})]})},"TextArea",0,function({label:e,error:r,hint:o,mono:n=!1,className:l,id:s,placeholder:c,rows:d=4,...u}){let[h]=(0,a.useState)(()=>s??(0,i.uid)("textarea"));return(0,t.jsxs)("div",{className:(0,i.cx)("fa-field","fa-field-area",!e&&"fa-field-unlabeled",r&&"fa-field-error",l),children:[(0,t.jsxs)("div",{className:"fa-field-frame",children:[(0,t.jsx)("textarea",{id:h,className:(0,i.cx)("fa-field-input",n&&"fa-mono"),placeholder:e?" ":c,rows:d,"aria-invalid":!!r||void 0,...u}),e&&(0,t.jsx)("label",{className:"fa-field-label",htmlFor:h,children:e}),(0,t.jsx)("span",{className:"fa-field-charge","aria-hidden":!0})]}),(r||o)&&(0,t.jsx)("span",{className:(0,i.cx)("fa-field-msg",r&&"fa-field-msg-error"),children:r??o})]})}])},42673,e=>{"use strict";var t=e.i(43476),a=e.i(71645),i=e.i(29372);e.s(["SegmentedControl",0,function({options:e,value:r,defaultValue:o,onChange:n,size:l="md",className:s,ariaLabel:c="Choose an option","aria-label":d,"aria-labelledby":u}){let[h,_]=(0,a.useState)(o??e[0]?.value??""),f=(0,a.useRef)([]),m=void 0!==r?r:h,p=e.findIndex(e=>e.value===m),g=e.findIndex(e=>!e.disabled),v=p>=0&&!e[p]?.disabled?p:g,x=p>=0?p:Math.max(0,g),y=e=>{void 0===r&&_(e),n?.(e)};return(0,t.jsxs)("div",{className:(0,i.cx)("fa-seg",`fa-seg-${l}`,s),role:"radiogroup","aria-label":d||c,"aria-labelledby":u,style:{"--fa-seg-count":e.length,"--fa-seg-index":x},children:[(0,t.jsx)("span",{className:"fa-seg-indicator","aria-hidden":!0}),e.map((a,r)=>(0,t.jsxs)("button",{ref:e=>{f.current[r]=e},type:"button",role:"radio","aria-checked":m===a.value,tabIndex:r===v?0:-1,disabled:a.disabled,className:(0,i.cx)("fa-seg-item",m===a.value&&"fa-seg-active"),onClick:()=>y(a.value),onKeyDown:t=>((t,a)=>{let i,r=e.map((e,t)=>({option:e,optionIndex:t})).filter(({option:e})=>!e.disabled);if(0===r.length)return;let o=r.findIndex(({optionIndex:e})=>e===a);if("Home"===t.key)i=r[0];else if("End"===t.key)i=r[r.length-1];else if("ArrowRight"===t.key||"ArrowDown"===t.key)i=r[(Math.max(o,-1)+1)%r.length];else{if("ArrowLeft"!==t.key&&"ArrowUp"!==t.key)return;i=o<0?r[r.length-1]:r[(o-1+r.length)%r.length]}t.preventDefault(),y(i.option.value),f.current[i.optionIndex]?.focus()})(t,r),children:[a.icon&&(0,t.jsx)("span",{className:"fa-seg-icon",children:a.icon}),a.label]},a.value))]})}])},56623,e=>{e.v({cap:"toggle-module__BAu5xq__cap",input:"toggle-module__BAu5xq__input",root:"toggle-module__BAu5xq__root",text:"toggle-module__BAu5xq__text",thumb:"toggle-module__BAu5xq__thumb",track:"toggle-module__BAu5xq__track"})},7087,e=>{"use strict";var t=e.i(43476),a=e.i(71645),i=e.i(29372),r=e.i(56623);e.s(["Toggle",0,function({label:e,description:o,size:n="md",className:l,id:s,checked:c,defaultChecked:d,disabled:u,onChange:h,"aria-label":_,"aria-labelledby":f,"aria-describedby":m,...p}){let g=(0,a.useId)(),v=s??`toggle-${g}`,x=`${v}-label`,y=`${v}-description`;return(0,t.jsxs)("span",{className:(0,i.cx)("fa-toggle",r.default.root,u&&"fa-toggle-disabled",l),"data-toggle-size":n,"data-disabled":u||void 0,children:[(0,t.jsx)("input",{...p,id:v,type:"checkbox",role:"switch",className:(0,i.cx)("fa-toggle-input",r.default.input),checked:c,defaultChecked:d,disabled:u,onChange:e=>h?.(e.target.checked),"aria-label":_,"aria-labelledby":f??(!_&&e?x:void 0),"aria-describedby":[m,o?y:void 0].filter(Boolean).join(" ")||void 0}),(0,t.jsx)("span",{className:r.default.track,"data-toggle-track":!0,"aria-hidden":"true",children:(0,t.jsx)("span",{className:r.default.thumb,"data-toggle-thumb":!0,children:(0,t.jsx)("span",{className:r.default.cap})})}),(e||o)&&(0,t.jsxs)("span",{className:(0,i.cx)("fa-toggle-text",r.default.text),children:[e&&(0,t.jsx)("span",{id:x,className:"fa-toggle-label",children:e}),o&&(0,t.jsx)("span",{id:y,className:"fa-toggle-desc",children:o})]})]})}])},76194,e=>{"use strict";var t=e.i(43476),a=e.i(29372);e.s(["Tooltip",0,function({content:e,side:i="top",children:r,className:o}){return(0,t.jsxs)("span",{className:(0,a.cx)("fa-tip",o),children:[r,(0,t.jsxs)("span",{role:"tooltip",className:(0,a.cx)("fa-tip-bubble",`fa-tip-${i}`),children:[e,(0,t.jsx)("span",{className:"fa-tip-arrow","aria-hidden":!0})]})]})}])},40407,e=>{"use strict";var t=e.i(43476),a=e.i(71645);let i=["M23 37.5 Q23 18 42 18 L79 18 Q87 18 87 27.6 Q87 37.5 76 37.5 Z","M12.7 60.6 Q12.7 41.2 31.7 41.2 L67 41.2 Q74.7 41.2 74.7 50.8 Q74.7 60.6 64 60.6 Z","M23 64.6 L46.4 64.6 Q46.4 85.8 23 85.8 Z"];e.s(["FlowAuthMark",0,function({size:e=26,className:r,title:o}){let n=`fam${(0,a.useId)().replace(/:/g,"")}`;return(0,t.jsxs)("svg",{className:r,width:e,height:e,viewBox:"0 0 100 100",fill:"none",role:o?"img":"presentation","aria-hidden":o?void 0:"true","aria-label":o||void 0,children:[o?(0,t.jsx)("title",{children:o}):null,(0,t.jsx)("defs",{children:(0,t.jsxs)("linearGradient",{id:`${n}-f`,x1:"10",y1:"14",x2:"86",y2:"88",gradientUnits:"userSpaceOnUse",children:[(0,t.jsx)("stop",{offset:"0",stopColor:"#6E7BF0"}),(0,t.jsx)("stop",{offset:"0.36",stopColor:"#C9A8F2"}),(0,t.jsx)("stop",{offset:"1",stopColor:"#C44BE8"})]})}),(0,t.jsx)("g",{transform:"translate(0 2.2)",fill:"#3A2160",opacity:"0.28",children:i.map(e=>(0,t.jsx)("path",{d:e},e))}),(0,t.jsx)("g",{fill:`url(#${n}-f)`,children:i.map(e=>(0,t.jsx)("path",{d:e},e))})]})}])},52699,80178,e=>{"use strict";var t=e.i(43476),a=e.i(71645);let i=`#version 300 es
precision mediump float;

layout(location = 0) in vec4 a_position;

uniform vec2 u_resolution;
uniform float u_pixelRatio;
uniform float u_imageAspectRatio;
uniform float u_originX;
uniform float u_originY;
uniform float u_worldWidth;
uniform float u_worldHeight;
uniform float u_fit;
uniform float u_scale;
uniform float u_rotation;
uniform float u_offsetX;
uniform float u_offsetY;

out vec2 v_objectUV;
out vec2 v_objectBoxSize;
out vec2 v_responsiveUV;
out vec2 v_responsiveBoxGivenSize;
out vec2 v_patternUV;
out vec2 v_patternBoxSize;
out vec2 v_imageUV;

vec3 getBoxSize(float boxRatio, vec2 givenBoxSize) {
  vec2 box = vec2(0.);
  // fit = none
  box.x = boxRatio * min(givenBoxSize.x / boxRatio, givenBoxSize.y);
  float noFitBoxWidth = box.x;
  if (u_fit == 1.) { // fit = contain
    box.x = boxRatio * min(u_resolution.x / boxRatio, u_resolution.y);
  } else if (u_fit == 2.) { // fit = cover
    box.x = boxRatio * max(u_resolution.x / boxRatio, u_resolution.y);
  }
  box.y = box.x / boxRatio;
  return vec3(box, noFitBoxWidth);
}

void main() {
  gl_Position = a_position;

  vec2 uv = gl_Position.xy * .5;
  vec2 boxOrigin = vec2(.5 - u_originX, u_originY - .5);
  vec2 givenBoxSize = vec2(u_worldWidth, u_worldHeight);
  givenBoxSize = max(givenBoxSize, vec2(1.)) * u_pixelRatio;
  float r = u_rotation * 3.14159265358979323846 / 180.;
  mat2 graphicRotation = mat2(cos(r), sin(r), -sin(r), cos(r));
  vec2 graphicOffset = vec2(-u_offsetX, u_offsetY);


  // ===================================================

  float fixedRatio = 1.;
  vec2 fixedRatioBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );

  v_objectBoxSize = getBoxSize(fixedRatio, fixedRatioBoxGivenSize).xy;
  vec2 objectWorldScale = u_resolution.xy / v_objectBoxSize;

  v_objectUV = uv;
  v_objectUV *= objectWorldScale;
  v_objectUV += boxOrigin * (objectWorldScale - 1.);
  v_objectUV += graphicOffset;
  v_objectUV /= u_scale;
  v_objectUV = graphicRotation * v_objectUV;

  // ===================================================

  v_responsiveBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  float responsiveRatio = v_responsiveBoxGivenSize.x / v_responsiveBoxGivenSize.y;
  vec2 responsiveBoxSize = getBoxSize(responsiveRatio, v_responsiveBoxGivenSize).xy;
  vec2 responsiveBoxScale = u_resolution.xy / responsiveBoxSize;

  #ifdef ADD_HELPERS
  v_responsiveHelperBox = uv;
  v_responsiveHelperBox *= responsiveBoxScale;
  v_responsiveHelperBox += boxOrigin * (responsiveBoxScale - 1.);
  #endif

  v_responsiveUV = uv;
  v_responsiveUV *= responsiveBoxScale;
  v_responsiveUV += boxOrigin * (responsiveBoxScale - 1.);
  v_responsiveUV += graphicOffset;
  v_responsiveUV /= u_scale;
  v_responsiveUV.x *= responsiveRatio;
  v_responsiveUV = graphicRotation * v_responsiveUV;
  v_responsiveUV.x /= responsiveRatio;

  // ===================================================

  float patternBoxRatio = givenBoxSize.x / givenBoxSize.y;
  vec2 patternBoxGivenSize = vec2(
  (u_worldWidth == 0.) ? u_resolution.x : givenBoxSize.x,
  (u_worldHeight == 0.) ? u_resolution.y : givenBoxSize.y
  );
  patternBoxRatio = patternBoxGivenSize.x / patternBoxGivenSize.y;

  vec3 boxSizeData = getBoxSize(patternBoxRatio, patternBoxGivenSize);
  v_patternBoxSize = boxSizeData.xy;
  float patternBoxNoFitBoxWidth = boxSizeData.z;
  vec2 patternBoxScale = u_resolution.xy / v_patternBoxSize;

  v_patternUV = uv;
  v_patternUV += graphicOffset / patternBoxScale;
  v_patternUV += boxOrigin;
  v_patternUV -= boxOrigin / patternBoxScale;
  v_patternUV *= u_resolution.xy;
  v_patternUV /= u_pixelRatio;
  if (u_fit > 0.) {
    v_patternUV *= (patternBoxNoFitBoxWidth / v_patternBoxSize.x);
  }
  v_patternUV /= u_scale;
  v_patternUV = graphicRotation * v_patternUV;
  v_patternUV += boxOrigin / patternBoxScale;
  v_patternUV -= boxOrigin;
  // x100 is a default multiplier between vertex and fragmant shaders
  // we use it to avoid UV presision issues
  v_patternUV *= .01;

  // ===================================================

  vec2 imageBoxSize;
  if (u_fit == 1.) { // contain
    imageBoxSize.x = min(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else if (u_fit == 2.) { // cover
    imageBoxSize.x = max(u_resolution.x / u_imageAspectRatio, u_resolution.y) * u_imageAspectRatio;
  } else {
    imageBoxSize.x = min(10.0, 10.0 / u_imageAspectRatio * u_imageAspectRatio);
  }
  imageBoxSize.y = imageBoxSize.x / u_imageAspectRatio;
  vec2 imageBoxScale = u_resolution.xy / imageBoxSize;

  v_imageUV = uv;
  v_imageUV *= imageBoxScale;
  v_imageUV += boxOrigin * (imageBoxScale - 1.);
  v_imageUV += graphicOffset;
  v_imageUV /= u_scale;
  v_imageUV.x *= u_imageAspectRatio;
  v_imageUV = graphicRotation * v_imageUV;
  v_imageUV.x /= u_imageAspectRatio;

  v_imageUV += .5;
  v_imageUV.y = 1. - v_imageUV.y;
}`,r=8294400;class o{parentElement;canvasElement;gl;program=null;uniformLocations={};fragmentShader;rafId=null;lastRenderTime=0;currentFrame=0;speed=0;currentSpeed=0;providedUniforms;mipmaps=[];hasBeenDisposed=!1;resolutionChanged=!0;textures=new Map;minPixelRatio;maxPixelCount;isSafari=(function(){let e=navigator.userAgent.toLowerCase();return e.includes("safari")&&!e.includes("chrome")&&!e.includes("android")})();uniformCache={};textureUnitMap=new Map;ownerDocument;constructor(e,t,a,i,o=0,n=0,s=2,c=r,d=[]){if(e?.nodeType===1)this.parentElement=e;else throw Error("Paper Shaders: parent element must be an HTMLElement");if(this.ownerDocument=e.ownerDocument,!this.ownerDocument.querySelector("style[data-paper-shader]")){const e=this.ownerDocument.createElement("style");e.innerHTML=l,e.setAttribute("data-paper-shader",""),this.ownerDocument.head.prepend(e)}const u=this.ownerDocument.createElement("canvas");this.canvasElement=u,this.parentElement.prepend(u),this.fragmentShader=t,this.providedUniforms=a,this.mipmaps=d,this.currentFrame=n,this.minPixelRatio=s,this.maxPixelCount=c;const h=u.getContext("webgl2",i);if(!h)throw Error("Paper Shaders: WebGL is not supported in this browser");this.gl=h,this.initProgram(),this.setupPositionAttribute(),this.setupUniforms(),this.setUniformValues(this.providedUniforms),this.setupResizeObserver(),visualViewport?.addEventListener("resize",this.handleVisualViewportChange),this.setSpeed(o),this.parentElement.setAttribute("data-paper-shader",""),this.parentElement.paperShaderMount=this,this.ownerDocument.addEventListener("visibilitychange",this.handleDocumentVisibilityChange)}initProgram=()=>{let e=function(e,t,a){let i=e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT),r=i?i.precision:null;r&&r<23&&(t=t.replace(/precision\s+(lowp|mediump)\s+float;/g,"precision highp float;"),a=a.replace(/precision\s+(lowp|mediump)\s+float/g,"precision highp float").replace(/\b(uniform|varying|attribute)\s+(lowp|mediump)\s+(\w+)/g,"$1 highp $3"));let o=n(e,e.VERTEX_SHADER,t),l=n(e,e.FRAGMENT_SHADER,a);if(!o||!l)return null;let s=e.createProgram();return s?(e.attachShader(s,o),e.attachShader(s,l),e.linkProgram(s),e.getProgramParameter(s,e.LINK_STATUS))?(e.detachShader(s,o),e.detachShader(s,l),e.deleteShader(o),e.deleteShader(l),s):(console.error("Unable to initialize the shader program: "+e.getProgramInfoLog(s)),e.deleteProgram(s),e.deleteShader(o),e.deleteShader(l),null):null}(this.gl,i,this.fragmentShader);e&&(this.program=e)};setupPositionAttribute=()=>{let e=this.gl.getAttribLocation(this.program,"a_position"),t=this.gl.createBuffer();this.gl.bindBuffer(this.gl.ARRAY_BUFFER,t),this.gl.bufferData(this.gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),this.gl.STATIC_DRAW),this.gl.enableVertexAttribArray(e),this.gl.vertexAttribPointer(e,2,this.gl.FLOAT,!1,0,0)};setupUniforms=()=>{let e={u_time:this.gl.getUniformLocation(this.program,"u_time"),u_pixelRatio:this.gl.getUniformLocation(this.program,"u_pixelRatio"),u_resolution:this.gl.getUniformLocation(this.program,"u_resolution")};Object.entries(this.providedUniforms).forEach(([t,a])=>{if(e[t]=this.gl.getUniformLocation(this.program,t),a instanceof HTMLImageElement){let a=`${t}AspectRatio`;e[a]=this.gl.getUniformLocation(this.program,a)}}),this.uniformLocations=e};renderScale=1;parentWidth=0;parentHeight=0;parentDevicePixelWidth=0;parentDevicePixelHeight=0;devicePixelsSupported=!1;resizeObserver=null;setupResizeObserver=()=>{this.resizeObserver=new ResizeObserver(([e])=>{if(e?.borderBoxSize[0]){let t=e.devicePixelContentBoxSize?.[0];void 0!==t&&(this.devicePixelsSupported=!0,this.parentDevicePixelWidth=t.inlineSize,this.parentDevicePixelHeight=t.blockSize),this.parentWidth=e.borderBoxSize[0].inlineSize,this.parentHeight=e.borderBoxSize[0].blockSize}this.handleResize()}),this.resizeObserver.observe(this.parentElement)};handleVisualViewportChange=()=>{this.resizeObserver?.disconnect(),this.setupResizeObserver()};handleResize=()=>{let e=0,t=0,a=Math.max(1,window.devicePixelRatio),i=visualViewport?.scale??1;if(this.devicePixelsSupported){let r=Math.max(1,this.minPixelRatio/a);e=this.parentDevicePixelWidth*r*i,t=this.parentDevicePixelHeight*r*i}else{var r;let o,n,l=Math.max(a,this.minPixelRatio)*i;this.isSafari&&(l*=Math.max(1,(r=this.ownerDocument,(n=Math.round(100*(o=outerWidth/((visualViewport?.scale??1)*(visualViewport?.width??window.innerWidth)+(window.innerWidth-r.documentElement.clientWidth)))))%5==0?n/100:33===n?1/3:67===n?2/3:133===n?4/3:o))),e=Math.round(this.parentWidth)*l,t=Math.round(this.parentHeight)*l}let o=Math.min(1,Math.sqrt(this.maxPixelCount)/Math.sqrt(e*t)),n=Math.round(e*o),l=Math.round(t*o),s=n/Math.round(this.parentWidth);(this.canvasElement.width!==n||this.canvasElement.height!==l||this.renderScale!==s)&&(this.renderScale=s,this.canvasElement.width=n,this.canvasElement.height=l,this.resolutionChanged=!0,this.gl.viewport(0,0,this.gl.canvas.width,this.gl.canvas.height),this.render(performance.now()))};render=e=>{if(this.hasBeenDisposed)return;if(null===this.program)return void console.warn("Tried to render before program or gl was initialized");let t=e-this.lastRenderTime;this.lastRenderTime=e,0!==this.currentSpeed&&(this.currentFrame+=t*this.currentSpeed),this.gl.clear(this.gl.COLOR_BUFFER_BIT),this.gl.useProgram(this.program),this.gl.uniform1f(this.uniformLocations.u_time,.001*this.currentFrame),this.resolutionChanged&&(this.gl.uniform2f(this.uniformLocations.u_resolution,this.gl.canvas.width,this.gl.canvas.height),this.gl.uniform1f(this.uniformLocations.u_pixelRatio,this.renderScale),this.resolutionChanged=!1),this.gl.drawArrays(this.gl.TRIANGLES,0,6),0!==this.currentSpeed?this.requestRender():this.rafId=null};requestRender=()=>{null!==this.rafId&&cancelAnimationFrame(this.rafId),this.rafId=requestAnimationFrame(this.render)};setTextureUniform=(e,t)=>{if(!t.complete||0===t.naturalWidth)throw Error(`Paper Shaders: image for uniform ${e} must be fully loaded`);let a=this.textures.get(e);a&&this.gl.deleteTexture(a),this.textureUnitMap.has(e)||this.textureUnitMap.set(e,this.textureUnitMap.size);let i=this.textureUnitMap.get(e);this.gl.activeTexture(this.gl.TEXTURE0+i);let r=this.gl.createTexture();this.gl.bindTexture(this.gl.TEXTURE_2D,r),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_WRAP_S,this.gl.CLAMP_TO_EDGE),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_WRAP_T,this.gl.CLAMP_TO_EDGE),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MIN_FILTER,this.gl.LINEAR),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MAG_FILTER,this.gl.LINEAR),this.gl.texImage2D(this.gl.TEXTURE_2D,0,this.gl.RGBA,this.gl.RGBA,this.gl.UNSIGNED_BYTE,t),this.mipmaps.includes(e)&&(this.gl.generateMipmap(this.gl.TEXTURE_2D),this.gl.texParameteri(this.gl.TEXTURE_2D,this.gl.TEXTURE_MIN_FILTER,this.gl.LINEAR_MIPMAP_LINEAR));let o=this.gl.getError();if(o!==this.gl.NO_ERROR||null===r)return void console.error("Paper Shaders: WebGL error when uploading texture:",o);this.textures.set(e,r);let n=this.uniformLocations[e];if(n){this.gl.uniform1i(n,i);let a=`${e}AspectRatio`,r=this.uniformLocations[a];if(r){let e=t.naturalWidth/t.naturalHeight;this.gl.uniform1f(r,e)}}};areUniformValuesEqual=(e,t)=>e===t||!!(Array.isArray(e)&&Array.isArray(t))&&e.length===t.length&&e.every((e,a)=>this.areUniformValuesEqual(e,t[a]));setUniformValues=e=>{this.gl.useProgram(this.program),Object.entries(e).forEach(([e,t])=>{let a=t;if(t instanceof HTMLImageElement&&(a=`${t.src.slice(0,200)}|${t.naturalWidth}x${t.naturalHeight}`),this.areUniformValuesEqual(this.uniformCache[e],a))return;this.uniformCache[e]=a;let i=this.uniformLocations[e];if(!i)return void console.warn(`Uniform location for ${e} not found`);if(t instanceof HTMLImageElement)this.setTextureUniform(e,t);else if(Array.isArray(t)){let a=null,r=null;if(void 0!==t[0]&&Array.isArray(t[0])){let i=t[0].length;if(!t.every(e=>e.length===i))return void console.warn(`All child arrays must be the same length for ${e}`);a=t.flat(),r=i}else r=(a=t).length;switch(r){case 2:this.gl.uniform2fv(i,a);break;case 3:this.gl.uniform3fv(i,a);break;case 4:this.gl.uniform4fv(i,a);break;case 9:this.gl.uniformMatrix3fv(i,!1,a);break;case 16:this.gl.uniformMatrix4fv(i,!1,a);break;default:console.warn(`Unsupported uniform array length: ${r}`)}}else"number"==typeof t?this.gl.uniform1f(i,t):"boolean"==typeof t?this.gl.uniform1i(i,+!!t):console.warn(`Unsupported uniform type for ${e}: ${typeof t}`)})};getCurrentFrame=()=>this.currentFrame;setFrame=e=>{this.currentFrame=e,this.lastRenderTime=performance.now(),this.render(performance.now())};setSpeed=(e=1)=>{this.speed=e,this.setCurrentSpeed(this.ownerDocument.hidden?0:e)};setCurrentSpeed=e=>{this.currentSpeed=e,null===this.rafId&&0!==e&&(this.lastRenderTime=performance.now(),this.rafId=requestAnimationFrame(this.render)),null!==this.rafId&&0===e&&(cancelAnimationFrame(this.rafId),this.rafId=null)};setMaxPixelCount=(e=r)=>{this.maxPixelCount=e,this.handleResize()};setMinPixelRatio=(e=2)=>{this.minPixelRatio=e,this.handleResize()};setUniforms=e=>{this.setUniformValues(e),this.providedUniforms={...this.providedUniforms,...e},this.render(performance.now())};handleDocumentVisibilityChange=()=>{this.setCurrentSpeed(this.ownerDocument.hidden?0:this.speed)};dispose=()=>{this.hasBeenDisposed=!0,null!==this.rafId&&(cancelAnimationFrame(this.rafId),this.rafId=null),this.gl&&this.program&&(this.textures.forEach(e=>{this.gl.deleteTexture(e)}),this.textures.clear(),this.gl.deleteProgram(this.program),this.program=null,this.gl.bindBuffer(this.gl.ARRAY_BUFFER,null),this.gl.bindBuffer(this.gl.ELEMENT_ARRAY_BUFFER,null),this.gl.bindRenderbuffer(this.gl.RENDERBUFFER,null),this.gl.bindFramebuffer(this.gl.FRAMEBUFFER,null),this.gl.getError()),this.resizeObserver&&(this.resizeObserver.disconnect(),this.resizeObserver=null),visualViewport?.removeEventListener("resize",this.handleVisualViewportChange),this.ownerDocument.removeEventListener("visibilitychange",this.handleDocumentVisibilityChange),this.uniformLocations={},this.canvasElement.remove(),delete this.parentElement.paperShaderMount}}function n(e,t,a){let i=e.createShader(t);return i?(e.shaderSource(i,a),e.compileShader(i),e.getShaderParameter(i,e.COMPILE_STATUS))?i:(console.error("An error occurred compiling the shaders: "+e.getShaderInfoLog(i)),e.deleteShader(i),null):null}let l=`@layer paper-shaders {
  :where([data-paper-shader]) {
    isolation: isolate;
    position: relative;

    & canvas {
      contain: strict;
      display: block;
      position: absolute;
      inset: 0;
      z-index: -1;
      width: 100%;
      height: 100%;
      border-radius: inherit;
      corner-shape: inherit;
    }
  }
}`;function s(e){if(e.naturalWidth<1024&&e.naturalHeight<1024){if(e.naturalWidth<1||e.naturalHeight<1)return;let t=e.naturalWidth/e.naturalHeight;e.width=Math.round(t>1?1024*t:1024),e.height=Math.round(t>1?1024:1024/t)}}async function c(e){let t={},a=[];return Object.entries(e).forEach(([e,i])=>{if("string"==typeof i){let r=i||"data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==";if(!(e=>{try{if(e.startsWith("/"))return!0;return new URL(e),!0}catch{return!1}})(r))return void console.warn(`Uniform "${e}" has invalid URL "${r}". Skipping image loading.`);let o=new Promise((a,i)=>{let o=new Image;(e=>{try{if(e.startsWith("/"))return!1;return new URL(e,window.location.origin).origin!==window.location.origin}catch{return!1}})(r)&&(o.crossOrigin="anonymous"),o.onload=()=>{s(o),t[e]=o,a()},o.onerror=()=>{console.error(`Could not set uniforms. Failed to load image at ${r}`),i()},o.src=r});a.push(o)}else i instanceof HTMLImageElement&&s(i),t[e]=i}),await Promise.all(a),t}let d=(0,a.forwardRef)(function({fragmentShader:e,uniforms:i,webGlContextAttributes:r,speed:n=0,frame:l=0,width:s,height:d,minPixelRatio:u,maxPixelCount:h,mipmaps:_,style:f,...m},p){var g;let v,x,[y,b]=(0,a.useState)(!1),w=(0,a.useRef)(null),S=(0,a.useRef)(null),k=(0,a.useRef)(r);(0,a.useEffect)(()=>((async()=>{let t=await c(i);w.current&&!S.current&&(S.current=new o(w.current,e,t,k.current,n,l,u,h,_),b(!0))})(),()=>{S.current?.dispose(),S.current=null}),[e]),(0,a.useEffect)(()=>{let e=!1;return(async()=>{let t=await c(i);e||S.current?.setUniforms(t)})(),()=>{e=!0}},[i,y]),(0,a.useEffect)(()=>{S.current?.setSpeed(n)},[n,y]),(0,a.useEffect)(()=>{S.current?.setMaxPixelCount(h)},[h,y]),(0,a.useEffect)(()=>{S.current?.setMinPixelRatio(u)},[u,y]),(0,a.useEffect)(()=>{S.current?.setFrame(l)},[l,y]);let I=(g=[w,p],v=a.useRef(void 0),x=a.useCallback(e=>{let t=g.map(t=>{if(null!=t){if("function"==typeof t){let a=t(e);return"function"==typeof a?a:()=>{t(null)}}return t.current=e,()=>{t.current=null}}});return()=>{t.forEach(e=>e?.())}},g),a.useMemo(()=>g.every(e=>null==e)?null:e=>{v.current&&(v.current(),v.current=void 0),null!=e&&(v.current=x(e))},g));return(0,t.jsx)("div",{ref:I,style:void 0!==s||void 0!==d?{width:"string"==typeof s&&!1===isNaN(+s)?+s:s,height:"string"==typeof d&&!1===isNaN(+d)?+d:d,...f}:f,...m})});d.displayName="ShaderMount";let u={fit:"contain",scale:1,rotation:0,offsetX:0,offsetY:0,originX:.5,originY:.5,worldWidth:0,worldHeight:0},h={none:0,contain:1,cover:2};function _(e){if(Array.isArray(e))return 4===e.length?e:3===e.length?[...e,1]:m;if("string"!=typeof e)return m;let t,a,i,r=1;if(e.startsWith("#")){var o;[t,a,i,r]=(3===(o=(o=e).replace(/^#/,"")).length&&(o=o.split("").map(e=>e+e).join("")),6===o.length&&(o+="ff"),[parseInt(o.slice(0,2),16)/255,parseInt(o.slice(2,4),16)/255,parseInt(o.slice(4,6),16)/255,parseInt(o.slice(6,8),16)/255])}else if(e.startsWith("rgb")){let o;[t,a,i,r]=(o=e.match(/^rgba?\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([0-9.]+))?\s*\)$/i))?[parseInt(o[1]??"0")/255,parseInt(o[2]??"0")/255,parseInt(o[3]??"0")/255,void 0===o[4]?1:parseFloat(o[4])]:[0,0,0,1]}else{let o;if(!e.startsWith("hsl"))return console.error("Unsupported color format",e),m;[t,a,i,r]=function(e){let t,a,i,[r,o,n,l]=e,s=r/360,c=o/100,d=n/100;if(0===o)t=a=i=d;else{let e=(e,t,a)=>(a<0&&(a+=1),a>1&&(a-=1),a<1/6)?e+(t-e)*6*a:a<.5?t:a<2/3?e+(t-e)*(2/3-a)*6:e,r=d<.5?d*(1+c):d+c-d*c,o=2*d-r;t=e(o,r,s+1/3),a=e(o,r,s),i=e(o,r,s-1/3)}return[t,a,i,l]}((o=e.match(/^hsla?\s*\(\s*(\d+)\s*,\s*(\d+)%\s*,\s*(\d+)%\s*(?:,\s*([0-9.]+))?\s*\)$/i))?[parseInt(o[1]??"0"),parseInt(o[2]??"0"),parseInt(o[3]??"0"),void 0===o[4]?1:parseFloat(o[4])]:[0,0,0,1])}return[f(t,0,1),f(a,0,1),f(i,0,1),f(r,0,1)]}let f=(e,t,a)=>Math.min(Math.max(e,t),a),m=[0,0,0,1],p=`
#define TWO_PI 6.28318530718
#define PI 3.14159265358979323846
`,g=`
vec2 rotate(vec2 uv, float th) {
  return mat2(cos(th), sin(th), -sin(th), cos(th)) * uv;
}
`,v=`
  float hash21(vec2 p) {
    p = fract(p * vec2(0.3183099, 0.3678794)) + 0.1;
    p += dot(p, p + 19.19);
    return fract(p.x * p.y);
  }
`,x=`#version 300 es
precision mediump float;

uniform float u_time;

uniform vec4 u_colors[10];
uniform float u_colorsCount;

uniform float u_distortion;
uniform float u_swirl;
uniform float u_grainMixer;
uniform float u_grainOverlay;

in vec2 v_objectUV;
out vec4 fragColor;

${p}
${g}
${v}

float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  float x1 = mix(a, b, u.x);
  float x2 = mix(c, d, u.x);
  return mix(x1, x2, u.y);
}

float noise(vec2 n, vec2 seedOffset) {
  return valueNoise(n + seedOffset);
}

vec2 getPosition(int i, float t) {
  float a = float(i) * .37;
  float b = .6 + fract(float(i) / 3.) * .9;
  float c = .8 + fract(float(i + 1) / 4.);

  float x = sin(t * b + a);
  float y = cos(t * c + a * 1.5);

  return .5 + .5 * vec2(x, y);
}

void main() {
  vec2 uv = v_objectUV;
  uv += .5;
  vec2 grainUV = uv * 1000.;

  float grain = noise(grainUV, vec2(0.));
  float mixerGrain = .4 * u_grainMixer * (grain - .5);

  const float firstFrameOffset = 41.5;
  float t = .5 * (u_time + firstFrameOffset);

  float radius = smoothstep(0., 1., length(uv - .5));
  float center = 1. - radius;
  for (float i = 1.; i <= 2.; i++) {
    uv.x += u_distortion * center / i * sin(t + i * .4 * smoothstep(.0, 1., uv.y)) * cos(.2 * t + i * 2.4 * smoothstep(.0, 1., uv.y));
    uv.y += u_distortion * center / i * cos(t + i * 2. * smoothstep(.0, 1., uv.x));
  }

  vec2 uvRotated = uv;
  uvRotated -= vec2(.5);
  float angle = 3. * u_swirl * radius;
  uvRotated = rotate(uvRotated, -angle);
  uvRotated += vec2(.5);

  vec3 color = vec3(0.);
  float opacity = 0.;
  float totalWeight = 0.;

  for (int i = 0; i < 10; i++) {
    if (i >= int(u_colorsCount)) break;

    vec2 pos = getPosition(i, t) + mixerGrain;
    vec3 colorFraction = u_colors[i].rgb * u_colors[i].a;
    float opacityFraction = u_colors[i].a;

    float dist = length(uvRotated - pos);

    dist = pow(dist, 3.5);
    float weight = 1. / (dist + 1e-3);
    color += colorFraction * weight;
    opacity += opacityFraction * weight;
    totalWeight += weight;
  }

  color /= max(1e-4, totalWeight);
  opacity /= max(1e-4, totalWeight);

  float grainOverlay = valueNoise(rotate(grainUV, 1.) + vec2(3.));
  grainOverlay = mix(grainOverlay, valueNoise(rotate(grainUV, 2.) + vec2(-1.)), .5);
  grainOverlay = pow(grainOverlay, 1.3);

  float grainOverlayV = grainOverlay * 2. - 1.;
  vec3 grainOverlayColor = vec3(step(0., grainOverlayV));
  float grainOverlayStrength = u_grainOverlay * abs(grainOverlayV);
  grainOverlayStrength = pow(grainOverlayStrength, .8);
  color = mix(color, grainOverlayColor, .35 * grainOverlayStrength);

  opacity += .5 * grainOverlayStrength;
  opacity = clamp(opacity, 0., 1.);

  fragColor = vec4(color, opacity);
}
`,y={name:"Default",params:{...u,speed:1,frame:0,colors:["#e0eaff","#241d9a","#f75092","#9f50d3"],distortion:.8,swirl:.1,grainMixer:0,grainOverlay:0}},b=(0,a.memo)(function({speed:e=y.params.speed,frame:a=y.params.frame,colors:i=y.params.colors,distortion:r=y.params.distortion,swirl:o=y.params.swirl,grainMixer:n=y.params.grainMixer,grainOverlay:l=y.params.grainOverlay,fit:s=y.params.fit,rotation:c=y.params.rotation,scale:u=y.params.scale,originX:f=y.params.originX,originY:m=y.params.originY,offsetX:p=y.params.offsetX,offsetY:g=y.params.offsetY,worldWidth:v=y.params.worldWidth,worldHeight:b=y.params.worldHeight,...w}){let S={u_colors:i.map(_),u_colorsCount:i.length,u_distortion:r,u_swirl:o,u_grainMixer:n,u_grainOverlay:l,u_fit:h[s],u_rotation:c,u_scale:u,u_offsetX:p,u_offsetY:g,u_originX:f,u_originY:m,u_worldWidth:v,u_worldHeight:b};return(0,t.jsx)(d,{...w,speed:e,frame:a,fragmentShader:x,uniforms:S})},function(e,t){for(let a in e){if("colors"===a){let a=Array.isArray(e.colors),i=Array.isArray(t.colors);if(!a||!i){if(!1===Object.is(e.colors,t.colors))return!1;continue}if(e.colors?.length!==t.colors?.length||!e.colors?.every((e,a)=>e===t.colors?.[a]))return!1;continue}if(!1===Object.is(e[a],t[a]))return!1}return!0});e.s(["MeshGradient",0,b],80178);var w=e.i(73444);let S=["#f7f4fc","#a7abf2","#c78ce8","#eadff7","#f3eefa"];e.s(["LandingBackdrop",0,function({animated:e=!0,className:i=""}={}){let[r,o]=(0,a.useState)(!1);return(0,a.useEffect)(()=>{let t=window.matchMedia?.("(prefers-reduced-motion: reduce)"),a=()=>{o(e&&"hidden"!==document.visibilityState&&!t?.matches)};return a(),document.addEventListener("visibilitychange",a),t?.addEventListener?.("change",a),()=>{document.removeEventListener("visibilitychange",a),t?.removeEventListener?.("change",a)}},[e]),(0,t.jsxs)("div",{className:`${w.default.backdrop} ${i}`,"aria-hidden":"true",children:[(0,t.jsx)(b,{className:w.default.backdropMesh,colors:S,distortion:.85,swirl:.6,grainOverlay:.04,speed:.16*!!r}),(0,t.jsx)("span",{className:w.default.backdropScrim}),(0,t.jsx)("span",{className:w.default.backdropFade})]})}],52699)},73444,e=>{e.v({backdrop:"landing-module__I_lyca__backdrop",backdropFade:"landing-module__I_lyca__backdropFade",backdropMesh:"landing-module__I_lyca__backdropMesh",backdropScrim:"landing-module__I_lyca__backdropScrim",brand:"landing-module__I_lyca__brand",btn:"landing-module__I_lyca__btn",btnBlock:"landing-module__I_lyca__btnBlock",btnGlass:"landing-module__I_lyca__btnGlass",btnQuiet:"landing-module__I_lyca__btnQuiet",card:"landing-module__I_lyca__card",cardIcon:"landing-module__I_lyca__cardIcon",cards:"landing-module__I_lyca__cards",cycle:"landing-module__I_lyca__cycle",cycleSave:"landing-module__I_lyca__cycleSave",cycleWrap:"landing-module__I_lyca__cycleWrap",d1:"landing-module__I_lyca__d1",d2:"landing-module__I_lyca__d2",d3:"landing-module__I_lyca__d3",d4:"landing-module__I_lyca__d4",d5:"landing-module__I_lyca__d5",enter:"landing-module__I_lyca__enter",execHead:"landing-module__I_lyca__execHead",execItem:"landing-module__I_lyca__execItem",execList:"landing-module__I_lyca__execList",execLogo:"landing-module__I_lyca__execLogo",execWrap:"landing-module__I_lyca__execWrap",faqAnswer:"landing-module__I_lyca__faqAnswer",faqGrid:"landing-module__I_lyca__faqGrid",faqItem:"landing-module__I_lyca__faqItem",faqSign:"landing-module__I_lyca__faqSign",footer:"landing-module__I_lyca__footer",footerBrand:"landing-module__I_lyca__footerBrand",footerCol:"landing-module__I_lyca__footerCol",footerGrid:"landing-module__I_lyca__footerGrid",footerLegal:"landing-module__I_lyca__footerLegal",footerLink:"landing-module__I_lyca__footerLink",footerSignoff:"landing-module__I_lyca__footerSignoff",footerTagline:"landing-module__I_lyca__footerTagline",footerWordmark:"landing-module__I_lyca__footerWordmark",freeNote:"landing-module__I_lyca__freeNote",header:"landing-module__I_lyca__header",headerActions:"landing-module__I_lyca__headerActions",headerInner:"landing-module__I_lyca__headerInner",headerScrolled:"landing-module__I_lyca__headerScrolled",hero:"landing-module__I_lyca__hero",heroActions:"landing-module__I_lyca__heroActions",heroFine:"landing-module__I_lyca__heroFine",heroSub:"landing-module__I_lyca__heroSub",main:"landing-module__I_lyca__main",nav:"landing-module__I_lyca__nav",navHideSmall:"landing-module__I_lyca__navHideSmall",navLink:"landing-module__I_lyca__navLink",navLinkActive:"landing-module__I_lyca__navLinkActive",page:"landing-module__I_lyca__page",plan:"landing-module__I_lyca__plan",planDesc:"landing-module__I_lyca__planDesc",planFeatures:"landing-module__I_lyca__planFeatures",planFoot:"landing-module__I_lyca__planFoot",planName:"landing-module__I_lyca__planName",planNote:"landing-module__I_lyca__planNote",planPopular:"landing-module__I_lyca__planPopular",planPrice:"landing-module__I_lyca__planPrice",planTag:"landing-module__I_lyca__planTag",planTop:"landing-module__I_lyca__planTop",plans:"landing-module__I_lyca__plans",reveal:"landing-module__I_lyca__reveal",revealIn:"landing-module__I_lyca__revealIn",rise:"landing-module__I_lyca__rise",secHead:"landing-module__I_lyca__secHead",secLede:"landing-module__I_lyca__secLede",secTitle:"landing-module__I_lyca__secTitle",section:"landing-module__I_lyca__section",shell:"landing-module__I_lyca__shell",shellNarrow:"landing-module__I_lyca__shellNarrow",totalExecutions:"landing-module__I_lyca__totalExecutions",totalExecutionsBadge:"landing-module__I_lyca__totalExecutionsBadge",totalExecutionsLabel:"landing-module__I_lyca__totalExecutionsLabel",totalExecutionsNote:"landing-module__I_lyca__totalExecutionsNote",totalExecutionsValue:"landing-module__I_lyca__totalExecutionsValue",wordmark:"landing-module__I_lyca__wordmark"})},82295,e=>{"use strict";async function t(e,a=globalThis){let i,r=String(e??""),o=a.navigator?.clipboard?.writeText;if("function"==typeof o)try{await o.call(a.navigator.clipboard,r);return}catch(e){i=e}let n=a.document;if(n?.body&&"function"==typeof n.createElement&&"function"==typeof n.execCommand){let e=n.createElement("textarea");e.value=r,e.setAttribute("readonly",""),e.style.position="fixed",e.style.opacity="0",n.body.appendChild(e);try{if(e.focus(),e.select(),n.execCommand("copy"))return}finally{e.remove()}}throw i instanceof Error?i:Error("clipboard_unavailable")}e.s(["copyTextToClipboard",0,t])},97379,72804,20226,e=>{"use strict";var t=e.i(71645);let a={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none"},i=(0,t.forwardRef)(({color:e="currentColor",size:i=24,strokeWidth:r,absoluteStrokeWidth:o=!1,className:n="",altIcon:l,showAlt:s=!1,icon:c,primaryColor:d,secondaryColor:u,disableSecondaryOpacity:h=!1,..._},f)=>{let m=void 0!==r?o?24*Number(r)/Number(i):r:void 0,p=void 0!==m?{strokeWidth:m,stroke:"currentColor"}:{},g={ref:f,...a,width:i,height:i,color:d||e,className:n,...p,..._},v=[...s&&l?l:c].sort(([,e],[,t])=>{let a=void 0!==e.opacity;return void 0!==t.opacity?1:a?-1:0}).map(([a,i])=>{let r=void 0!==i.opacity,o=r&&!h?i.opacity:void 0,n=u?{...void 0!==i.stroke?{stroke:r?u:d||e}:{fill:r?u:d||e}}:{};return(0,t.createElement)(a,{...i,...p,...n,opacity:o,key:i.key})});return(0,t.createElement)("svg",g,v)});i.displayName="HugeiconsIcon",e.s(["HugeiconsIcon",0,i],72804),e.s([],97379),e.s(["GiftIcon",0,[["path",{d:"M4 11V15C4 18.2998 4 19.9497 5.02513 20.9749C6.05025 22 7.70017 22 11 22H13C16.2998 22 17.9497 22 18.9749 20.9749C20 19.9497 20 18.2998 20 15V11",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"1.5",key:"0"}],["path",{d:"M3 9C3 8.25231 3 7.87846 3.20096 7.6C3.33261 7.41758 3.52197 7.26609 3.75 7.16077C4.09808 7 4.56538 7 5.5 7H18.5C19.4346 7 19.9019 7 20.25 7.16077C20.478 7.26609 20.6674 7.41758 20.799 7.6C21 7.87846 21 8.25231 21 9C21 9.74769 21 10.1215 20.799 10.4C20.6674 10.5824 20.478 10.7339 20.25 10.8392C19.9019 11 19.4346 11 18.5 11H5.5C4.56538 11 4.09808 11 3.75 10.8392C3.52197 10.7339 3.33261 10.5824 3.20096 10.4C3 10.1215 3 9.74769 3 9Z",stroke:"currentColor",strokeLinejoin:"round",strokeWidth:"1.5",key:"1"}],["path",{d:"M6 3.78571C6 2.79949 6.79949 2 7.78571 2H8.14286C10.2731 2 12 3.7269 12 5.85714V7H9.21429C7.43908 7 6 5.56091 6 3.78571Z",stroke:"currentColor",strokeLinejoin:"round",strokeWidth:"1.5",key:"2"}],["path",{d:"M18 3.78571C18 2.79949 17.2005 2 16.2143 2H15.8571C13.7269 2 12 3.7269 12 5.85714V7H14.7857C16.5609 7 18 5.56091 18 3.78571Z",stroke:"currentColor",strokeLinejoin:"round",strokeWidth:"1.5",key:"3"}],["path",{d:"M12 11L12 22",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"1.5",key:"4"}]]],20226)},72328,71164,38544,e=>{"use strict";let t={current:null},a={current:!1};e.s(["hasReducedMotionListener",0,a,"prefersReducedMotion",0,t],71164);let i="u">typeof window;function r(){if(a.current=!0,i)if(window.matchMedia){let e=window.matchMedia("(prefers-reduced-motion)"),a=()=>t.current=e.matches;e.addEventListener("change",a),a()}else t.current=!1}e.s(["initPrefersReducedMotion",0,r],38544);var o=e.i(71645);e.s(["useReducedMotion",0,function(){a.current||r();let[e]=(0,o.useState)(t.current);return e}],72328)},79432,e=>{"use strict";let t=(0,e.i(56420).default)("activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]);e.s(["Activity",0,t],79432)},16327,e=>{"use strict";let t=(0,e.i(56420).default)("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);e.s(["ChevronDown",0,t],16327)},99847,e=>{"use strict";let t=(0,e.i(56420).default)("circle-alert",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]]);e.s(["AlertCircle",0,t],99847)},4729,e=>{"use strict";let t=(0,e.i(56420).default)("clock-3",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 6v6h4",key:"135r8i"}]]);e.s(["Clock3",0,t],4729)},35610,e=>{"use strict";let t=(0,e.i(56420).default)("cloud-upload",[["path",{d:"M12 13v8",key:"1l5pq0"}],["path",{d:"M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242",key:"1pljnt"}],["path",{d:"m8 17 4-4 4 4",key:"1quai1"}]]);e.s(["UploadCloud",0,t],35610)},8734,e=>{"use strict";let t=(0,e.i(56420).default)("copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);e.s(["Copy",0,t],8734)},62368,e=>{"use strict";let t=(0,e.i(56420).default)("download",[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]]);e.s(["Download",0,t],62368)},72382,4684,e=>{"use strict";let t=(0,e.i(56420).default)("eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);e.s(["Eye",0,t],72382);var a=e.i(43476),i=e.i(71645),r=e.i(29372);e.s(["Avatar",0,function({name:e,src:t=null,size:o="md",status:n=null,ring:l=!1,className:s="",...c}){let d=function(e){let t=0;for(let a=0;a<e.length;a++)t=(31*t+e.charCodeAt(a))%360;return t}(e),[u,h]=(0,i.useState)(!1);return(0,i.useEffect)(()=>{h(!1)},[t]),(0,a.jsxs)("span",{className:(0,r.cx)("fa-avatar",`fa-avatar-${o}`,l&&"fa-avatar-ring",s),title:e,...c,children:[t&&!u?(0,a.jsx)("img",{className:"fa-avatar-img",src:t,alt:"",style:{borderRadius:"inherit"},onError:()=>h(!0)}):(0,a.jsx)("span",{className:"fa-avatar-fallback",style:{background:`linear-gradient(135deg, hsl(${d} 70% 22%), hsl(${(d+40)%360} 75% 14%))`,color:`hsl(${d} 90% 72%)`,borderRadius:"inherit"},children:e.split(/\s+/).slice(0,2).map(e=>e[0]?.toUpperCase()??"").join("")}),n&&(0,a.jsx)("span",{className:(0,r.cx)("fa-avatar-status",`fa-avatar-${n}`),"aria-label":n})]})}],4684)},34322,e=>{"use strict";let t=(0,e.i(56420).default)("file-code-corner",[["path",{d:"M4 12.15V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-3.35",key:"1wthlu"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"m5 16-3 3 3 3",key:"331omg"}],["path",{d:"m9 22 3-3-3-3",key:"lsp7cz"}]]);e.s(["FileCode2",0,t],34322)},89360,e=>{"use strict";let t=(0,e.i(56420).default)("file-code",[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M10 12.5 8 15l2 2.5",key:"1tg20x"}],["path",{d:"m14 12.5 2 2.5-2 2.5",key:"yinavb"}]]);e.s(["FileCode",0,t],89360)},37076,96315,e=>{"use strict";var t=e.i(56420);let a=(0,t.default)("layers",[["path",{d:"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",key:"zw3jo"}],["path",{d:"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",key:"1wduqc"}],["path",{d:"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",key:"kqbvx6"}]]);e.s(["default",0,a],37076);let i=(0,t.default)("mail",[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]]);e.s(["Mail",0,i],96315)},21357,25981,e=>{"use strict";var t=e.i(56420);let a=(0,t.default)("play",[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]]);e.s(["Play",0,a],21357);let i=(0,t.default)("upload",[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]]);e.s(["Upload",0,i],25981)},41120,e=>{"use strict";let t=(0,e.i(56420).default)("refresh-cw",[["path",{d:"M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",key:"v9h5vc"}],["path",{d:"M21 3v5h-5",key:"1q7to0"}],["path",{d:"M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",key:"3uifl3"}],["path",{d:"M8 16H3v5",key:"1cv678"}]]);e.s(["RefreshCw",0,t],41120)},94371,e=>{"use strict";let t=(0,e.i(56420).default)("rocket",[["path",{d:"M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5",key:"qeys4"}],["path",{d:"M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09",key:"u4xsad"}],["path",{d:"M9 12a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.4 22.4 0 0 1-4 2z",key:"676m9"}],["path",{d:"M9 12H4s.55-3.03 2-4c1.62-1.08 5 .05 5 .05",key:"92ym6u"}]]);e.s(["Rocket",0,t],94371)},4139,e=>{"use strict";let t=(0,e.i(56420).default)("terminal",[["path",{d:"M12 19h8",key:"baeox8"}],["path",{d:"m4 17 6-6-6-6",key:"1yngyt"}]]);e.s(["Terminal",0,t],4139)},7219,e=>{"use strict";let t=(0,e.i(56420).default)("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]);e.s(["TrendingUp",0,t],7219)}]);