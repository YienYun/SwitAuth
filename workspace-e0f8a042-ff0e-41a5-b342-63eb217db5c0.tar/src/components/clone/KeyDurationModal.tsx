"use client";

import { useState } from "react";
import FlowModal from "./FlowModal";
import FaSelect from "./FaSelect";

/**
 * "Set or add key days" dialog — direct port of the decompiled `ey` component
 * in chunk 3k6a5lhrkscp5.js, opened by the keys page "Set or add days" action
 * (enabled only for active keys, exactly like the original
 * `disabled:…||"active"!==(e.base_status||e.status)` guard).
 *
 * Decompiled state contract: `now` freezes at mount (the preview stays
 * stable), the summary derives paused / unused (timer not started) / remaining
 * from the record, the action select disables "Add days" for lifetime keys
 * (remaining === null), the days input accepts 1–3650 integers, the hint and
 * preview copy follow the decompiled branch tree, and save is disabled while
 * invalid. The original POSTed to /v1/keys/{id}/duration and refreshed; the
 * clone's parent applies the same mode/days semantics locally.
 */

export interface DurationRecord {
  /** Server-style numeric id, shown as `Access key #N`. */
  numericId: number;
  /** Absolute epoch-ms expiry; null = lifetime. */
  expiresAtMs: number | null;
  /** First-use timestamp; null = timer not started (unused). */
  claimedAtMs: number | null;
  /** TTL from first use for unused keys (decompiled expires_after_ms). */
  expiresAfterMs: number | null;
  pausedAtMs: number | null;
  pausedRemainingMs: number | null;
}

const DAY_MS = 864e5;

/** Decompiled: round-trips through days with 2 decimals. */
const daysLabel = (ms: number) => `${Math.round((ms / DAY_MS) * 100) / 100} days`;

export default function KeyDurationModal({
  record,
  onClose,
  onSave,
}: {
  record: DurationRecord;
  onClose: () => void;
  onSave: (mode: "add" | "set", days: number) => Promise<void> | void;
}) {
  // Decompiled `useState(Date.now)` — frozen for the dialog's lifetime.
  const [now] = useState(Date.now);
  // Normalize optional fields (older persisted records omit them).
  const pausedAtMs = record.pausedAtMs ?? null;
  const expiresAtMs = record.expiresAtMs ?? null;
  const claimedAtMs = record.claimedAtMs ?? null;
  const expiresAfterMs = record.expiresAfterMs ?? null;
  const pausedRemainingMs = record.pausedRemainingMs ?? null;
  const paused = pausedAtMs !== null;
  const unused = !claimedAtMs && expiresAtMs === null && !paused;
  const remaining = paused
    ? (pausedRemainingMs ?? 0)
    : unused
      ? expiresAfterMs
      : expiresAtMs === null
        ? null
        : Math.max(0, expiresAtMs - now);

  const [action, setAction] = useState<"add" | "set">(remaining === null ? "set" : "add");
  const [days, setDays] = useState("30");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const parsed = Number(days);
  const valid = Number.isInteger(parsed) && parsed >= 1 && parsed <= 3650 && (action === "set" || remaining !== null);
  const newTotal = ((action === "add" && remaining) || 0) + DAY_MS * parsed;

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!valid || busy) return;
    setBusy(true);
    setError("");
    try {
      await onSave(action, parsed);
      onClose();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message.replaceAll("_", " ") : "Could not update the key.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <FlowModal
      onClose={() => {
        if (!busy) onClose();
      }}
      title="Set or add key days"
      eyebrow={`Access key #${record.numericId}`}
    >
      <form
        className="key-duration-dialog-module__E8o3Fq__form"
        onSubmit={(event) => void submit(event)}
      >
        <div className="key-duration-dialog-module__E8o3Fq__summary">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 6v6l4 2" />
          </svg>
          <div>
            <strong>{remaining === null ? "Lifetime access" : `${daysLabel(remaining)} ${unused ? "on first use" : "remaining"}`}</strong>
            <p>
              {paused ? "This key stays paused." : unused ? "Its timer has not started yet." : "Changes apply to this key only."}
            </p>
          </div>
        </div>
        <label>
          Action
          <FaSelect
            ariaLabel="Duration action"
            value={action}
            disabled={busy}
            onChange={(next) => setAction(next as "add" | "set")}
            options={[
              { value: "add", label: "Add days", disabled: remaining === null },
              { value: "set", label: "Set remaining days" },
            ]}
          />
        </label>
        <label htmlFor="key-duration-days">
          Days
          <span className="fa-field fa-field-unlabeled">
            <span className="fa-field-frame">
              <input
                id="key-duration-days"
                className="fa-field-input"
                type="number"
                min={1}
                max={3650}
                step={1}
                required
                value={days}
                disabled={busy}
                onChange={(event) => setDays(event.target.value)}
              />
              <span className="fa-field-charge" aria-hidden="true" />
            </span>
          </span>
        </label>
        <p className="key-duration-dialog-module__E8o3Fq__hint">
          {action === "add"
            ? "Adds to remaining time. An expired key starts from now."
            : "Replaces the remaining time with the number of days entered."}{" "}
          {unused ? "Unused keys still start on first use." : paused ? "Paused time starts counting again when resumed." : ""}
        </p>
        {valid ? (
          <p className="key-duration-dialog-module__E8o3Fq__preview">
            {unused || paused ? `After saving: ${daysLabel(newTotal)}` : `New expiry: ${new Date(now + newTotal).toLocaleString()}`}
          </p>
        ) : null}
        {error ? (
          <p className="key-duration-dialog-module__E8o3Fq__error" role="alert">
            {error}
          </p>
        ) : null}
        <div className="key-duration-dialog-module__E8o3Fq__actions">
          <button
            type="button"
            className="flow-btn flow-btn-secondary flow-btn-md"
            disabled={busy}
            onClick={onClose}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content">
              <span className="flow-btn-label">Cancel</span>
            </span>
          </button>
          <button
            type="submit"
            className={`flow-btn flow-btn-primary flow-btn-md${busy ? " flow-btn-loading" : ""}`}
            disabled={!valid || busy}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content">
              {busy ? (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flow-btn-spinner" aria-hidden="true">
                  <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                </svg>
              ) : null}
              <span className="flow-btn-label">Save duration</span>
            </span>
          </button>
        </div>
      </form>
    </FlowModal>
  );
}
