"use client";

import { useCallback, useEffect, useId, useRef, useState } from "react";

/**
 * Port of the design-system Select (compiled module 52909 in
 * 0uywnoa6t3qjm.js). Single-select subset with the exact DOM contract of the
 * original: `fa-select` wrapper, `fa-select-trigger` combobox button with
 * chevron, and a fixed-positioned `fa-select-menu` listbox portal rendered to
 * document.body with per-option staggered animation delay. Keyboard support
 * mirrors the decompiled handler: ArrowUp/Down to move the highlight,
 * Enter/Space to commit, Escape to close, Home/End, type-ahead, click-outside
 * (pointerdown) dismissal, and option disabled states.
 */

export interface FaSelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export default function FaSelect({
  options,
  value,
  onChange,
  ariaLabel,
  placeholder = "Select…",
  disabled = false,
  className,
}: {
  options: FaSelectOption[];
  value: string;
  onChange: (next: string) => void;
  ariaLabel?: string;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}) {
  const uid = useId().replace(/:/g, "");
  const listId = `select-${uid}`;
  const rootRef = useRef<HTMLDivElement | null>(null);
  const menuRef = useRef<HTMLUListElement | null>(null);
  const typeRef = useRef({ text: "", at: 0 });
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const [position, setPosition] = useState<React.CSSProperties>({});

  const enabled = options
    .map((option, index) => ({ option, index }))
    .filter(({ option }) => !option.disabled);

  const enabledIndex = () => {
    const current = options.findIndex((option) => option.value === value && !option.disabled);
    return current >= 0 ? current : (enabled[0]?.index ?? -1);
  };

  const close = useCallback(() => setOpen(false), []);

  // Escape closes (capture) — decompiled useEscape.
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      event.stopPropagation();
      event.preventDefault();
      close();
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [open, close]);

  // Position the fixed menu under the trigger, flipping up when cramped —
  // decompiled W() measure step.
  const measure = useCallback(() => {
    const trigger = rootRef.current?.querySelector<HTMLElement>(".fa-select-trigger");
    if (!trigger) return;
    const rect = trigger.getBoundingClientRect();
    const below = window.innerHeight - rect.bottom - 10;
    const above = rect.top - 10;
    const flip = below < 180 && above > below;
    const height = Math.min(320, flip ? above : below);
    const width = Math.min(Math.max(rect.width, 180), window.innerWidth - 16);
    setPosition({
      position: "fixed",
      top: flip ? "auto" : `${rect.bottom + 6}px`,
      bottom: flip ? `${window.innerHeight - rect.top + 6}px` : "auto",
      left: `${Math.max(8, Math.min(rect.left, window.innerWidth - width - 8))}px`,
      right: "auto",
      width: `${width}px`,
      maxHeight: `${height}px`,
      zIndex: 10000,
    });
  }, []);

  useEffect(() => {
    if (!open) return;
    // Initial measure runs in a rAF callback (subscribe-then-update, never a
    // cascading sync render); resize/scroll keep live subscription.
    const raf = requestAnimationFrame(measure);
    window.addEventListener("resize", measure);
    window.addEventListener("scroll", measure, true);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", measure);
      window.removeEventListener("scroll", measure, true);
    };
  }, [open, measure]);

  // Click-outside dismissal — decompiled pointerdown listener.
  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: PointerEvent) => {
      const root = rootRef.current;
      const menu = menuRef.current;
      if (root?.contains(event.target as Node) || menu?.contains(event.target as Node)) return;
      close();
    };
    document.addEventListener("pointerdown", onPointerDown);
    return () => document.removeEventListener("pointerdown", onPointerDown);
  }, [open, close]);

  const commit = (option: FaSelectOption) => {
    if (option.disabled) return;
    onChange(option.value);
    setOpen(false);
  };

  const move = (direction: number) => {
    if (enabled.length === 0) return;
    setActive((current) => {
      const at = enabled.findIndex(({ index }) => index === current);
      if (at < 0) return direction > 0 ? enabled[0].index : enabled[enabled.length - 1].index;
      return enabled[(at + direction + enabled.length) % enabled.length].index;
    });
  };

  const onTriggerKeyDown = (event: React.KeyboardEvent) => {
    switch (event.key) {
      case "ArrowDown":
        event.preventDefault();
        if (open) move(1);
        else {
          setOpen(true);
          setActive(enabledIndex());
        }
        break;
      case "ArrowUp":
        event.preventDefault();
        if (open) move(-1);
        else {
          setOpen(true);
          const current = options.findIndex((option) => option.value === value && !option.disabled);
          setActive(current >= 0 ? current : (enabled[enabled.length - 1]?.index ?? -1));
        }
        break;
      case "Enter":
      case " ":
        event.preventDefault();
        if (open) {
          if (active >= 0) commit(options[active]);
        } else {
          setOpen(true);
          setActive(enabledIndex());
        }
        break;
      case "Home":
        if (open) {
          event.preventDefault();
          setActive(enabled[0]?.index ?? -1);
        }
        break;
      case "End":
        if (open) {
          event.preventDefault();
          setActive(enabled[enabled.length - 1]?.index ?? -1);
        }
        break;
      default:
        // Type-ahead — decompiled default branch.
        if (open && event.key.length === 1 && /\S/.test(event.key)) {
          const now = Date.now();
          const type = typeRef.current;
          type.text = now - type.at > 600 ? event.key : type.text + event.key;
          type.at = now;
          const found = options.findIndex(
            (option) => !option.disabled && option.label.toLowerCase().startsWith(type.text.toLowerCase()),
          );
          if (found >= 0) setActive(found);
        }
        break;
    }
  };

  const selected = options.find((option) => option.value === value);

  return (
    <div ref={rootRef} className={`fa-select${disabled ? " fa-select-disabled" : ""}${className ? ` ${className}` : ""}`}>
      <button
        type="button"
        className={`fa-select-trigger${open ? " fa-select-open" : ""}`}
        onClick={() => {
          if (disabled) return;
          setOpen((current) => !current);
          setActive(enabledIndex());
        }}
        onKeyDown={onTriggerKeyDown}
        disabled={disabled}
        role="combobox"
        aria-expanded={open}
        aria-haspopup="listbox"
        aria-controls={listId}
        aria-activedescendant={open && active >= 0 ? `${listId}-option-${active}` : undefined}
        aria-label={ariaLabel}
      >
        <span className={`fa-select-value${selected ? "" : " fa-select-placeholder"}`}>
          {selected ? selected.label : placeholder}
        </span>
        <span className="fa-select-chevron">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="m6 9 6 6 6-6" />
          </svg>
        </span>
      </button>
      {open
        ? (
            <ul
              ref={menuRef}
              id={listId}
              role="listbox"
              aria-labelledby={ariaLabel ? undefined : listId}
              className="fa-select-menu"
              style={position}
            >
              {options.map((option, index) => (
                <li
                  key={option.value}
                  id={`${listId}-option-${index}`}
                  role="option"
                  aria-selected={option.value === value}
                  aria-disabled={option.disabled || undefined}
                  className={`fa-select-option${option.disabled ? " fa-select-option-disabled" : ""}${index === active ? " fa-select-option-hl" : ""}${option.value === value ? " fa-select-option-active" : ""}`}
                  style={{ animationDelay: `${30 * index}ms` }}
                  onPointerEnter={() => {
                    if (!option.disabled) setActive(index);
                  }}
                  onClick={() => commit(option)}
                >
                  <span className="fa-select-option-text">
                    <span className="fa-select-option-label">{option.label}</span>
                  </span>
                  <span className="fa-select-option-check">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                  </span>
                </li>
              ))}
            </ul>
          )
        : null}
    </div>
  );
}
