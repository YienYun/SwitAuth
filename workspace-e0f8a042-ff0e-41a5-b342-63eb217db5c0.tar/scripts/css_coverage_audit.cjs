#!/usr/bin/env node
/**
 * CSS coverage + inline-style parity audit for the Switzauth clone.
 *
 * Part 1 — class coverage: every className token used by the ported clone
 *   components must be defined in one of the ported stylesheets (globals.css +
 *   src/app/styles/*). CSS custom properties set from JSX are tracked
 *   separately (they are consumed via var(--x) in CSS, not class selectors).
 *
 * Part 2 — inline-style parity (round-8 suggestion #3): every inline style
 *   property emitted by the clone components (`style={{ … }}` JSX props) is
 *   compared against the inline `style="…"` attributes captured in the
 *   scraped markup (/tmp/extracted/*.html — the ground truth). Divergences
 *   are reported for review:
 *     • clone inline props never seen in the scraped markup, and
 *     • scraped inline props the clone never emits (informational — some are
 *       runtime-injected by React libraries or applied via DOM scripting).
 */
const fs = require("fs");
const path = require("path");

const ROOT = "/home/z/my-project";
const CLONE_DIR = path.join(ROOT, "src/components/clone");
const SCRAPED_DIR = process.env.SCRAPED_DIR || "/tmp/extracted";
const STYLES = [
  path.join(ROOT, "src/app/globals.css"),
  ...fs.readdirSync(path.join(ROOT, "src/app/styles")).map((f) => path.join(ROOT, "src/app/styles", f)),
];

// ─────────────────────────────────────────────────────────────────────────────
// Part 1 — class coverage
// ─────────────────────────────────────────────────────────────────────────────
const components = fs.readdirSync(CLONE_DIR).filter((f) => /\.(tsx|jsx)$/.test(f));
const used = new Map(); // class token -> [files]
const usedVars = new Map(); // --custom-prop -> [files]

function addToken(token, file) {
  if (!/^-?-?[a-zA-Z_][a-zA-Z0-9_-]*$/.test(token) || token.length <= 2) return;
  if (token.startsWith("--")) {
    // CSS custom property (set inline or in a var() reference)
    if (!usedVars.has(token)) usedVars.set(token, []);
    usedVars.get(token).push(file);
    return;
  }
  // plausible CSS class only: lowercase, contains - or __ (filters copy
  // text like "Auto-delete", "-Loader", "MCP-capable", "_blank")
  if (/[A-Z]/.test(token)) return;
  if (token === "_blank" || token === "_self" || token === "_parent") return;
  if (!token.includes("-") && !token.includes("__") && !token.includes("_")) return;
  if (!used.has(token)) used.set(token, []);
  used.get(token).push(file);
}

function addClassList(list, file) {
  for (const token of list.split(/\s+/)) addToken(token, file);
}

for (const file of components) {
  const src = fs.readFileSync(path.join(CLONE_DIR, file), "utf8");
  // className="static classes"
  for (const m of src.matchAll(/className="([^"]+)"/g)) addClassList(m[1], file);
  // className={'static classes'}
  for (const m of src.matchAll(/className=\{'([^']+)'\}/g)) addClassList(m[1], file);
  // className={`template ${dynamic} literals`} — static fragments only
  for (const m of src.matchAll(/className=\{`([^`]+)`\}/g)) {
    addClassList(m[1].replace(/\$\{[^}]*\}/g, " "), file);
  }
  // class="…" inside innerHTML template markup
  for (const m of src.matchAll(/\bclass="([^"]+)"/g)) addClassList(m[1], file);
  // classList.add/remove/toggle/contains("token")
  for (const m of src.matchAll(/classList\.(?:add|remove|toggle|contains)\((["'`])([^"'`]+)\1/g)) {
    addClassList(m[2], file);
  }
}

const defined = new Set();
const cssVarRefs = new Set(); // vars consumed via var(--x) in CSS
for (const file of STYLES) {
  if (!fs.existsSync(file)) continue;
  const css = fs.readFileSync(file, "utf8").replace(/\/\*[\s\S]*?\*\//g, "");
  for (const match of css.matchAll(/\.([a-zA-Z_][a-zA-Z0-9_-]*)/g)) defined.add(match[1]);
  for (const match of css.matchAll(/var\((--[a-zA-Z0-9-]+)/g)) cssVarRefs.add(match[1]);
}

const missing = [...used.keys()].filter((t) => !defined.has(t)).sort();
console.log(`Components scanned: ${components.length}`);
console.log(`Class tokens used:  ${used.size}`);
console.log(`Classes defined:    ${defined.size}`);

// Runtime-generated or confirmed-absent class families (see worklog rounds
// 5–9): lucide-* are added by the lucide-react icon runtime (sizing comes
// from the `.lucide` base rule), recharts-* are injected by recharts at
// runtime, ui-dialog-* are shadcn structural markers without original CSS,
// flow-btn-md / flow-icon-btn-ghost / flow-icon-btn-md are confirmed absent
// from the original compiled chunks too (base classes carry the sizing),
// and tokens ending with "-" are template-literal fragments ("fa-popup-${tone}").
const EXPECTED_PREFIXES = ["lucide-", "recharts-", "ui-dialog-"];
const EXPECTED_EXACT = new Set(["flow-btn-md", "flow-icon-btn-ghost", "flow-icon-btn-md"]);
const unexpected = missing.filter(
  (t) =>
    !t.endsWith("-") &&
    !EXPECTED_EXACT.has(t) &&
    !EXPECTED_PREFIXES.some((p) => t.startsWith(p)),
);
console.log(`\nUSED BUT NOT DEFINED (${missing.length} raw / ${unexpected.length} unexpected):`);
for (const token of unexpected) {
  const files = [...new Set(used.get(token))].join(", ");
  console.log(`  ${token}  ← ${files}`);
}

// Custom properties set from JSX but never consumed by any stylesheet rule —
// potential dead inline vars (reported for review; inline-only consumption by
// other inline styles is legitimate, e.g. --fa-seg-index inside a component).
const deadVars = [...usedVars.keys()].filter((v) => !cssVarRefs.has(v)).sort();
console.log(`\nJSX-SET CUSTOM PROPS NEVER READ IN CSS (${deadVars.length}):`);
for (const token of deadVars) {
  const files = [...new Set(usedVars.get(token))].join(", ");
  console.log(`  ${token}  ← ${files}`);
}

// ─────────────────────────────────────────────────────────────────────────────
// Part 2 — inline-style parity vs the scraped markup
// ─────────────────────────────────────────────────────────────────────────────
const kebab = (prop) =>
  prop.startsWith("--") ? prop : prop.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();

// 2a. scraped ground truth: style="prop: value; …"
const scrapedProps = new Map(); // prop -> {count, files:Set}
const scrapedFiles = fs.existsSync(SCRAPED_DIR)
  ? fs.readdirSync(SCRAPED_DIR).filter((f) => f.endsWith(".html"))
  : [];
for (const file of scrapedFiles) {
  const html = fs.readFileSync(path.join(SCRAPED_DIR, file), "utf8");
  for (const m of html.matchAll(/style="([^"]*)"/g)) {
    for (const decl of m[1].split(";")) {
      const idx = decl.indexOf(":");
      if (idx < 1) continue;
      const prop = decl.slice(0, idx).trim().toLowerCase();
      if (!prop || prop.startsWith("<")) continue;
      if (!scrapedProps.has(prop)) scrapedProps.set(prop, { count: 0, files: new Set() });
      scrapedProps.get(prop).count += 1;
      scrapedProps.get(prop).files.add(file);
    }
  }
}

// 2b. clone inline styles: style={{ prop: value, "--custom": value }} —
//     balanced-brace scan (style objects may contain nested braces/ternaries).
function extractStyleObjects(src) {
  const out = [];
  const anchor = /style=\{\{/g;
  let m;
  while ((m = anchor.exec(src))) {
    let depth = 2;
    let i = anchor.lastIndex;
    const start = i;
    while (i < src.length && depth > 0) {
      const ch = src[i];
      if (ch === "{") depth += 1;
      else if (ch === "}") depth -= 1;
      i += 1;
    }
    if (depth === 0) out.push(src.slice(start, i - 1));
  }
  return out;
}

const cloneProps = new Map(); // prop -> [files]
const STRING_VALUE = /["'`]([^["'`]*)["'`]/; // first string literal in the value
for (const file of components) {
  const src = fs.readFileSync(path.join(CLONE_DIR, file), "utf8");
  for (const body of extractStyleObjects(src)) {
    // strip comments so "// note" / "/* note */" never parse as declarations
    const clean = body.replace(/\/\*[\s\S]*?\*\//g, " ").replace(/(^|[^:])\/\/[^\n]*/g, "$1 ");
    // top-level property keys: commas at depth 0 separate entries
    const entries = [];
    let depth = 0, cur = "";
    for (const ch of clean) {
      if (ch === "(" || ch === "[" || ch === "{") depth += 1;
      else if (ch === ")" || ch === "]" || ch === "}") depth -= 1;
      if (ch === "," && depth === 0) { entries.push(cur); cur = ""; continue; }
      cur += ch;
    }
    if (cur.trim()) entries.push(cur);
    for (const entry of entries) {
      const kv = entry.split(/[:=]/); // `prop: value` or shorthand `{"--x": v}`
      if (kv.length < 2) continue;
      const keyRaw = kv[0].replace(/["'`{}\s]/g, "");
      if (!keyRaw || keyRaw.startsWith("...")) continue;
      const prop = kebab(keyRaw);
      // skip spread-derived dynamic styles; keep concrete declarations only
      const value = entry.slice(entry.indexOf(kv[0]) + kv[0].length);
      if (!STRING_VALUE.test(value) && !/true|false|\d/.test(value)) continue;
      if (!cloneProps.has(prop)) cloneProps.set(prop, new Set());
      cloneProps.get(prop).add(file);
    }
  }
}

console.log(`\n━━━ INLINE-STYLE PARITY (scraped files: ${scrapedFiles.length}, scraped style attrs: ${scrapedProps.size} props) ━━━`);

// Clone-only inline props that were reviewed against the decompiled sources
// and screenshots in round 9 and are faithful (see worklog):
//   --color-executions  → decompiled ChartContainer config (eG) injects the
//                         series color inline exactly like this.
//   --modal-w           → genuine original mechanism: theme.css sizes the
//                         workspace form modals via
//                         max-width:min(var(--modal-w,580px),…).
//   animation-delay     → decompiled FaSelect staggers its options
//                         (animationDelay:`${30*r}ms`).
//   font-variant-numeric / font-weight on tooltip values → clone
//                         approximation of the shared reui ChartTooltipContent
//                         internals (hover tooltips were never captured in the
//                         archive; verified against screenshots round 7).
//   the remaining structural props (border-*, flex, font, margin-*, outline,
//   overflow-y, padding-top, resize, text-*, transition, appearance, …) live
//   inside the rebuilt modals/drawer/palette (PublishScriptModal,
//   AddProviderModal, NewProjectModal, CommandPalette, ImportUsersModal,
//   MobileDrawer) — each screenshot-verified in earlier rounds.
const REVIEWED_INLINE = new Set([
  "--color-executions",
  "--modal-w",
  "animation-delay",
  "font-variant-numeric",
]);

const cloneOnly = [...cloneProps.keys()].filter((p) => !scrapedProps.has(p)).sort();
const unreviewed = cloneOnly.filter((p) => !REVIEWED_INLINE.has(p));
console.log(`\nCLONE INLINE PROPS NOT IN SCRAPED MARKUP (${cloneOnly.length} total / ${unreviewed.length} unreviewed):`);
console.log(`  reviewed & faithful (allowlisted): ${[...cloneOnly].filter((p) => REVIEWED_INLINE.has(p)).sort().join(", ") || "—"}`);
for (const prop of unreviewed) {
  console.log(`  NEW ${prop}  ← ${[...cloneProps.get(prop)].join(", ")}`);
}

const scrapedOnly = [...scrapedProps.keys()].filter((p) => !cloneProps.has(p)).sort();
console.log(`\nSCRAPED INLINE PROPS THE CLONE NEVER EMITS (${scrapedOnly.length}) — informational:`);
console.log(`  ${scrapedOnly.join(", ")}`);
