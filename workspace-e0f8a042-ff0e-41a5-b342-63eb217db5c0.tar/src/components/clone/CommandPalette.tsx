"use client";

/**
 * Switzauth command palette — rebuilt on the decompiled ground truth from
 * chunk 3k6a5lhrkscp5.js (groups `sa` + wrappers rM/rR/rW/rD/rz/rH/rO/r$) and
 * the ported `.flowCommandDialog` / `.ui-command-*` rules in theme.css, so the
 * already-present CSS applies verbatim instead of inline approximations.
 *
 * Structure recovered from the decompiled app:
 *   flowCommandDialog
 *     ├─ sr-only title + description
 *     ├─ .ui-dialog-close (showCloseButton)
 *     └─ .ui-command
 *         ├─ .ui-command-input-wrapper  (placeholder "Search dashboard, keys, docs...")
 *         └─ .ui-command-list
 *             ├─ .ui-command-empty      "No matching section found."
 *             └─ .ui-command-group (CORE / TOOLS / DOCUMENTATION / ACCOUNT)
 *                 ├─ [cmdk-group-heading]
 *                 ├─ .ui-command-item   icon 16 / 1.5 + label + "Current" shortcut
 *                 └─ .ui-command-separator (between groups)
 *
 * Item `value` for filtering = `${title} ${label} ${tab}` lowercased, matching
 * the decompiled palette. "Discord" stays non-navigational like the sidebar
 * (its page CSS module was never part of the captured archive).
 */

import { useEffect, useMemo, useRef, useState } from "react";
import type { WorkspaceView } from "./WorkspaceView";

type PaletteTab =
  | "dashboard" | "projects" | "keys" | "rewards" | "discord"
  | "obfuscator" | "decompiler" | "docs" | "api" | "mcp" | "changelog" | "profile";

type PaletteItem = { label: string; tab: PaletteTab; protected: boolean };

type PaletteGroup = { title: string; items: PaletteItem[] };

/* Decompiled `sa` groups — labels, tabs, protected flags and order preserved. */
const GROUPS: PaletteGroup[] = [
  {
    title: "CORE",
    items: [
      { label: "Dashboard", tab: "dashboard", protected: false },
      { label: "Projects", tab: "projects", protected: true },
      { label: "Users / Keys", tab: "keys", protected: true },
      { label: "Rewards", tab: "rewards", protected: true },
      { label: "Discord", tab: "discord", protected: true },
    ],
  },
  {
    title: "TOOLS",
    items: [
      { label: "Obfuscator", tab: "obfuscator", protected: true },
      { label: "Decompiler", tab: "decompiler", protected: true },
    ],
  },
  {
    title: "DOCUMENTATION",
    items: [
      { label: "Docs", tab: "docs", protected: false },
      { label: "API", tab: "api", protected: false },
      { label: "MCP Server", tab: "mcp", protected: true },
      { label: "Changelog", tab: "changelog", protected: false },
    ],
  },
  {
    title: "ACCOUNT",
    items: [{ label: "Profile", tab: "profile", protected: true }],
  },
];

/* Decompiled icon path data (Hugeicons via st(...) wrappers; Rewards/Discord
 * are the captured Hugeicons Gift/Discord equivalents). Stroke 1.5, size 16 —
 * exactly like the original `r$`-era items. Colors come from CSS
 * (.ui-command-item svg), never inline. */
const ICONS: Record<PaletteTab, React.ReactNode> = {
  dashboard: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M13.6903 19.4567C13.5 18.9973 13.5 18.4149 13.5 17.25C13.5 16.0851 13.5 15.5027 13.6903 15.0433C13.944 14.4307 14.4307 13.944 15.0433 13.6903C15.5027 13.5 16.0851 13.5 17.25 13.5C18.4149 13.5 18.9973 13.5 19.4567 13.6903C20.0693 13.944 20.556 14.4307 20.8097 15.0433C21 15.5027 21 16.0851 21 17.25C21 18.4149 21 18.9973 20.8097 19.4567C20.556 20.0693 20.0693 20.556 19.4567 20.8097C18.9973 21 18.4149 21 17.25 21C16.0851 21 15.5027 21 15.0433 20.8097C14.4307 20.556 13.944 20.0693 13.6903 19.4567Z" strokeLinecap="square" strokeLinejoin="round" />
          <path d="M13.6903 8.95671C13.5 8.49728 13.5 7.91485 13.5 6.75C13.5 5.58515 13.5 5.00272 13.6903 4.54329C13.944 3.93072 14.4307 3.44404 15.0433 3.1903C15.5027 3 16.0851 3 17.25 3C18.4149 3 18.9973 3 19.4567 3.1903C20.0693 3.44404 20.556 3.93072 20.8097 4.54329C21 5.00272 21 5.58515 21 6.75C21 7.91485 21 8.49728 20.8097 8.95671C20.556 9.56928 20.0693 10.056 19.4567 10.3097C18.9973 10.5 18.4149 10.5 17.25 10.5C16.0851 10.5 15.5027 10.5 15.0433 10.3097C14.4307 10.056 13.944 9.56928 13.6903 8.95671Z" strokeLinecap="square" strokeLinejoin="round" />
          <path d="M3.1903 19.4567C3 18.9973 3 18.4149 3 17.25C3 16.0851 3 15.5027 3.1903 15.0433C3.44404 14.4307 3.93072 13.944 4.54329 13.6903C5.00272 13.5 5.58515 13.5 6.75 13.5C7.91485 13.5 8.49728 13.5 8.95671 13.6903C9.56928 13.944 10.056 14.4307 10.3097 15.0433C10.5 15.5027 10.5 16.0851 10.5 17.25C10.5 18.4149 10.5 18.9973 10.3097 19.4567C10.056 20.0693 9.56928 20.556 8.95671 20.8097C8.49728 21 7.91485 21 6.75 21C5.58515 21 5.00272 21 4.54329 20.8097C3.93072 20.556 3.44404 20.0693 3.1903 19.4567Z" strokeLinecap="square" strokeLinejoin="round" />
          <path d="M3.1903 8.95671C3 8.49728 3 7.91485 3 6.75C3 5.58515 3 5.00272 3.1903 4.54329C3.44404 3.93072 3.93072 3.44404 4.54329 3.1903C5.00272 3 5.58515 3 6.75 3C7.91485 3 8.49728 3 8.95671 3.1903C9.56928 3.44404 10.056 3.93072 10.3097 4.54329C10.5 5.00272 10.5 5.58515 10.5 6.75C10.5 7.91485 10.5 8.49728 10.3097 8.95671C10.056 9.56928 9.56928 10.056 8.95671 10.3097C8.49728 10.5 7.91485 10.5 6.75 10.5C5.58515 10.5 5.00272 10.5 4.54329 10.3097C3.93072 10.056 3.44404 9.56928 3.1903 8.95671Z" strokeLinecap="square" strokeLinejoin="round" />
    </svg>
  ),
  projects: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M8 7H16.75C18.8567 7 19.91 7 20.6667 7.50559C20.9943 7.72447 21.2755 8.00572 21.4944 8.33329C22 9.08996 22 10.1433 22 12.25C22 15.7612 22 17.5167 21.1573 18.7779C20.7926 19.3238 20.3238 19.7926 19.7779 20.1573C18.5167 21 16.7612 21 13.25 21H12C7.28595 21 4.92893 21 3.46447 19.5355C2 18.0711 2 15.714 2 11V7.94427C2 6.1278 2 5.21956 2.38032 4.53806C2.65142 4.05227 3.05227 3.65142 3.53806 3.38032C4.21956 3 5.1278 3 6.94427 3C8.10802 3 8.6899 3 9.19926 3.19101C10.3622 3.62712 10.8418 4.68358 11.3666 5.73313L12 7" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M14 17C14 17 17 14.7905 17 14C17 13.2094 14 11 14 11" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M9.99998 17C9.99998 17 7.00001 14.7905 7 14C6.99999 13.2094 10 11 10 11" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  keys: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M16 21C15.7668 18.0685 13.3422 15.7477 10.3085 15.5521L9.49999 15.5C9.21121 15.5076 8.94209 15.5178 8.68816 15.5298C5.68124 15.6723 3.23089 18.0974 3 21" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12.75 9.75C12.75 11.5449 11.2949 13 9.5 13C7.70508 13 6.25 11.5449 6.25 9.75C6.25 7.95507 7.70508 6.5 9.5 6.5C11.2949 6.5 12.75 7.95507 12.75 9.75Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M21 17.501C20.7709 14.6314 18.4541 12.2748 15.5 11.9961" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M15.9877 9C16.8965 8.42434 17.5001 7.40788 17.5001 6.25C17.5001 4.45507 16.0496 3 14.2602 3C13.3811 3 12.5838 3.35121 12.0001 3.92139" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  rewards: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M4 11V15C4 18.2998 4 19.9497 5.02513 20.9749C6.05025 22 7.70017 22 11 22H13C16.2998 22 17.9497 22 18.9749 20.9749C20 19.9497 20 18.2998 20 15V11" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M3 9C3 8.25231 3 7.87846 3.20096 7.6C3.33261 7.41758 3.52197 7.26609 3.75 7.16077C4.09808 7 4.56538 7 5.5 7H18.5C19.4346 7 19.9019 7 20.25 7.16077C20.478 7.26609 20.6674 7.41758 20.799 7.6C21 7.87846 21 8.25231 21 9C21 9.74769 21 10.1215 20.799 10.4C20.6674 10.5824 20.478 10.7339 20.25 10.8392C19.9019 11 19.4346 11 18.5 11H5.5C4.56538 11 4.09808 11 3.75 10.8392C3.52197 10.5824 3.20096 10.4 3 10.4C3 9.74769 3 9.74769 3 9Z" strokeLinejoin="round" />
          <path d="M6 3.78571C6 2.79949 6.79949 2 7.78571 2H8.14286C10.2731 2 12 3.7269 12 5.85714V7H9.21429C7.43908 7 6 5.56091 6 3.78571Z" strokeLinejoin="round" />
          <path d="M18 3.78571C18 2.79949 17.2005 2 16.2143 2H15.8571C13.7269 2 12 3.7269 12 5.85714V7H14.7857C16.5609 7 18 5.56091 18 3.78571Z" strokeLinejoin="round" />
          <path d="M12 11L12 22" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  discord: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M15.5 17.5C16.5 19 17.3333 19.6667 18 20C19.3333 19.6667 22 18.2 22 15C22 11.8 20.6667 7.33333 20 5.5C18 4.3 15.8333 4 15 4L14.198 5.60393C13.4135 5.28708 12.4058 5.25438 12 5.27763C11.5942 5.25438 10.5865 5.28708 9.80197 5.60393L9 4C8.16667 4 6 4.3 4 5.5C3.33333 7.33333 2 11.8 2 15C2 18.2 4.66667 19.6667 6 20C6.66667 19.6667 7.5 19 8.5 17.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M17.3652 11.5C17.3652 12.6046 16.5817 13.5 15.6152 13.5C14.6487 13.5 13.8652 12.6046 13.8652 11.5C13.8652 10.3954 14.6487 9.5 15.6152 9.5C16.5817 9.5 17.3652 10.3954 17.3652 11.5Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10 11.5C10 12.6046 9.2165 13.5 8.25 13.5C7.2835 13.5 6.5 12.6046 6.5 11.5C6.5 10.3954 7.2835 9.5 8.25 9.5C9.2165 9.5 10 10.3954 10 11.5Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M17.5 16.5C16.4022 17.3967 14.3502 18 12 18C9.64981 18 7.59785 17.3967 6.5 16.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  obfuscator: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M13.9258 12.7775L11.7775 10.6292C11.4847 10.3364 11.3383 10.19 11.1803 10.1117C10.8798 9.96277 10.527 9.96277 10.2264 10.1117C10.0685 10.19 9.92207 10.3364 9.62923 10.6292C9.33638 10.9221 9.18996 11.0685 9.11169 11.2264C8.96277 11.527 8.96277 11.8798 9.11169 12.1803C9.18996 12.3383 9.33638 12.4847 9.62923 12.7775L11.7775 14.9258M13.9258 12.7775L20.3708 19.2225C20.6636 19.5153 20.81 19.6617 20.8883 19.8197C21.0372 20.1202 21.0372 20.473 20.8883 20.7736C20.81 20.9315 20.6636 21.0779 20.3708 21.3708C20.0779 21.6636 19.9315 21.81 19.7736 21.8883C19.473 22.0372 19.1202 22.0372 18.8197 21.8883C18.6617 21.81 18.5153 21.6636 18.2225 21.3708L11.7775 14.9258M13.9258 12.7775L11.7775 14.9258" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M17 2L17.2948 2.7966C17.6813 3.84117 17.8746 4.36345 18.2556 4.74445C18.6366 5.12545 19.1588 5.31871 20.2034 5.70523L21 6L20.2034 6.29477C19.1588 6.68129 18.6366 6.87456 18.2556 7.25555C17.8746 7.63655 17.6813 8.15883 17.2948 9.2034L17 10L16.7052 9.2034C16.3187 8.15884 16.1254 7.63655 15.7444 7.25555C15.3634 6.87455 14.8412 6.68129 13.7966 6.29477L13 6L13.7966 5.70523C14.8412 5.31871 15.3634 5.12545 15.7444 4.74445C16.1254 4.36345 16.3187 3.84117 16.7052 2.7966L17 2Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M6 4L6.22108 4.59745C6.51097 5.38087 6.65592 5.77259 6.94167 6.05834C7.22741 6.34408 7.61913 6.48903 8.40255 6.77892L9 7L8.40255 7.22108C7.61913 7.51097 7.22741 7.65592 6.94166 7.94167C6.65592 8.22741 6.51097 8.61913 6.22108 9.40255L6 10L5.77892 9.40255C5.48903 8.61913 5.34408 8.22741 5.05833 7.94167C4.77259 7.65592 4.38087 7.51097 3.59745 7.22108L3 7L3.59745 6.77892C4.38087 6.48903 4.77259 6.34408 5.05833 6.05833C5.34408 5.77259 5.48903 5.38087 5.77892 4.59745L6 4Z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  decompiler: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M2 6C2 5.05719 2 4.58579 2.29289 4.29289C2.58579 4 3.05719 4 4 4C4.94281 4 5.41421 4 5.70711 4.29289C6 4.58579 6 5.05719 6 6V8C6 8.94281 6 9.41421 5.70711 9.70711C5.41421 10 4.94281 10 4 10C3.05719 10 2.58579 10 2.29289 9.70711C2 9.41421 2 8.94281 2 8V6Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M6.5 16C6.5 15.0572 6.5 14.5858 6.79289 14.2929C7.08579 14 7.55719 14 8.5 14C9.44281 14 9.91421 14 10.2071 14.2929C10.5 14.5858 10.5 15.0572 10.5 16V18C10.5 18.9428 10.5 19.4142 10.2071 19.7071C9.91421 20 9.44281 20 8.5 20C7.55719 20 7.08579 20 6.79289 19.7071C6.5 19.4142 6.5 18.9428 6.5 18V16Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M13.5 6C13.5 5.05719 13.5 4.58579 13.7929 4.29289C14.0858 4 14.5572 4 15.5 4C16.4428 4 16.9142 4 17.2071 4.29289C17.5 4.58579 17.5 5.05719 17.5 6V8C17.5 8.94281 17.5 9.41421 17.2071 9.70711C16.9142 10 16.4428 10 15.5 10C14.5572 10 14.0858 10 13.7929 9.70711C13.5 9.41421 13.5 8.94281 13.5 8V6Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M13.5 16C13.5 15.0572 13.5 14.5858 13.7929 14.2929C14.0858 14 14.5572 14 15.5 14C16.4428 14 16.9142 14 17.2071 14.2929C17.5 14.5858 17.5 15.0572 17.5 16V18C17.5 18.9428 17.5 19.4142 17.2071 19.7071C16.9142 20 16.4428 20 15.5 20C14.5572 20 14.0858 20 13.7929 19.7071C13.5 19.4142 13.5 18.9428 13.5 18V16Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M9 5L10.5 4V10" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M2 15L3.5 14V20" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M20.5 5L22 4V10" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M20.5 15L22 14V20" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  docs: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M15.5 7H8.5M12.499 11H8.49902" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M20 22H6C4.89543 22 4 21.1046 4 20M4 20C4 18.8954 4.89543 18 6 18H20V6C20 4.11438 20 3.17157 19.4142 2.58579C18.8284 2 17.8856 2 16 2H10C7.17157 2 5.75736 2 4.87868 2.87868C4 3.75736 4 5.17157 4 8V20Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M19.5 18C19.5 18 18.5 18.7628 18.5 20C18.5 21.2372 19.5 22 19.5 22" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  api: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M4.00004 17C4.00004 17 9.99999 12.5811 10 11C10 9.41884 4 5 4 5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M12 19H20" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  mcp: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M19 4H5C4.06812 4 3.60218 4 3.23463 4.15224C2.74458 4.35523 2.35523 4.74458 2.15224 5.23463C2 5.60218 2 6.06812 2 7C2 7.93188 2 8.39782 2.15224 8.76537C2.35523 9.25542 2.74458 9.64477 3.23463 9.84776C3.60218 10 4.06812 10 5 10H19C19.9319 10 20.3978 10 20.7654 9.84776C21.2554 9.64477 21.6448 9.25542 21.8478 8.76537C22 8.39782 22 7.93188 22 7C22 6.06812 22 5.60218 21.8478 5.23463C21.6448 4.74458 21.2554 4.35523 20.7654 4.15224C20.3978 4 19.9319 4 19 4Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M19 14H5C4.06812 14 3.60218 14 3.23463 14.1522C2.74458 14.3552 2.35523 14.7446 2.15224 15.2346C2 15.6022 2 16.0681 2 17C2 17.9319 2 18.3978 2.15224 18.7654C2.35523 19.2554 2.74458 19.6448 3.23463 19.8478C3.60218 20 4.06812 20 5 20H19C19.9319 20 20.3978 20 20.7654 19.8478C21.2554 19.6448 21.6448 19.2554 21.8478 18.7654C22 18.3978 22 17.9319 22 17C22 16.0681 22 15.6022 21.8478 15.2346C21.6448 14.7446 21.2554 14.3552 20.7654 14.1522C20.3978 14 19.9319 14 19 14Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M6.125 7H6M6.25 7C6.25 7.13807 6.13807 7.25 6 7.25C5.86193 7.25 5.75 7.13807 5.75 7C5.75 6.86193 5.86193 6.75 6 6.75C6.13807 6.75 6.25 6.86193 6.25 7Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10.125 7H10M10.25 7C10.25 7.13807 10.1381 7.25 10 7.25C9.86193 7.25 9.75 7.13807 9.75 7C9.75 6.86193 9.86193 6.75 10 6.75C10.1381 6.75 10.25 6.86193 10.25 7Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M6.125 17H6M6.25 17C6.25 17.1381 6.13807 17.25 6 17.25C5.86193 17.25 5.75 17.1381 5.75 17C5.75 16.8619 5.86193 16.75 6 16.75C6.13807 16.75 6.25 16.8619 6.25 17Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10.125 17H10M10.25 17C10.25 17.1381 10.1381 17.25 10 17.25C9.86193 17.25 9.75 17.1381 9.75 17C9.75 16.8619 9.86193 16.75 10 16.75C10.1381 16.75 10.25 16.8619 10.25 17Z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  changelog: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <circle cx="12" cy="12" r="10" />
          <path d="M12 8V12L14 14" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  profile: (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
          <path d="M18.4984 19.1511C17.3377 17.4018 15.2947 16.2009 12.9313 16.0569L11.9984 16C11.6652 16.0083 11.3547 16.0194 11.0617 16.0325C8.71722 16.1376 6.66598 17.3796 5.5 19.1511" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M14.9961 10C14.9961 11.6569 13.6529 13 11.9961 13C10.3392 13 8.99609 11.6569 8.99609 10C8.99609 8.34315 10.3392 7 11.9961 7C13.6529 7 14.9961 8.34315 14.9961 10Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
};

/** Decompiled filter value: `${title} ${label} ${tab}`.toLowerCase(). */
function itemValue(group: PaletteGroup, item: PaletteItem): string {
  return `${group.title} ${item.label} ${item.tab}`.toLowerCase();
}

function capitalize(title: string): string {
  const s = title.toLowerCase();
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export default function CommandPalette({
  onClose,
  onNavigate,
  activeView,
}: {
  onClose: () => void;
  onNavigate: (view: WorkspaceView) => void;
  activeView: WorkspaceView;
}) {
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const listRef = useRef<HTMLDivElement | null>(null);

  const visibleGroups = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return GROUPS;
    return GROUPS.map((group) => ({
      ...group,
      items: group.items.filter((item) => itemValue(group, item).includes(q)),
    })).filter((group) => group.items.length > 0);
  }, [query]);

  const flat = useMemo(
    () => visibleGroups.flatMap((group) => group.items),
    [visibleGroups]
  );

  const safeIndex = Math.min(activeIndex, Math.max(0, flat.length - 1));
  const activeItem = flat[safeIndex] ?? null;

  const [prevQuery, setPrevQuery] = useState(query);
  if (prevQuery !== query) {
    // cmdk resets the selection to the first rendered item on query change.
    // Adjusted during render (React's recommended pattern) so the reset never
    // cascades through an effect.
    setPrevQuery(query);
    setActiveIndex(0);
  }

  // Keep the selected row in view while arrowing through results.
  useEffect(() => {
    const list = listRef.current;
    if (!list) return;
    const selected = list.querySelector<HTMLElement>('[data-selected="true"]');
    selected?.scrollIntoView({ block: "nearest" });
  }, [safeIndex, query]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const runItem = (item: PaletteItem) => {
    // The original called onProtectedNavigate/onNavigate; the clone workspace
    // is always authenticated, so every tab routes except "discord", whose
    // section was never captured (non-navigational, like the sidebar).
    if (item.tab === "discord") return;
    onClose();
    onNavigate(item.tab as WorkspaceView);
  };

  const onKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActiveIndex((i) => (flat.length ? (i + 1) % flat.length : 0));
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setActiveIndex((i) => (flat.length ? (i - 1 + flat.length) % flat.length : 0));
    } else if (event.key === "Home") {
      event.preventDefault();
      setActiveIndex(0);
    } else if (event.key === "End") {
      event.preventDefault();
      setActiveIndex(Math.max(0, flat.length - 1));
    } else if (event.key === "Enter") {
      event.preventDefault();
      if (activeItem) runItem(activeItem);
    }
  };

  let rowIndex = -1;

  return (
    <>
      <div className="ui-dialog-overlay" onClick={onClose} aria-hidden="true" />
      <div
        className="ui-dialog-content ui-command-dialog flowCommandDialog"
        role="dialog"
        aria-modal="true"
        aria-label="Switzauth Command Palette"
      >
        <div data-slot="dialog-header" className="sr-only">
          <h2 data-slot="dialog-title" className="ui-dialog-title">Switzauth Command Palette</h2>
          <p data-slot="dialog-description" className="ui-dialog-description">Search dashboard sections and tools.</p>
        </div>
        <button type="button" className="ui-dialog-close" aria-label="Close" onClick={onClose}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </button>
        <div className="ui-command" data-slot="command">
          <div className="ui-command-input-wrapper" data-slot="command-input-wrapper">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
              <path d="m21 21-4.34-4.34" />
              <circle cx="11" cy="11" r="8" />
            </svg>
            <input
              ref={inputRef}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              onKeyDown={onKeyDown}
              placeholder="Search dashboard, keys, docs..."
              aria-label="Search dashboard, keys, docs..."
              autoComplete="off"
              spellCheck={false}
              data-slot="command-input"
              className="ui-command-input"
            />
          </div>
          <div
            ref={listRef}
            className="ui-command-list"
            data-slot="command-list"
            role="listbox"
            aria-label="Command palette results"
          >
            {flat.length === 0 ? (
              <div data-slot="command-empty" className="ui-command-empty" role="presentation">
                No matching section found.
              </div>
            ) : (
              visibleGroups.map((group, groupIndex) => (
                <div key={group.title} className="ui-command-group" data-slot="command-group" role="group" aria-label={capitalize(group.title)}>
                  <div cmdk-group-heading="">{capitalize(group.title)}</div>
                  {group.items.map((item) => {
                    rowIndex += 1;
                    const index = rowIndex;
                    const selected = index === safeIndex;
                    const isCurrent = item.tab === activeView; // "discord" is never a view, so it can never match
                    return (
                      // cmdk items are div[role=option] (never <button>): the
                      // ported .ui-command-item CSS assumes borderless divs and
                      // UA button chrome would leak through.
                      <div
                        key={item.tab}
                        role="option"
                        aria-selected={selected}
                        data-selected={selected}
                        tabIndex={-1}
                        className="ui-command-item"
                        data-slot="command-item"
                        onClick={() => runItem(item)}
                        onMouseEnter={() => setActiveIndex(index)}
                      >
                        {ICONS[item.tab]}
                        <span>{item.label}</span>
                        {isCurrent ? (
                          <span data-slot="command-shortcut" className="ui-command-shortcut">
                            Current
                          </span>
                        ) : null}
                      </div>
                    );
                  })}
                  {groupIndex < visibleGroups.length - 1 ? (
                    <div className="ui-command-separator" data-slot="command-separator" role="separator" />
                  ) : null}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </>
  );
}
