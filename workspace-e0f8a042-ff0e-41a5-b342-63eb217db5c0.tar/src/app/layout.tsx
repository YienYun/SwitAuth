import type { Metadata } from "next";
import "./styles/fonts.css";
import "./styles/theme.css";
import "./styles/app.css";
import "./styles/dash-a.css";
import "./styles/dash-b.css";
import "./styles/dash-chart-vars.css";
import "./styles/dash-tailwind.css";
import "./styles/docs.css";
import "./styles/changelog.css";
import "./styles/obfuscator.css";
import "./styles/decompiler.css";
import "./styles/logs.css";
import "./styles/analytics.css";
import "./styles/activity-chart.css";
import "./styles/uiverse.css";
import "./styles/spotlight.css";
import "./styles/port-fixes.css";

export const metadata: Metadata = {
  title: "Switzauth - Lua/Luau Source Protection and Key Licensing",
  description:
    "Hosted Lua/Luau source protection, license-key authentication, customer access delivery, and execution logging for software teams.",
  icons: {
    icon: [{ url: "/brand/icon.png", sizes: "512x512", type: "image/png" }],
  },
};

const themeInit = `
  try {
    var savedTheme = localStorage.getItem("switzauth-theme");
    var theme = savedTheme === "dark" ? "dark" : "light";
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
  } catch (error) {
    document.documentElement.dataset.theme = "light";
    document.documentElement.style.colorScheme = "light";
  }
`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className="displayfont_7f55197b-module__xxCxpq__variable bodyfont_fff2ca47-module__oEqcsG__variable monofont_ec94182d-module__nOFkpq__variable"
      suppressHydrationWarning
    >
      <head>
        <link
          rel="preload"
          href="/fonts/space_grotesk_latin-s.p.2cyn07wtgehh0.woff2"
          as="font"
          type="font/woff2"
          crossOrigin=""
        />
        <link
          rel="preload"
          href="/fonts/plus_jakarta_sans_latin-s.p.18rizl4rsrl42.woff2"
          as="font"
          type="font/woff2"
          crossOrigin=""
        />
        <link
          rel="preload"
          href="/fonts/jetbrains_mono_latin-s.p.3t6q91iet4nsy.woff2"
          as="font"
          type="font/woff2"
          crossOrigin=""
        />
        <script dangerouslySetInnerHTML={{ __html: themeInit }} id="switzauth-theme" />
      </head>
      <body>{children}</body>
    </html>
  );
}
