"use client";

import { useMemo, useState } from "react";
import FaSelect from "./FaSelect";
import { useKeyCounts } from "./useKeyCounts";

/**
 * 1:1 port of the decompiled ActivityChartCard (chunk 2bqlz_847hfus.js,
 * lazy-loaded as `sY` on the dashboard). Recovers the interactions the static
 * scrape could not capture:
 *  - the range Select is the real design-system component (options
 *    Weekly/Monthly/Yearly, aria-label "{title} range"); changing the value
 *    re-keys the plot SVG exactly like the decompiled `key: _`, which remounts
 *    it and replays the acDraw/acFade line-draw animation;
 *  - hovering a hit rect shows the decompiled crosshair, node dot and readout
 *    (value + day, acPop animation) and highlights the hovered day label
 *    (`dayOn`).
 * All styling comes from the ported activity-chart-card-module__ohKOwW__*
 * rules — no invented CSS. With the captured all-zero series the rendered
 * paths are byte-identical to the scraped markup.
 */

export interface ActivityPoint {
  day: string;
  value: number;
}

const W = 320;
const H = 130;

function smoothPath(points: Array<[number, number]>): string {
  if (points.length < 2) return "";
  if (points.length === 2) {
    return `M ${points[0][0]} ${points[0][1]} L ${points[1][0]} ${points[1][1]}`;
  }
  let d = `M ${points[0][0]} ${points[0][1]}`;
  for (let i = 1; i < points.length - 1; i += 1) {
    const [l, r] = points[i];
    const [c, s] = points[i + 1];
    d += ` Q ${l} ${r} ${(l + c) / 2} ${(r + s) / 2}`;
  }
  const [tx, ty] = points[points.length - 1];
  d += ` L ${tx} ${ty}`;
  return d;
}

export default function UsersActivityChart({
  title = "Activity",
  totalValue,
  data,
  className,
  dropdownOptions = ["Weekly", "Monthly", "Yearly"],
  trendLabel = "+12% from last week",
  valueSuffix = "",
  liveKeysTotal = false,
}: {
  title?: string;
  totalValue: string;
  data: ActivityPoint[];
  className?: string;
  dropdownOptions?: string[];
  trendLabel?: string;
  valueSuffix?: string;
  /** When true the total/trend follow the persisted key count (the decompiled
   * dashboard passed the account's real numbers; the captured account had 1,
   * so SSR stays identical and hydration keeps the number truthful). */
  liveKeysTotal?: boolean;
}) {
  // Decompiled state: selected range re-keys the SVG; hover index drives the
  // crosshair/readout pair.
  const [range, setRange] = useState(dropdownOptions[0] || "");
  const [hover, setHover] = useState<number | null>(null);

  const uid = `ac${title.replace(/[^a-zA-Z0-9]/g, "")}`;
  // Live total (decompiled contract: the account's real key count — captured
  // account had 1, so the static value and the hydrated one agree at SSR).
  const { total: liveTotal } = useKeyCounts();
  const shownTotal = liveKeysTotal ? String(liveTotal) : totalValue;
  // Captured label has no singularization ("1 total keys") — keep it verbatim.
  const shownTrend = liveKeysTotal ? `${liveTotal} total keys` : trendLabel;
  const series = Array.isArray(data) && data.length ? data : [];
  const maxValue = useMemo(
    () => series.reduce((acc, point) => (point.value > acc ? point.value : acc), 0),
    [series],
  );
  const coords = useMemo(() => {
    if (!series.length) return [] as Array<[number, number]>;
    const step = series.length > 1 ? W / (series.length - 1) : 0;
    return series.map((point, index) => [
      index * step,
      10 + 110 * (1 - (maxValue > 0 ? point.value / maxValue : 0)),
    ]) as Array<[number, number]>;
  }, [series, maxValue]);

  const linePath = useMemo(() => smoothPath(coords), [coords]);
  const areaPath = useMemo(() => {
    if (!linePath) return "";
    const last = coords[coords.length - 1];
    return `${linePath} L ${last[0]} ${H} L ${coords[0][0]} ${H} Z`;
  }, [linePath, coords]);

  const slot = series.length ? W / series.length : 0;
  const hoveredPoint = hover != null ? series[hover] : null;
  const hoveredCoord = hover != null ? coords[hover] : null;

  return (
    <section
      className={`activityChartCard activity-chart-card-module__ohKOwW__card${className ? ` ${className}` : ""}`}
      aria-labelledby={`${uid}-title`}
    >
      <div className="activity-chart-card-module__ohKOwW__head">
        <h3 id={`${uid}-title`} className="activity-chart-card-module__ohKOwW__title">{title}</h3>
        <FaSelect
          className="activityChartRangeSelect"
          ariaLabel={`${title} range`}
          value={range}
          onChange={setRange}
          options={dropdownOptions.map((option) => ({ value: option, label: option }))}
        />
      </div>
      <p className="activity-chart-card-module__ohKOwW__total">
        {shownTotal}
        {valueSuffix ? <sup>{valueSuffix}</sup> : null}
      </p>
      <p className="activity-chart-card-module__ohKOwW__trend">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-trending-up" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M16 7h6v6" /><path d="m22 7-8.5 8.5-5-5L2 17" /></svg>
        {shownTrend}
      </p>
      <div className="activity-chart-card-module__ohKOwW__plot">
        {/* key={range} — decompiled remount that replays the draw animation */}
        <svg key={range} viewBox="0 0 320 130" preserveAspectRatio="none" role="img" aria-label={`${title} over time`}>
          <defs>
            <linearGradient id={`${uid}-stroke`} x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stopColor="#7c5cff" /><stop offset="100%" stopColor="#c44be8" /></linearGradient>
            <linearGradient id={`${uid}-fill`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#7c5cff" stopOpacity="0.22" />
              <stop offset="100%" stopColor="#7c5cff" stopOpacity="0" />
            </linearGradient>
          </defs>
          <line className="activity-chart-card-module__ohKOwW__grid" x1="0" y1="130" x2="320" y2="130" vectorEffect="non-scaling-stroke" />
          {areaPath ? <path className="activity-chart-card-module__ohKOwW__area" d={areaPath} fill={`url(#${uid}-fill)`} /> : null}
          {linePath ? (
            <path
              className="activity-chart-card-module__ohKOwW__line"
              d={linePath}
              stroke={`url(#${uid}-stroke)`}
              pathLength="1"
              strokeDasharray="1"
              vectorEffect="non-scaling-stroke"
              style={{ "--ac-len": "1" } as React.CSSProperties}
            />
          ) : null}
          {hoveredCoord ? (
            <line
              className="activity-chart-card-module__ohKOwW__crosshair"
              x1={hoveredCoord[0]}
              y1="0"
              x2={hoveredCoord[0]}
              y2="130"
              vectorEffect="non-scaling-stroke"
            />
          ) : null}
          {series.map((point, index) => (
            <rect
              key={`${point.day}-${index}`}
              className="activity-chart-card-module__ohKOwW__hit"
              x={Math.max(0, index * (series.length > 1 ? W / (series.length - 1) : 0) - slot / 2)}
              y="0"
              width={slot}
              height="130"
              onMouseEnter={() => setHover(index)}
              onMouseLeave={() => setHover(null)}
            />
          ))}
        </svg>
        {hoveredCoord && hoveredPoint ? (
          <>
            <span
              className="activity-chart-card-module__ohKOwW__node"
              style={{ left: `${(hoveredCoord[0] / W) * 100}%`, top: `${(hoveredCoord[1] / H) * 100}%` }}
              aria-hidden="true"
            />
            <div
              className="activity-chart-card-module__ohKOwW__readout"
              style={{ left: `${(hoveredCoord[0] / W) * 100}%`, top: `${(hoveredCoord[1] / H) * 100}%` }}
            >
              <span className="activity-chart-card-module__ohKOwW__readoutValue">{hoveredPoint.value}</span>
              <span className="activity-chart-card-module__ohKOwW__readoutDay">{hoveredPoint.day}</span>
            </div>
          </>
        ) : null}
      </div>
      <div
        className="activity-chart-card-module__ohKOwW__days"
        style={{ gridTemplateColumns: `repeat(${series.length || 1}, minmax(0, 1fr))` }}
      >
        {series.map((point, index) => (
          <span
            key={`${point.day}-label-${index}`}
            className={`activity-chart-card-module__ohKOwW__day${hover === index ? " activity-chart-card-module__ohKOwW__dayOn" : ""}`}
          >
            {point.day}
          </span>
        ))}
      </div>
    </section>
  );
}
