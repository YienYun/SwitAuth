"use client";

import { useMemo, useState } from "react";

const inputStyle: React.CSSProperties = {
  width: "100%",
  height: 40,
  border: "1px solid var(--fl-line-2)",
  borderRadius: 10,
  background: "var(--fl-surface)",
  color: "var(--fl-ink)",
  padding: "0 12px",
  font: "500 14px var(--fl-sans)",
  outline: "none",
};

const labelStyle: React.CSSProperties = {
  display: "block",
  font: "600 12.5px var(--fl-sans)",
  color: "var(--fl-ink-2)",
  marginBottom: 6,
};

const sectionHeadStyle: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: 8,
  font: "600 14px var(--fl-sans)",
  color: "var(--fl-ink)",
};

const sectionSubStyle: React.CSSProperties = {
  margin: "3px 0 0",
  font: "500 12.5px var(--fl-sans)",
  color: "var(--fl-ink-3)",
};

const iconTileStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  width: 26,
  height: 26,
  borderRadius: 8,
  border: "1px solid var(--fl-line)",
  background: "var(--fl-inset)",
  color: "var(--fl-violet)",
  flex: "none",
};

function Toggle({ on, onToggle, label }: { on: boolean; onToggle: () => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={onToggle}
      style={{
        width: 36,
        height: 20,
        borderRadius: 999,
        border: 0,
        cursor: "pointer",
        padding: 2,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: on ? "flex-end" : "flex-start",
        background: on ? "var(--fl-ink)" : "var(--fl-line-2)",
        transition: "background .18s var(--fl-ease)",
      }}
    >
      <span
        style={{
          width: 16,
          height: 16,
          borderRadius: 999,
          background: on ? "var(--fl-surface)" : "#fff",
          boxShadow: "0 1px 2px rgba(0,0,0,.25)",
          display: "block",
        }}
      />
    </button>
  );
}

export default function PublishScriptModal({ onClose }: { onClose: () => void }) {
  const [scriptName, setScriptName] = useState("");
  const [scope, setScope] = useState("Universal fallback");
  const [scopeValue, setScopeValue] = useState("*");
  const [uiLibrary, setUiLibrary] = useState(false);
  const [keyless, setKeyless] = useState(false);
  const [autoObfuscate, setAutoObfuscate] = useState(true);
  const [silent, setSilent] = useState(false);
  const [storageMode, setStorageMode] = useState<"protected" | "original">("protected");
  const [source, setSource] = useState("");

  const canPublish = useMemo(() => scriptName.trim().length > 0, [scriptName]);
  const lineCount = Math.max(1, source.split("\n").length);

  return (
    <>
      <div className="ui-dialog-overlay" onClick={onClose} aria-hidden="true" />
      <div
        className="ui-dialog-content"
        role="dialog"
        aria-modal="true"
        aria-labelledby="publish-script-title"
        style={{
          width: "min(720px, calc(100vw - 32px))",
          maxHeight: "min(760px, calc(100vh - 48px))",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          background: "var(--fl-surface)",
          color: "var(--fl-ink)",
          border: "1px solid var(--fl-line)",
          padding: 0,
        }}
      >
        <button type="button" className="ui-dialog-close" aria-label="Close" onClick={onClose} style={{ zIndex: 2 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </button>

        <header style={{ display: "flex", alignItems: "center", gap: 12, padding: "18px 22px", borderBottom: "1px solid var(--fl-line)" }}>
          <span style={{ ...iconTileStyle, width: 34, height: 34, borderRadius: 10 }}>
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z" />
              <path d="M14 2v5a1 1 0 0 0 1 1h5" />
              <path d="M10 12.5 8 15l2 2.5M14 12.5l2 2.5-2 2.5" />
            </svg>
          </span>
          <div>
            <h2 id="publish-script-title" style={{ margin: 0, font: "600 16px var(--fl-sans)", color: "var(--fl-ink)" }}>Publish script</h2>
            <p style={{ margin: "2px 0 0", font: "500 13px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
              Set how this script is targeted, delivered, and protected.
            </p>
          </div>
        </header>

        <div style={{ overflowY: "auto", padding: "6px 22px 18px" }}>
          <section style={{ padding: "16px 0", borderBottom: "1px solid var(--fl-line)" }}>
            <div style={sectionHeadStyle}>
              <span style={iconTileStyle}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M3 5.5c0-1.38 1.119-2.5 2.5-2.5h11.985c1.38 0 2.5 1.12 2.5 2.5v13c0 1.38-1.12 2.5-2.5 2.5H5.5A2.5 2.5 0 0 1 3 18.5v-13Z" />
                  <path d="M8.5 2.5v3.523c0 .538-.216 1.053-.6 1.433L6.5 8.854a2.02 2.02 0 0 0 0 2.292l1.4 1.398c.384.38.6.895.6 1.433V21.5" />
                </svg>
              </span>
              <div>
                <span>Script details</span>
                <p style={sectionSubStyle}>How this script is named and which places it answers for.</p>
              </div>
            </div>

            <div style={{ marginTop: 14 }}>
              <label style={labelStyle} htmlFor="publish-script-name">Script name</label>
              <input
                id="publish-script-name"
                style={inputStyle}
                placeholder="e.g. bloxfruit"
                value={scriptName}
                onChange={(event) => setScriptName(event.target.value)}
              />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginTop: 14 }}>
              <div>
                <label style={labelStyle} htmlFor="publish-script-scope">Scope</label>
                <select
                  id="publish-script-scope"
                  style={{ ...inputStyle, appearance: "none", cursor: "pointer" }}
                  value={scope}
                  onChange={(event) => setScope(event.target.value)}
                >
                  <option>Universal fallback</option>
                  <option>Game by place id</option>
                  <option>Game by name</option>
                </select>
              </div>
              <div>
                <label style={labelStyle} htmlFor="publish-script-scope-value">Scope value</label>
                <input
                  id="publish-script-scope-value"
                  style={inputStyle}
                  value={scopeValue}
                  onChange={(event) => setScopeValue(event.target.value)}
                />
                <p style={{ margin: "6px 2px 0", font: "500 12px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
                  Answers every place that has no more specific match.
                </p>
              </div>
            </div>
          </section>

          <section style={{ padding: "16px 0", borderBottom: "1px solid var(--fl-line)" }}>
            <div style={sectionHeadStyle}>
              <span style={iconTileStyle}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3ZM12 12l8-4.5M12 12v9m0-9L4 7.5" />
                </svg>
              </span>
              <div>
                <span>Delivery</span>
                <p style={sectionSubStyle}>How the loader serves and protects this payload.</p>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 14 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "flex-start", borderTop: "1px solid var(--fl-line)", paddingTop: 12 }}>
                <span style={iconTileStyle}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6 5.6 18.4" />
                  </svg>
                </span>
                <div style={{ flex: 1 }}>
                  <span style={{ font: "600 13.5px var(--fl-sans)", color: "var(--fl-ink)" }}>UI library loader</span>
                  <p style={{ margin: "2px 0 0", font: "500 12.5px var(--fl-sans)", color: "var(--fl-ink-3)", lineHeight: 1.5 }}>
                    Serves from its own direct loader path.
                  </p>
                </div>
                <Toggle on={uiLibrary} onToggle={() => setUiLibrary((v) => !v)} label="UI library loader" />
              </div>

              <div style={{ display: "flex", gap: 10, alignItems: "flex-start", borderTop: "1px solid var(--fl-line)", paddingTop: 12 }}>
                <span style={iconTileStyle}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
                    <path d="M7 11V7a5 5 0 0 1 9.9-1" />
                  </svg>
                </span>
                <div style={{ flex: 1 }}>
                  <span style={{ font: "600 13.5px var(--fl-sans)", color: "var(--fl-ink)" }}>Keyless access</span>
                  <p style={{ margin: "2px 0 0", font: "500 12.5px var(--fl-sans)", color: "var(--fl-ink-3)", lineHeight: 1.5 }}>
                    Runs without a key. Leave off to require one.
                  </p>
                </div>
                <Toggle on={keyless} onToggle={() => setKeyless((v) => !v)} label="Keyless access" />
              </div>

              <div style={{ display: "flex", gap: 10, alignItems: "flex-start", borderTop: "1px solid var(--fl-line)", paddingTop: 12 }}>
                <span style={iconTileStyle}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
                    <path d="m9 12 2 2 4-4" />
                  </svg>
                </span>
                <div style={{ flex: 1 }}>
                  <span style={{ font: "600 13.5px var(--fl-sans)", color: "var(--fl-ink)" }}>Auto-obfuscate</span>
                  <p style={{ margin: "2px 0 0", font: "500 12.5px var(--fl-sans)", color: "var(--fl-ink-3)", lineHeight: 1.5 }}>
                    Protects the payload with Centurion on every upload.
                  </p>
                </div>
                <Toggle on={autoObfuscate} onToggle={() => setAutoObfuscate((v) => !v)} label="Auto-obfuscate" />
              </div>

              <div style={{ display: "flex", gap: 10, alignItems: "flex-start", borderTop: "1px solid var(--fl-line)", paddingTop: 12 }}>
                <span style={iconTileStyle}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M12 3a3.4 3.4 0 0 0 0 6 3.4 3.4 0 0 1 0 6 3.4 3.4 0 0 0 0 6M3 12h18M7 7l1 1M7 16l1-1M16 8l1-1M16 17l1 1" />
                  </svg>
                </span>
                <div style={{ flex: 1 }}>
                  <span style={{ font: "600 13.5px var(--fl-sans)", color: "var(--fl-ink)" }}>Silent execution</span>
                  <p style={{ margin: "2px 0 0", font: "500 12.5px var(--fl-sans)", color: "var(--fl-ink-3)", lineHeight: 1.5 }}>
                    Hides Switzauth console messages. Your script&apos;s print and warn output stays on.
                  </p>
                </div>
                <Toggle on={silent} onToggle={() => setSilent((v) => !v)} label="Silent execution" />
              </div>
            </div>
          </section>

          <section style={{ padding: "16px 0 0" }}>
            <div style={sectionHeadStyle}>
              <span style={iconTileStyle}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <ellipse cx="12" cy="5" rx="9" ry="3" />
                  <path d="M3 5v14a9 3 0 0 0 18 0V5M3 12a9 3 0 0 0 18 0" />
                </svg>
              </span>
              <div>
                <span>Source storage</span>
                <p style={sectionSubStyle}>Choose what stays in your account after saving.</p>
              </div>
            </div>

            <div style={{ marginTop: 14, border: "1px solid var(--fl-line)", borderRadius: 12, background: "var(--fl-inset)", padding: 14 }}>
              <div
                role="radiogroup"
                aria-label="Source storage mode"
                style={{ display: "inline-flex", background: "var(--fl-sunken)", borderRadius: 10, padding: 3 }}
              >
                <button
                  type="button"
                  role="radio"
                  aria-checked={storageMode === "protected"}
                  onClick={() => setStorageMode("protected")}
                  style={{
                    border: storageMode === "protected" ? "1px solid var(--fl-line-2)" : "1px solid transparent",
                    background: storageMode === "protected" ? "var(--fl-surface)" : "transparent",
                    borderRadius: 8,
                    padding: "6px 14px",
                    font: "600 13px var(--fl-sans)",
                    color: "var(--fl-ink)",
                    cursor: "pointer",
                    boxShadow: storageMode === "protected" ? "var(--fl-shadow)" : "none",
                  }}
                >
                  Protected output
                </button>
                <button
                  type="button"
                  role="radio"
                  aria-checked={storageMode === "original"}
                  onClick={() => setStorageMode("original")}
                  style={{
                    border: storageMode === "original" ? "1px solid var(--fl-line-2)" : "1px solid transparent",
                    background: storageMode === "original" ? "var(--fl-surface)" : "transparent",
                    borderRadius: 8,
                    padding: "6px 14px",
                    font: "600 13px var(--fl-sans)",
                    color: "var(--fl-ink)",
                    cursor: "pointer",
                    boxShadow: storageMode === "original" ? "var(--fl-shadow)" : "none",
                  }}
                >
                  Original source
                </button>
              </div>
              <p style={{ margin: "10px 2px 0", font: "500 12.5px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
                Keep only the protected output. Your original source cannot be viewed or recovered after saving.
              </p>
            </div>

            <label
              style={{
                marginTop: 12,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 4,
                padding: "22px 16px",
                border: "1px dashed var(--fl-line-2)",
                borderRadius: 12,
                cursor: "pointer",
                color: "var(--fl-ink-2)",
                textAlign: "center",
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 3v12m0-12 4 4m-4-4-4 4" />
                <path d="M4 15v3a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-3" />
              </svg>
              <span style={{ font: "600 13.5px var(--fl-sans)", color: "var(--fl-ink)" }}>Drop a file or browse</span>
              <span style={{ font: "500 12px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
                Lua or Luau · only protected output will be kept
              </span>
              <input
                type="file"
                accept=".lua,.luau,text/plain"
                style={{ display: "none" }}
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => setSource(String(reader.result || ""));
                  reader.readAsText(file);
                }}
              />
            </label>

            <div style={{ marginTop: 12, border: "1px solid var(--fl-line)", borderRadius: 12, overflow: "hidden", background: "var(--fl-surface)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "9px 12px", background: "var(--fl-inset)", borderBottom: "1px solid var(--fl-line)", font: "600 12.5px var(--fl-mono)", color: "var(--fl-ink-2)" }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--fl-violet)" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
                  <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
                  <path d="M14 2v4a2 2 0 0 0 2 2h4" />
                </svg>
                {scriptName.trim() ? `${scriptName.trim().toLowerCase().replace(/\s+/g, "-")}-source.lua` : "payload-source.lua"}
              </div>
              <div style={{ display: "flex" }}>
                <div aria-hidden="true" style={{ padding: "12px 10px", background: "var(--fl-inset)", color: "var(--fl-ink-3)", font: "500 12.5px/1.6 var(--fl-mono)", textAlign: "right", minWidth: 40 }}>
                  {lineCount}
                </div>
                <textarea
                  aria-label="Script source"
                  spellCheck={false}
                  value={source}
                  onChange={(event) => setSource(event.target.value)}
                  placeholder="-- Paste your original source here..."
                  style={{
                    flex: 1,
                    minHeight: 170,
                    resize: "none",
                    border: 0,
                    outline: "none",
                    background: "var(--fl-surface)",
                    color: "var(--fl-ink)",
                    padding: "12px 14px",
                    font: "500 12.5px/1.6 var(--fl-mono)",
                  }}
                />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", padding: "8px 12px", borderTop: "1px solid var(--fl-line)", background: "var(--fl-inset)", font: "500 11.5px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
                <span>Lines: {lineCount}&nbsp;&nbsp;&nbsp;Characters: {source.length}</span>
                <span>Encoding: UTF-8&nbsp;&nbsp;&nbsp;Language: Lua</span>
              </div>
            </div>
          </section>
        </div>

        <footer style={{ display: "flex", justifyContent: "flex-end", gap: 10, padding: "14px 22px", borderTop: "1px solid var(--fl-line)" }}>
          <button
            type="button"
            className="flow-btn flow-btn-secondary flow-btn-md"
            onClick={onClose}
            style={{ border: "1px solid var(--fl-line-2)", borderRadius: 10, background: "var(--fl-surface)", color: "var(--fl-ink)", font: "600 13.5px var(--fl-sans)", cursor: "pointer" }}
          >
            <span className="flow-btn-label">Cancel</span>
          </button>
          <button
            type="button"
            className="flow-btn flow-btn-primary flow-btn-md"
            disabled={!canPublish}
            onClick={onClose}
            style={{
              border: "1px solid var(--fl-btn)",
              borderRadius: 10,
              background: canPublish ? "var(--fl-btn)" : "var(--fl-inset)",
              color: canPublish ? "#fff" : "var(--fl-ink-3)",
              font: "600 13.5px var(--fl-sans)",
              cursor: canPublish ? "pointer" : "not-allowed",
              opacity: canPublish ? 1 : 0.7,
            }}
          >
            <span className="flow-btn-label">Publish script</span>
          </button>
        </footer>
      </div>
    </>
  );
}
