"use client";

import { useEffect, useRef } from "react";
import type { WorkspaceView } from "./WorkspaceView";

export type DrawerNavItem = {
  label: string;
  view?: WorkspaceView;
  enabled: boolean;
  icon: React.ReactNode;
};

const ICON_ATTRS = {
  width: 18,
  height: 18,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  "aria-hidden": true,
} as const;

export function buildDrawerNavItems(
  NAV_MAP: Record<string, WorkspaceView>,
  DISABLED: string[]
): DrawerNavItem[] {
  const icons: Record<string, React.ReactNode> = {
    Dashboard: (
      <svg {...ICON_ATTRS} strokeLinecap="square">
        <path d="M13.69 19.457C13.5 18.997 13.5 18.415 13.5 17.25s0-1.747.19-2.207a2.5 2.5 0 0 1 1.353-1.353C15.503 13.5 16.085 13.5 17.25 13.5s1.747 0 2.207.19a2.5 2.5 0 0 1 1.353 1.353c.19.46.19 1.042.19 2.207s0 1.747-.19 2.207a2.5 2.5 0 0 1-1.353 1.353c-.46.19-1.042.19-2.207.19s-1.747 0-2.207-.19a2.5 2.5 0 0 1-1.353-1.353ZM13.69 8.957C13.5 8.497 13.5 7.915 13.5 6.75s0-1.747.19-2.207a2.5 2.5 0 0 1 1.353-1.353C15.503 3 16.085 3 17.25 3s1.747 0 2.207.19a2.5 2.5 0 0 1 1.353 1.353c.19.46.19 1.042.19 2.207s0 1.747-.19 2.207a2.5 2.5 0 0 1-1.353 1.353c-.46.19-1.042.19-2.207.19s-1.747 0-2.207-.19a2.5 2.5 0 0 1-1.353-1.353ZM3.19 19.457C3 18.997 3 18.415 3 17.25s0-1.747.19-2.207a2.5 2.5 0 0 1 1.353-1.353C5.003 13.5 5.585 13.5 6.75 13.5s1.747 0 2.207.19a2.5 2.5 0 0 1 1.353 1.353c.19.46.19 1.042.19 2.207s0 1.747-.19 2.207a2.5 2.5 0 0 1-1.353 1.353c-.46.19-1.042.19-2.207.19s-1.747 0-2.207-.19a2.5 2.5 0 0 1-1.353-1.353ZM3.19 8.957C3 8.497 3 7.915 3 6.75s0-1.747.19-2.207a2.5 2.5 0 0 1 1.353-1.353C5.003 3 5.585 3 6.75 3s1.747 0 2.207.19a2.5 2.5 0 0 1 1.353 1.353c.19.46.19 1.042.19 2.207s0 1.747-.19 2.207a2.5 2.5 0 0 1-1.353 1.353c-.46.19-1.042.19-2.207.19s-1.747 0-2.207-.19a2.5 2.5 0 0 1-1.353-1.353Z" />
      </svg>
    ),
    Projects: (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <path d="M8 7h8.75c2.107 0 3.16 0 3.917.506.327.219.608.5.827.827C22 9.09 22 10.143 22 12.25c0 3.511 0 5.267-.843 6.528a5 5 0 0 1-1.379 1.379C18.517 21 16.761 21 13.25 21H12c-4.714 0-7.071 0-8.536-1.465C2 18.071 2 14.714 2 11V7.944c0-1.816 0-2.725.38-3.406.271-.486.672-.887 1.158-1.158C4.22 3 5.128 3 6.944 3c1.164 0 1.746 0 2.255.191 1.163.436 1.642 1.493 2.167 2.542L12 7" />
        <path d="M14 17c0 0 3-2.209 3-3s-3-3-3-3M10 17c0 0-3-2.209-3-3s3-3 3-3" />
      </svg>
    ),
    "Users / Keys": (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <path d="M16 21c-.233-2.932-2.658-5.252-5.692-5.448L9.5 15.5c-.289.008-.558.018-.812.03C5.681 15.672 3.231 18.097 3 21" />
        <path d="M12.75 9.75a3.25 3.25 0 1 1-6.5 0 3.25 3.25 0 0 1 6.5 0ZM21 17.501c-.229-2.87-2.546-5.226-5.5-5.505M15.988 9a3.25 3.25 0 1 0-3.988-5.079" />
      </svg>
    ),
    Rewards: (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 11v4c0 3.3 0 4.95 1.025 5.975C6.05 22 7.7 22 11 22h2c3.3 0 4.95 0 5.975-1.025C20 19.95 20 18.3 20 15v-4M3 9c0-.748 0-1.122.201-1.4.132-.182.321-.333.55-.439C4.098 7 4.565 7 5.5 7h13c.935 0 1.402 0 1.75.161.229.105.418.256.549.439.201.278.201.652.201 1.4s0 1.122-.201 1.4c-.132.182-.321.333-.55.439C19.902 11 19.435 11 18.5 11h-13c-.935 0-1.402 0-1.75-.161a1.2 1.2 0 0 1-.55-.439C3 10.122 3 9.748 3 9ZM6 3.786C6 2.799 6.799 2 7.786 2h.357C10.273 2 12 3.727 12 5.857V7H9.214C7.439 7 6 5.561 6 3.786ZM18 3.786C18 2.799 17.201 2 16.214 2h-.357C13.727 2 12 3.727 12 5.857V7h2.786C16.561 7 18 5.561 18 3.786ZM12 11v11" />
      </svg>
    ),
    Discord: (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <path d="M15.5 17.5c1 1.5 1.833 2.167 2.5 2.5 1.333-.333 4-1.8 4-5s-1.333-7.667-2-9.5c-2-1.2-4.167-1.5-5-1.5l-.802 1.604a6 6 0 0 0-2.398 0L11 4c-.833 0-3 .3-5 1.5-.667 1.833-2 6.3-2 9.5s2.667 4.667 4 5c.667-.333 1.5-1 2.5-2.5M17.365 11.5a1.75 2 0 1 0 3.5 0 1.75 2 0 0 0-3.5 0ZM10 11.5a1.75 2 0 1 0-3.5 0 1.75 2 0 0 0 3.5 0ZM17.5 16.5c-1.098.897-3.15 1.5-5.5 1.5s-4.402-.603-5.5-1.5" />
      </svg>
    ),
    Obfuscator: (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <path d="M13.926 12.778 11.778 10.63c-.293-.293-.44-.44-.597-.518a1.2 1.2 0 0 0-1.055 0c-.158.079-.304.225-.597.518-.293.293-.44.44-.518.597a1.2 1.2 0 0 0 0 1.055c.078.158.225.304.518.597l2.148 2.148M13.926 12.778l6.445 6.445c.293.293.439.439.517.597a1.2 1.2 0 0 1 0 1.055c-.078.158-.224.304-.517.597-.293.293-.44.44-.597.518a1.2 1.2 0 0 1-1.055 0c-.158-.079-.304-.225-.597-.518l-6.445-6.445M13.926 12.778 11.778 14.926M17 2l.295.797c.386 1.044.58 1.566.96 1.947.382.381.904.574 1.948.961L21 6l-.797.295c-1.044.386-1.566.58-1.947.96-.381.382-.574.904-.961 1.949L17 10l-.295-.797c-.386-1.045-.58-1.567-.96-1.948-.382-.38-.904-.574-1.949-.96L13 6l.797-.295c1.045-.387 1.567-.58 1.948-.961.381-.381.575-.903.961-1.947L17 2ZM6 4l.221.597c.29.784.435 1.176.721 1.461.286.286.677.431 1.46.721L9 7l-.597.221c-.783.29-1.175.435-1.461.721-.286.286-.43.677-.72 1.461L6 10l-.221-.597c-.29-.784-.435-1.176-.72-1.461-.286-.286-.678-.431-1.461-.721L3 7l.597-.221c.784-.29 1.176-.435 1.461-.721.286-.286.431-.678.721-1.461L6 4Z" />
      </svg>
    ),
    Decompiler: (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <path d="M2 6c0-.943 0-1.414.293-1.707C2.586 4 3.057 4 4 4c.943 0 1.414 0 1.707.293C6 4.586 6 5.057 6 6v2c0 .943 0 1.414-.293 1.707C5.414 10 4.943 10 4 10c-.943 0-1.414 0-1.707-.293C2 9.414 2 8.943 2 8V6ZM6.5 16c0-.943 0-1.414.293-1.707C7.086 14 7.557 14 8.5 14c.943 0 1.414 0 1.707.293.293.293.293.764.293 1.707v2c0 .943 0 1.414-.293 1.707C9.914 20 9.443 20 8.5 20c-.943 0-1.414 0-1.707-.293C6.5 19.414 6.5 18.943 6.5 18v-2ZM13.5 6c0-.943 0-1.414.293-1.707C14.086 4 14.557 4 15.5 4c.943 0 1.414 0 1.707.293.293.293.293.764.293 1.707v2c0 .943 0 1.414-.293 1.707C16.914 10 16.443 10 15.5 10c-.943 0-1.414 0-1.707-.293C13.5 9.414 13.5 8.943 13.5 8V6ZM13.5 16c0-.943 0-1.414.293-1.707C14.086 14 14.557 14 15.5 14c.943 0 1.414 0 1.707.293.293.293.293.764.293 1.707v2c0 .943 0 1.414-.293 1.707-.293.293-.764.293-1.707.293-.943 0-1.414 0-1.707-.293-.293-.293-.293-.764-.293-1.707v-2ZM9 5l1.5-1v6M2 15l1.5-1v6M20.5 5 22 4v6M20.5 15l1.5-1v6" />
      </svg>
    ),
    Docs: (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <path d="M15.5 7h-7M12.499 11H8.499M20 22H6a2 2 0 0 1-2-2m0 0a2 2 0 0 1 2-2h14V6c0-1.886 0-2.828-.586-3.414C18.828 2 17.886 2 16 2h-6C7.172 2 5.757 2 4.879 2.879 4 3.757 4 5.172 4 8v12ZM19.5 18c0 0-1 .763-1 2s1 2 1 2" />
      </svg>
    ),
    API: (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <path d="M4 17s6-4.419 6-6-6-6-6-6M12 19h8" />
      </svg>
    ),
    "MCP Server": (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="4" width="20" height="6" rx="2" />
        <rect x="2" y="14" width="20" height="6" rx="2" />
        <path d="M6 7h.01M10 7h.01M6 17h.01M10 17h.01" />
      </svg>
    ),
    Changelog: (
      <svg {...ICON_ATTRS}>
        <circle cx="12" cy="12" r="10" />
        <path d="M12 8v4l2 2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    Profile: (
      <svg {...ICON_ATTRS} strokeLinecap="round" strokeLinejoin="round">
        <path d="M18.498 19.151C17.338 17.402 15.295 16.201 12.931 16.057L11.998 16c-.333.008-.644.02-.937.032-2.345.105-4.396 1.348-5.562 3.119M14.996 10a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM22 12c0 5.523-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2s10 4.477 10 10Z" />
      </svg>
    ),
  };
  const order = [
    "Dashboard",
    "Projects",
    "Users / Keys",
    "Rewards",
    "Discord",
    "Obfuscator",
    "Decompiler",
    "Docs",
    "API",
    "MCP Server",
    "Changelog",
    "Profile",
  ];
  return order.map((label) => ({
    label,
    view: NAV_MAP[label],
    enabled: Boolean(NAV_MAP[label]) && !DISABLED.includes(label),
    icon: icons[label],
  }));
}

export default function MobileDrawer({
  open,
  sectionLabel,
  activeView,
  items,
  onClose,
  onNavigate,
  onLogout,
}: {
  open: boolean;
  sectionLabel: string;
  activeView: WorkspaceView;
  items: DrawerNavItem[];
  onClose: () => void;
  onNavigate: (view: WorkspaceView) => void;
  onLogout: () => void;
}) {
  const drawerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    drawerRef.current?.focus();
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="sidebar-module__9SB1EG__mobileLayer" role="dialog" aria-modal="true" aria-label="Workspace navigation">
      <div
        ref={drawerRef}
        className="sidebar-module__9SB1EG__mobileDrawer"
        tabIndex={-1}
        style={{ display: "flex", flexDirection: "column", background: "var(--fl-page)" }}
      >
        <div className="sidebar-module__9SB1EG__mobileDrawerHeader">
          <span>
            <small style={{ color: "var(--fl-ink-3)" }}>Switzauth</small>
            <strong style={{ textTransform: "capitalize" }}>{sectionLabel}</strong>
          </span>
          <button
            type="button"
            className="sidebar-module__9SB1EG__mobileClose"
            aria-label="Close workspace navigation"
            onClick={onClose}
          >
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>
        <nav
          aria-label="Workspace navigation"
          style={{ display: "grid", gap: 4, overflowY: "auto", paddingTop: 12 }}
        >
          {items.map((item) => {
            const active = item.view === activeView;
            return (
              <button
                key={item.label}
                type="button"
                className={
                  active
                    ? "sidebar-module__9SB1EG__link sidebar-module__9SB1EG__linkActive"
                    : "sidebar-module__9SB1EG__link"
                }
                aria-current={active ? "page" : undefined}
                aria-label={item.label}
                disabled={!item.enabled}
                onClick={() => {
                  if (!item.enabled || !item.view) return;
                  onNavigate(item.view);
                  onClose();
                }}
                style={{ width: "100%", opacity: item.enabled ? 1 : 0.45, cursor: item.enabled ? "pointer" : "not-allowed" }}
              >
                {active ? (
                  <span className="sidebar-module__9SB1EG__activeSurface" aria-hidden="true" />
                ) : null}
                <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                  {item.icon}
                </span>
                <span className="sidebar-module__9SB1EG__linkLabel">{item.label}</span>
              </button>
            );
          })}
          <span className="enhanced-sidebar-module__5H-W0q__divider" aria-hidden="true" />
          <button
            type="button"
            className="sidebar-module__9SB1EG__link enhanced-sidebar-module__5H-W0q__logout"
            aria-label="Log out"
            onClick={() => {
              onLogout();
              onClose();
            }}
            style={{ width: "100%" }}
          >
            <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="m16 17 5-5-5-5M21 12H9M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              </svg>
            </span>
            <span className="sidebar-module__9SB1EG__linkLabel">Log out</span>
          </button>
        </nav>
      </div>
      <button
        type="button"
        className="sidebar-module__9SB1EG__mobileBackdrop"
        aria-label="Close workspace navigation"
        onClick={onClose}
      />
    </div>
  );
}
