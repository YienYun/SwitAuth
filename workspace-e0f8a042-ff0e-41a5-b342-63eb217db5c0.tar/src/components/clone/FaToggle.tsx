"use client";

/**
 * Shared port of the design-system Toggle (compiled module 7087 in
 * 0uywnoa6t3qjm.js). DOM contract is identical to the original so the ported
 * `fa-toggle` + `toggle-module__BAu5xq__*` classes in theme.css render
 * untouched: an optional visible label, the switch input with role="switch",
 * and the track/thumb/cap stack. Extracted here so the project-config modal
 * and the reward settings panel share one implementation.
 */
export default function FaToggle({
  id,
  checked,
  onChange,
  size = "md",
  disabled,
  label,
  showLabel,
}: {
  id: string;
  checked: boolean;
  onChange: (next: boolean) => void;
  size?: "sm" | "md";
  disabled?: boolean;
  label: string;
  showLabel?: string;
}) {
  return (
    <span
      className="fa-toggle toggle-module__BAu5xq__root"
      data-toggle-size={size}
      data-disabled={disabled || undefined}
    >
      <input
        id={id}
        type="checkbox"
        role="switch"
        className="fa-toggle-input toggle-module__BAu5xq__input"
        checked={checked}
        disabled={disabled}
        onChange={(event) => onChange(event.target.checked)}
        aria-label={label}
      />
      <span className="toggle-module__BAu5xq__track" data-toggle-track="true" aria-hidden="true">
        <span className="toggle-module__BAu5xq__thumb" data-toggle-thumb="true">
          <span className="toggle-module__BAu5xq__cap" />
        </span>
      </span>
      {showLabel ? (
        <span className="fa-toggle-text toggle-module__BAu5xq__text">
          <span className="fa-toggle-label">{showLabel}</span>
        </span>
      ) : null}
    </span>
  );
}
