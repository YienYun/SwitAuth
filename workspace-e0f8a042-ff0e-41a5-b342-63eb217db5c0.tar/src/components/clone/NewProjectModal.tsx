"use client";

import { useState } from "react";

export default function NewProjectModal({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState("");
  const canCreate = name.trim().length > 0;

  return (
    <>
      <div className="ui-dialog-overlay" onClick={onClose} aria-hidden="true" />
      <div
        className="ui-dialog-content"
        role="dialog"
        aria-modal="true"
        aria-labelledby="new-project-title"
        style={{
          width: "min(480px, calc(100vw - 32px))",
          background: "var(--fl-surface)",
          color: "var(--fl-ink)",
          border: "1px solid var(--fl-line)",
          padding: 0,
        }}
      >
        <button type="button" className="ui-dialog-close" aria-label="Close" onClick={onClose} style={{ zIndex: 2 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </button>

        <header style={{ padding: "20px 22px 4px" }}>
          <h2 id="new-project-title" style={{ margin: 0, font: "600 16px var(--fl-sans)", color: "var(--fl-ink)" }}>
            New project
          </h2>
          <p style={{ margin: "4px 0 0", font: "500 13px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
            Group a loader, its scripts, keys, and analytics under one workspace.
          </p>
        </header>

        <div style={{ padding: "14px 22px 4px" }}>
          <label
            htmlFor="new-project-name"
            style={{ display: "block", font: "600 12.5px var(--fl-sans)", color: "var(--fl-ink-2)", marginBottom: 6 }}
          >
            Project name
          </label>
          <input
            id="new-project-name"
            autoFocus
            placeholder="e.g. BloxFruits Hub"
            value={name}
            onChange={(event) => setName(event.target.value)}
            style={{
              width: "100%",
              height: 40,
              border: "1px solid var(--fl-line-2)",
              borderRadius: 10,
              background: "var(--fl-surface)",
              color: "var(--fl-ink)",
              padding: "0 12px",
              font: "500 14px var(--fl-sans)",
              outline: "none",
            }}
          />
          <p style={{ margin: "8px 2px 0", font: "500 12px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
            Free plan: 25 projects, 100 keys, 1,000 Centurion obfuscations a month.
          </p>
        </div>

        <footer style={{ display: "flex", justifyContent: "flex-end", gap: 10, padding: "16px 22px 20px" }}>
          <button
            type="button"
            onClick={onClose}
            style={{
              border: "1px solid var(--fl-line-2)",
              borderRadius: 10,
              background: "var(--fl-surface)",
              color: "var(--fl-ink)",
              font: "600 13.5px var(--fl-sans)",
              padding: "0 14px",
              height: 36,
              cursor: "pointer",
            }}
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!canCreate}
            onClick={onClose}
            style={{
              border: "1px solid var(--fl-btn)",
              borderRadius: 10,
              background: canCreate ? "var(--fl-btn)" : "var(--fl-inset)",
              color: canCreate ? "#fff" : "var(--fl-ink-3)",
              font: "600 13.5px var(--fl-sans)",
              padding: "0 14px",
              height: 36,
              cursor: canCreate ? "pointer" : "not-allowed",
              opacity: canCreate ? 1 : 0.7,
            }}
          >
            Create project
          </button>
        </footer>
      </div>
    </>
  );
}
