"use client";

import { useMemo, useState } from "react";

/**
 * "Add provider option" modal — replicated 1:1 from the extracted reference
 * screenshot (add provider.png / provider.png) using the site's own design
 * tokens and the same ui-dialog classes as the other ported modals.
 */

const inputStyle: React.CSSProperties = {
  width: "100%",
  height: 40,
  border: "1px solid var(--fl-line-2)",
  borderRadius: 10,
  background: "var(--fl-surface)",
  color: "var(--fl-ink)",
  padding: "0 12px",
  font: "500 14px var(--fl-sans)",
  outline: "none",
};

const labelStyle: React.CSSProperties = {
  display: "block",
  font: "600 12.5px var(--fl-sans)",
  color: "var(--fl-ink-2)",
  marginBottom: 6,
};

const PROVIDERS = ["Work.ink", "LootLabs", "LinkUnlocker", "Linkvertise"] as const;

export default function AddProviderModal({
  onClose,
  onCreate,
}: {
  onClose: () => void;
  onCreate: (name: string, provider: string) => void;
}) {
  const [stepName, setStepName] = useState("Reward step 1");
  const [provider, setProvider] = useState<string>(PROVIDERS[0]);
  const [apiKey, setApiKey] = useState("");
  const [existing, setExisting] = useState("");

  const canCreate = useMemo(
    () => apiKey.trim().length > 0 || existing.trim().length > 0,
    [apiKey, existing],
  );

  return (
    <>
      <div className="ui-dialog-overlay" onClick={onClose} aria-hidden="true" />
      <div
        className="ui-dialog-content"
        role="dialog"
        aria-modal="true"
        aria-labelledby="add-provider-title"
        style={{
          width: "min(540px, calc(100vw - 32px))",
          maxHeight: "min(780px, calc(100vh - 48px))",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          background: "var(--fl-surface)",
          color: "var(--fl-ink)",
          border: "1px solid var(--fl-line)",
          padding: 0,
        }}
      >
        <button
          type="button"
          className="ui-dialog-close"
          aria-label="Close"
          onClick={onClose}
          style={{
            zIndex: 2,
            top: 14,
            right: 14,
            width: 30,
            height: 30,
            borderRadius: 9,
            border: "1px solid var(--fl-line)",
            background: "var(--fl-surface)",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            color: "var(--fl-ink-2)",
            cursor: "pointer",
          }}
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </button>

        <header style={{ padding: "20px 22px 14px" }}>
          <h2 id="add-provider-title" style={{ margin: 0, font: "600 16px var(--fl-sans)", color: "var(--fl-ink)" }}>
            Add provider option
          </h2>
          <p style={{ margin: "3px 0 0", font: "500 13px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
            Choose a provider and connect it. Switzauth handles secure returns and progress.
          </p>
        </header>

        <div style={{ overflowY: "auto", padding: "0 22px 6px" }}>
          <div style={{ marginBottom: 14 }}>
            <label style={labelStyle} htmlFor="provider-steps-count">Required steps in this option</label>
            <select
              id="provider-steps-count"
              style={{ ...inputStyle, appearance: "none", cursor: "pointer" }}
              defaultValue="1 reward step"
            >
              <option>1 reward step</option>
              <option>2 reward steps</option>
              <option>3 reward steps</option>
            </select>
          </div>

          <section
            style={{
              border: "1px solid var(--fl-line)",
              borderRadius: 12,
              padding: 16,
              background: "var(--fl-surface)",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={{ font: "500 11px var(--fl-sans)", color: "var(--fl-ink-3)" }}>Step 1</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 5, font: "500 11px var(--fl-sans)", color: "var(--fl-ink-2)" }}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
                  <path d="m9 12 2 2 4-4" />
                </svg>
                Secure setup
              </span>
            </div>
            <h3 style={{ margin: "2px 0 14px", font: "600 15px var(--fl-sans)", color: "var(--fl-ink)" }}>
              {stepName.trim() || "Reward step 1"}
            </h3>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <div>
                <label style={labelStyle} htmlFor="provider-step-name">Step name</label>
                <input
                  id="provider-step-name"
                  style={inputStyle}
                  value={stepName}
                  onChange={(event) => setStepName(event.target.value)}
                />
                <p style={{ margin: "6px 2px 0", font: "500 11.5px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
                  Shown to users in the reward gateway.
                </p>
              </div>
              <div>
                <label style={labelStyle} htmlFor="provider-step-provider">Provider</label>
                <select
                  id="provider-step-provider"
                  style={{ ...inputStyle, appearance: "none", cursor: "pointer" }}
                  value={provider}
                  onChange={(event) => setProvider(event.target.value)}
                >
                  {PROVIDERS.map((p) => (
                    <option key={p}>{p}</option>
                  ))}
                </select>
                <p style={{ margin: "6px 2px 0", font: "500 11.5px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
                  Switzauth verifies every provider return.
                </p>
              </div>
            </div>

            <div
              style={{
                marginTop: 14,
                border: "1px solid var(--fl-line)",
                borderRadius: 10,
                padding: 14,
                background: "var(--fl-inset)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
                <span
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    width: 28,
                    height: 28,
                    borderRadius: 8,
                    background: "color-mix(in srgb, var(--fl-violet) 12%, transparent)",
                    color: "var(--fl-violet)",
                    flex: "none",
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
                  </svg>
                </span>
                <span style={{ font: "600 12.5px var(--fl-sans)", color: "var(--fl-ink)" }}>Automatic setup</span>
                <a
                  href="https://work.ink/"
                  target="_blank"
                  rel="noreferrer"
                  style={{ marginLeft: "auto", font: "500 12px var(--fl-sans)", color: "var(--fl-violet)", textDecoration: "none" }}
                >
                  Open {provider} ↗
                </a>
              </div>
              <p style={{ margin: "10px 0 0", font: "600 13px var(--fl-sans)", color: "var(--fl-ink)" }}>
                Paste one API key. Switzauth handles the rest.
              </p>
              <p style={{ margin: "4px 0 0", font: "500 12.5px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
                Switzauth creates one reusable link and safely overrides the destination for each visitor.
              </p>
            </div>

            <div style={{ marginTop: 14 }}>
              <label style={labelStyle} htmlFor={`provider-api-key`}>{provider} API key</label>
              <input
                id="provider-api-key"
                style={inputStyle}
                type="password"
                placeholder="Paste API key"
                value={apiKey}
                onChange={(event) => setApiKey(event.target.value)}
              />
              <p style={{ margin: "6px 2px 0", font: "500 11.5px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
                Developer Tools → LinkAPI → API Keys. Stored encrypted.
              </p>
            </div>

            <div style={{ borderTop: "1px solid var(--fl-line)", margin: "14px 0 0", paddingTop: 12 }}>
              <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
                {["Create provider link", "Bind its Link ID", "Override each return"].map((label, i) => (
                  <span key={label} style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                    <span
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        width: 17,
                        height: 17,
                        borderRadius: 6,
                        background: "color-mix(in srgb, var(--fl-violet) 14%, transparent)",
                        color: "var(--fl-violet)",
                        font: "600 10.5px var(--fl-sans)",
                      }}
                    >
                      {i + 1}
                    </span>
                    <span style={{ font: "500 11.5px var(--fl-sans)", color: "var(--fl-ink-2)" }}>{label}</span>
                  </span>
                ))}
              </div>

              <details style={{ marginTop: 12 }}>
                <summary
                  style={{
                    cursor: "pointer",
                    font: "500 12.5px var(--fl-sans)",
                    color: "var(--fl-ink-2)",
                    width: "fit-content",
                    listStyle: "revert",
                  }}
                >
                  Use an existing {provider} link instead
                </summary>
                <div style={{ marginTop: 10 }}>
                  <input
                    style={inputStyle}
                    type="text"
                    placeholder={`Paste your ${provider} link`}
                    value={existing}
                    onChange={(event) => setExisting(event.target.value)}
                    aria-label={`Existing ${provider} link`}
                  />
                  <p style={{ margin: "6px 2px 0", font: "500 11.5px var(--fl-sans)", color: "var(--fl-ink-3)" }}>
                    We will bind this link instead of creating a new one.
                  </p>
                </div>
              </details>
            </div>
          </section>
        </div>

        <footer style={{ display: "flex", justifyContent: "flex-end", gap: 10, padding: "14px 22px 18px" }}>
          <button
            type="button"
            className="flow-btn flow-btn-secondary flow-btn-md"
            onClick={onClose}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content"><span className="flow-btn-label">Cancel</span></span>
          </button>
          <button
            type="button"
            className="flow-btn flow-btn-primary flow-btn-md"
            disabled={!canCreate}
            onClick={() => onCreate(stepName.trim() || "Reward step 1", provider)}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content"><span className="flow-btn-label">Create step</span></span>
          </button>
        </footer>
      </div>
    </>
  );
}
