"use client";

import { useEffect, useId, useRef, useState } from "react";
import { Check, Copy } from "lucide-react";
import WorkspaceShell from "./WorkspaceShell";

/**
 * Decompiler workspace — direct port of the decompiled `DecompilerWorkspace`
 * component (chunk 2ikq8md26yrw4.js module 596), styled by the ported
 * decompiler-workspace-module__Y4ANUa__* CSS. The executor setup command is
 * the decompiled string with the API host brand-swapped to switzauth.net, and
 * the "Check service" probe pings this deployment's own API route.
 */

const SETUP_COMMAND = 'return loadstring(game:HttpGet("https://api.switzauth.net/connector"))()';

const DIRECT_EXAMPLE =
  'local target = game:GetService("Players").LocalPlayer.PlayerScripts:FindFirstChild("LocalScript")\n' +
  "local source = getgenv().LuauDecompiler:Decompile(target)\n" +
  "print(source)";

type ServiceState = "idle" | "checking" | "online" | "offline";

export default function DecompilerBody() {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState("");
  const [disclosureOpen, setDisclosureOpen] = useState(false);
  const [service, setService] = useState<ServiceState>("idle");
  const mounted = useRef(true);
  const copyTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const uid = useId().replace(/:/g, "");

  useEffect(
    () => () => {
      mounted.current = false;
      if (copyTimer.current) clearTimeout(copyTimer.current);
      abortRef.current?.abort();
    },
    [],
  );

  const copySetup = async () => {
    try {
      await navigator.clipboard.writeText(SETUP_COMMAND);
      if (!mounted.current) return;
      setCopyError("");
      setCopied(true);
      if (copyTimer.current) clearTimeout(copyTimer.current);
      copyTimer.current = setTimeout(() => setCopied(false), 1800);
    } catch {
      if (mounted.current) {
        setCopyError("Couldn’t copy automatically. Select the command below and copy it manually.");
      }
    }
  };

  const checkService = async () => {
    if (abortRef.current) return;
    const controller = new AbortController();
    abortRef.current = controller;
    setService("checking");
    const timeout = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch("/api/v1/public/executions", { signal: controller.signal });
      if (mounted.current) setService(response.ok ? "online" : "offline");
    } catch {
      if (mounted.current) setService("offline");
    } finally {
      clearTimeout(timeout);
      abortRef.current = null;
    }
  };

  const statusText =
    service === "online"
      ? "Service is reachable from this browser"
      : service === "offline"
        ? "Couldn’t reach the service. Try again."
        : service === "checking"
          ? "Checking service…"
          : "Having trouble connecting?";

  return (
    <WorkspaceShell active="Decompiler" crumb="Decompiler" tab="decompiler">
      <div className="decompiler-workspace-module__Y4ANUa__root">
      <header className="decompiler-workspace-module__Y4ANUa__heading">
        <h1>Decompiler</h1>
        <p>Connect your executor, then open a script in Dex to read its Luau source.</p>
      </header>

      <section className="decompiler-workspace-module__Y4ANUa__setup" aria-labelledby={`${uid}-title`}>
        <div className="decompiler-workspace-module__Y4ANUa__intro">
          <div className="decompiler-workspace-module__Y4ANUa__titleGroup">
            <span className="decompiler-workspace-module__Y4ANUa__mark" aria-hidden="true">
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="4 17 10 11 4 5" />
                <line x1="12" x2="20" y1="19" y2="19" />
              </svg>
            </span>
            <div>
              <h2 id={`${uid}-title`}>Connect your executor</h2>
              <p>Copy this command and run it in your executor.</p>
            </div>
          </div>
          <button type="button" className="decompiler-workspace-module__Y4ANUa__copyButton" onClick={() => void copySetup()}>
            <span className="decompiler-workspace-module__Y4ANUa__copyIcon" aria-hidden="true">
              {copied ? <Check size={16} /> : <Copy size={16} />}
            </span>
            <span aria-live="polite">{copied ? "Copied" : "Copy setup script"}</span>
          </button>
        </div>

        {copyError ? (
          <p className="decompiler-workspace-module__Y4ANUa__error" role="alert">
            {copyError}
          </p>
        ) : null}

        <div className="decompiler-workspace-module__Y4ANUa__command">
          <div className="decompiler-workspace-module__Y4ANUa__codeLabel">
            <span>Setup command</span>
            <span>Luau</span>
          </div>
          <pre tabIndex={0} aria-label="Executor setup command">
            <code>{SETUP_COMMAND}</code>
          </pre>
        </div>

        <ol className="decompiler-workspace-module__Y4ANUa__steps" aria-label="Setup instructions">
          <li>
            <span className="decompiler-workspace-module__Y4ANUa__number">1</span>
            <div>
              <h3>Copy the script</h3>
              <p>Use the button above.</p>
            </div>
          </li>
          <li>
            <span className="decompiler-workspace-module__Y4ANUa__number">2</span>
            <div>
              <h3>Run it in your executor</h3>
              <p>Do this when you join a new session.</p>
            </div>
          </li>
          <li>
            <span className="decompiler-workspace-module__Y4ANUa__number">3</span>
            <div>
              <h3>Open a script in Dex</h3>
              <p>Already open? Close and reopen it to refresh the source.</p>
            </div>
          </li>
        </ol>
      </section>

      <section className="decompiler-workspace-module__Y4ANUa__help">
        <button
          type="button"
          className="decompiler-workspace-module__Y4ANUa__disclosure"
          aria-expanded={disclosureOpen}
          aria-controls={`${uid}-reveal`}
          onClick={() => setDisclosureOpen((open) => !open)}
        >
          <span>
            Using a different script viewer?
            <small>Call the decompiler directly after setup.</small>
          </span>
          <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="decompiler-workspace-module__Y4ANUa__chevron"
            data-open={disclosureOpen}
            aria-hidden="true"
          >
            <path d="m6 9 6 6 6-6" />
          </svg>
        </button>
        <div
          className="decompiler-workspace-module__Y4ANUa__reveal"
          data-open={disclosureOpen}
          id={`${uid}-reveal`}
        >
          <div className="decompiler-workspace-module__Y4ANUa__revealInner">
            <div className="decompiler-workspace-module__Y4ANUa__example">
              <p>
                Replace <code>target</code> with the LocalScript or ModuleScript you want to
                inspect.
              </p>
              <pre tabIndex={0} aria-label="Direct decompiler example">
                <code>{DIRECT_EXAMPLE}</code>
              </pre>
            </div>
          </div>
        </div>
      </section>

      <footer className="decompiler-workspace-module__Y4ANUa__footer">
        <div className="decompiler-workspace-module__Y4ANUa__service">
          <span className="decompiler-workspace-module__Y4ANUa__statusDot" data-status={service} aria-hidden="true" />
          <p role="status">{statusText}</p>
          <button
            type="button"
            className="decompiler-workspace-module__Y4ANUa__textButton"
            onClick={() => void checkService()}
            disabled={service === "checking"}
          >
            {service === "checking" ? "Checking" : "Check service"}
          </button>
        </div>
        <a href="/docs" className="decompiler-workspace-module__Y4ANUa__docsLink">
          Documentation{" "}
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M7 7h10v10" />
            <path d="M7 17 17 7" />
          </svg>
        </a>
      </footer>
      </div>
    </WorkspaceShell>
  );
}
