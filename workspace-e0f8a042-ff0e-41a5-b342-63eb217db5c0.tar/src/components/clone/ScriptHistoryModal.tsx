"use client";

import { useEffect, useMemo, useState } from "react";
import { Check, Clock3, Star, X } from "lucide-react";

/**
 * "Script history" dialog — port of the decompiled `tP` component in chunk
 * 3k6a5lhrkscp5.js (Projects page → script row "Version history" button;
 * visual reference: script history.png). Uses the extracted
 * script-history-module__VDKorW__* styles (ported CSS). Decompiled contract:
 * overview strip (Running now / Available), All versions ⇄ Saved filter,
 * per-version star (keep) + Restore with inline confirm, and the
 * "30 recent · up to 5 saved" footer.
 */

interface ScriptVersion {
  version: number;
  createdLabel: string;
  sizeLabel: string;
  current: boolean;
  stable: boolean;
  restoredFrom?: number;
}

interface HistoryPayload {
  versions: ScriptVersion[];
  current_version: number;
  history_limit: number;
  stable_limit: number;
}

const STORAGE_KEY = "switzauth-history-v1";

const DEFAULT_HISTORY: HistoryPayload = {
  current_version: 1,
  history_limit: 30,
  stable_limit: 5,
  versions: [
    {
      version: 1,
      createdLabel: new Date("2026-09-27T17:00:00").toLocaleString("en-GB", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
      sizeLabel: "13 B",
      current: true,
      stable: false,
    },
  ],
};

function loadHistory(): HistoryPayload {
  if (typeof window === "undefined") return DEFAULT_HISTORY;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULT_HISTORY, ...JSON.parse(raw) } : DEFAULT_HISTORY;
  } catch {
    return DEFAULT_HISTORY;
  }
}

export default function ScriptHistoryModal({
  scriptName,
  onClose,
}: {
  scriptName: string;
  onClose: () => void;
}) {
  // Decompiled parity: the modal fetches version history on open. The lazy
  // initializer reads localStorage (hydration-safe: the dialog only mounts
  // client-side from the projects view).
  const [history, setHistory] = useState<HistoryPayload>(() => loadHistory());
  const [filter, setFilter] = useState<"all" | "saved">("all");
  const [confirming, setConfirming] = useState<number | null>(null);
  const [notice, setNotice] = useState("");

  // Escape closes panels first (confirm), then the dialog — decompiled parity.
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      event.stopPropagation();
      event.preventDefault();
      if (confirming !== null) {
        setConfirming(null);
        return;
      }
      onClose();
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [confirming, onClose]);

  const persist = (next: HistoryPayload) => {
    setHistory(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* storage unavailable */
    }
  };

  const visible = useMemo(
    () => history.versions.filter((version) => filter === "all" || version.stable),
    [history.versions, filter],
  );
  const savedCount = history.versions.filter((version) => version.stable).length;

  const toggleStar = (version: ScriptVersion) => {
    if (version.stable && savedCount >= history.stable_limit) return;
    persist({
      ...history,
      versions: history.versions.map((item) =>
        item.version === version.version ? { ...item, stable: !item.stable } : item,
      ),
    });
  };

  const restore = (version: ScriptVersion) => {
    const nextNumber = history.current_version + 1;
    const restored: ScriptVersion = {
      ...version,
      version: nextNumber,
      current: true,
      restoredFrom: version.version,
      createdLabel: new Date().toLocaleString("en-GB", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }),
    };
    persist({
      ...history,
      current_version: nextNumber,
      versions: [
        restored,
        ...history.versions.map((item) => ({ ...item, current: false })),
      ],
    });
    setConfirming(null);
    setNotice(
      `Version ${restored.version} restored as version ${nextNumber}. The loader URL is unchanged.`,
    );
    setTimeout(() => setNotice(""), 4200);
  };

  return (
    <>
      <div className="script-history-module__VDKorW__overlay" data-state="open" onClick={onClose} aria-hidden="true" />
      <div
        className="script-history-module__VDKorW__dialog"
        data-state="open"
        role="dialog"
        aria-modal="true"
        aria-label={`Script history for ${scriptName}`}
      >
        <header className="script-history-module__VDKorW__header">
          <div className="script-history-module__VDKorW__heading">
            <span className="script-history-module__VDKorW__eyebrow">
              <Clock3 size={13} aria-hidden="true" /> Script history
            </span>
            <h2 id="script-history-title" className="script-history-module__VDKorW__title">
              {scriptName}
            </h2>
            <p className="script-history-module__VDKorW__description">
              Restore a published build. Keep the same loader.
            </p>
          </div>
          <button
            type="button"
            className="script-history-module__VDKorW__close"
            aria-label="Close version history"
            onClick={onClose}
          >
            <X size={18} aria-hidden="true" />
          </button>
        </header>
        <div className="script-history-module__VDKorW__body">
          {notice ? (
            <div className="script-history-module__VDKorW__notice" role="status">
              <Check size={16} aria-hidden="true" />
              {notice}
            </div>
          ) : null}
          <div className="script-history-module__VDKorW__overview">
            <div>
              <span>Running now</span>
              <strong>Version {history.current_version}</strong>
            </div>
            <div>
              <span>Available</span>
              <strong>
                {history.versions.length} {history.versions.length === 1 ? "build" : "builds"}
              </strong>
            </div>
          </div>
          <div className="script-history-module__VDKorW__toolbar" aria-label="Filter versions">
            <button
              type="button"
              aria-pressed={filter === "all"}
              onClick={() => setFilter("all")}
            >
              All versions
            </button>
            <button
              type="button"
              aria-pressed={filter === "saved"}
              onClick={() => setFilter("saved")}
            >
              <Star size={13} aria-hidden="true" /> Saved <span>{savedCount}</span>
            </button>
            <span className="script-history-module__VDKorW__latest">Newest first</span>
          </div>
          <ol className="script-history-module__VDKorW__versions" aria-label="Published versions">
            {visible.map((version) => (
              <li
                key={version.version}
                className="script-history-module__VDKorW__version"
                data-current={version.current || undefined}
              >
                <div className="script-history-module__VDKorW__versionRow">
                  <span className="script-history-module__VDKorW__mark" aria-hidden="true">
                    {version.current ? <Check size={16} aria-hidden="true" /> : <Clock3 size={16} aria-hidden="true" />}
                  </span>
                  <div className="script-history-module__VDKorW__details">
                    <div>
                      <strong>Version {version.version}</strong>
                      {version.current ? (
                        <span className="script-history-module__VDKorW__current">Current</span>
                      ) : null}
                      {version.stable ? (
                        <span className="script-history-module__VDKorW__saved">Saved</span>
                      ) : null}
                    </div>
                    <time>
                      {version.createdLabel}
                      <span> · {version.sizeLabel}</span>
                    </time>
                    {version.restoredFrom ? (
                      <small>Restored from version {version.restoredFrom}</small>
                    ) : null}
                  </div>
                  <div className="script-history-module__VDKorW__actions">
                    <button
                      type="button"
                      className="script-history-module__VDKorW__star"
                      aria-pressed={version.stable}
                      aria-label={`${version.stable ? "Unsave" : "Save"} version ${version.version}`}
                      title={version.stable ? "Remove from saved versions" : "Keep this version"}
                      onClick={() => toggleStar(version)}
                    >
                      <Star size={16} fill={version.stable ? "currentColor" : "none"} aria-hidden="true" />
                    </button>
                    {!version.current ? (
                      <button
                        type="button"
                        className="script-history-module__VDKorW__restore"
                        onClick={() => setConfirming(version.version)}
                      >
                        Restore
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                          <path d="M7 7h10v10" />
                          <path d="M7 17 17 7" />
                        </svg>
                        <span className="script-history-module__VDKorW__srOnly">
                          {" "}
                          version {version.version}
                        </span>
                      </button>
                    ) : null}
                  </div>
                </div>
                {confirming === version.version ? (
                  <div className="script-history-module__VDKorW__confirm">
                    <strong>Restore version {version.version}?</strong>
                    <p>
                      This publishes a new version from this build. Your current build stays in
                      history. Access settings and targeting stay the same.
                    </p>
                    <div>
                      <button type="button" onClick={() => setConfirming(null)}>
                        Cancel
                      </button>
                      <button
                        type="button"
                        className="script-history-module__VDKorW__confirmRestore"
                        onClick={() => restore(version)}
                      >
                        Restore version {version.version}
                      </button>
                    </div>
                  </div>
                ) : null}
              </li>
            ))}
          </ol>
          {visible.length === 0 ? (
            <div className="script-history-module__VDKorW__empty">
              <Star size={20} aria-hidden="true" />
              <strong>No saved versions</strong>
              <p>Star a version to keep it in your history.</p>
            </div>
          ) : null}
          {history.versions.length === 1 && filter === "all" ? (
            <p className="script-history-module__VDKorW__firstBuild">
              Your next publish will appear here. Save a version when you want to keep it.
            </p>
          ) : null}
        </div>
        <footer className="script-history-module__VDKorW__footer">
          <span>Current and previous builds are kept.</span>
          <span>
            {history.history_limit} recent · up to {history.stable_limit} saved
          </span>
        </footer>
      </div>
    </>
  );
}
