"use client";

import { useMemo, useState } from "react";
import FlowModal from "./FlowModal";

/**
 * "Rename loader URL" dialog — port of the decompiled modal (chunk
 * 3k6a5lhrkscp5.js) that the Projects page "Rename main loader" button opens.
 * Uses the original fa-modal system plus the extracted
 * `loader-name-dialog-module__wX3Pfa__*` classes (app.css) and the design
 * system's fa-field input. All copy is the decompiled text (brand-swapped).
 *
 * Decompiled validation: an empty field is VALID (it means "use the generated
 * name" — the submit sends loader_name:null and the server mints a fresh
 * hash); otherwise the slug must start with a letter, be 3–64 chars, and must
 * not look like a 32-hex system hash.
 */

const projectName = "jh9iu";
const currentLoader = "7fce8b6fd0f03dabbe718d52441c2e9f";

/** Decompiled normalization: slugify, force letter start, pad short/hex names. */
function normalizeLoaderName(raw: string): string {
  let name = raw
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^A-Za-z0-9_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
  if (!/^[A-Za-z]/.test(name)) name = `Loader-${name}`;
  if (name.length < 3 || /^[a-f0-9]{32}$/i.test(name)) name += "-Loader";
  return name.slice(0, 64);
}

export default function RenameLoaderModal({
  onClose,
  onSave,
}: {
  onClose: () => void;
  onSave: (loaderName: string) => void;
}) {
  // The decompiled modal opens with the custom loader name if one is set —
  // otherwise empty ("use generated name"). Our loader has no custom name.
  const [value, setValue] = useState("");
  const [saving, setSaving] = useState(false);

  const { valid, error } = useMemo(() => {
    const p = value.trim().replace(/\.lua$/i, "");
    const ok =
      p === "" ||
      (/^[A-Za-z][A-Za-z0-9_-]{2,63}$/.test(p) && !/^[a-f0-9]{32}$/i.test(p));
    return { valid: ok, error: ok ? null : "Choose a valid name using the rules above." };
  }, [value]);
  const preview = `${value.trim().replace(/\.lua$/i, "") || currentLoader}.lua`;

  const submit = () => {
    if (!valid || saving) return;
    setSaving(true);
    // Simulated request latency, then apply (single-tenant clone).
    setTimeout(() => {
      setSaving(false);
      onSave(value.trim().replace(/\.lua$/i, ""));
    }, 420);
  };

  return (
    <FlowModal
      onClose={onClose}
      title="Rename loader URL"
      eyebrow="Main project loader"
      size="md"
      labelledBy="fa-modal-title"
      footer={
        <div className="loader-name-dialog-module__wX3Pfa__actions">
          <button
            type="button"
            className="flow-btn flow-btn-secondary flow-btn-md"
            onClick={onClose}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content"><span className="flow-btn-label">Cancel</span></span>
          </button>
          <button
            type="button"
            className="flow-btn flow-btn-primary flow-btn-md"
            disabled={saving || !valid}
            onClick={submit}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content">
              <span className="flow-btn-label">{saving ? "Saving…" : "Save loader name"}</span>
            </span>
          </button>
        </div>
      }
    >
      <form
        className="loader-name-dialog-module__wX3Pfa__form"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        <div className={`fa-field${error ? " fa-field-error" : ""}`}>
          <div className="fa-field-frame">
            <input
              id="loader-name-input"
              className="fa-field-input"
              placeholder=" "
              value={value}
              maxLength={68}
              data-autofocus
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              aria-invalid={Boolean(error) || undefined}
              onChange={(event) => setValue(event.target.value)}
            />
            <label className="fa-field-label" htmlFor="loader-name-input">
              Lua filename
            </label>
            <span className="fa-field-charge" aria-hidden="true" />
          </div>
          <span className={`fa-field-msg${error ? " fa-field-msg-error" : ""}`}>
            {error ??
              "3–64 characters. Start with a letter; use letters, numbers, hyphens or underscores. .lua is added automatically."}
          </span>
        </div>

        <div className="loader-name-dialog-module__wX3Pfa__helpers">
          <button
            type="button"
            className="flow-btn flow-btn-secondary flow-btn-sm"
            onClick={() => setValue(normalizeLoaderName(projectName))}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content"><span className="flow-btn-label">Use project name</span></span>
          </button>
          <button
            type="button"
            className="flow-btn flow-btn-secondary flow-btn-sm"
            onClick={() => setValue("")}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content"><span className="flow-btn-label">Use generated name</span></span>
          </button>
        </div>

        <code className="loader-name-dialog-module__wX3Pfa__preview">{preview}</code>
        <p className="loader-name-dialog-module__wX3Pfa__hint">
          Names are unique across Switzauth, ignoring capitalization. Existing links keep working
          after a rename. Each loader can reserve up to 50 custom names.
        </p>
        {error ? (
          <p className="loader-name-dialog-module__wX3Pfa__error" role="alert">
            {error}
          </p>
        ) : null}
      </form>
    </FlowModal>
  );
}
