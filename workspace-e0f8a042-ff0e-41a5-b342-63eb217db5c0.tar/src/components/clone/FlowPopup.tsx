"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import FlowModal from "./FlowModal";

/**
 * Port of the original useFlowPopup hook (compiled chunk 0uywnoa6t3qjm.js,
 * module 88764). Promise-based confirm/notice dialogs rendered through the
 * fa-modal system with the site's own fa-popup classes:
 *   askConfirm(message, {title, confirmLabel, cancelLabel}) → Promise<boolean>
 *   showNotice(message, {title, tone, confirmLabel})
 * Default titles come from the decompiled map (brand word swapped):
 *   default → "Switzauth", danger → "Confirm action",
 *   success → "Success",  warning → "Notice".
 */

type Tone = "default" | "danger" | "success" | "warning";

interface PopupSpec {
  type: "confirm" | "notice";
  message: string;
  title: string;
  tone: Tone;
  confirmLabel: string;
  cancelLabel?: string;
}

const DEFAULT_TITLES: Record<Tone, string> = {
  default: "Switzauth",
  danger: "Confirm action",
  success: "Success",
  warning: "Notice",
};

const TONE_ICONS: Record<Tone, React.ReactNode> = {
  default: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="10" />
      <path d="M12 16v-4" />
      <path d="M12 8h.01" />
    </svg>
  ),
  danger: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
      <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" />
      <path d="M12 9v4" />
      <path d="M12 17h.01" />
    </svg>
  ),
  success: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
      <path d="M20 6 9 17l-5-5" />
    </svg>
  ),
  warning: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
      <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" />
      <path d="M12 9v4" />
      <path d="M12 17h.01" />
    </svg>
  ),
};

export function useFlowPopup() {
  const [spec, setSpec] = useState<PopupSpec | null>(null);
  const resolver = useRef<((value: boolean) => void) | null>(null);

  const settle = useCallback((value: boolean) => {
    const resolve = resolver.current;
    resolver.current = null;
    setSpec(null);
    resolve?.(value);
  }, []);

  const open = useCallback(
    (next: PopupSpec) => {
      resolver.current?.(false);
      return new Promise<boolean>((resolve) => {
        resolver.current = resolve;
        setSpec(next);
      });
    },
    [],
  );

  const showNotice = useCallback(
    (message: string, options: { title?: string; tone?: Tone; confirmLabel?: string } = {}) =>
      open({
        type: "notice",
        message,
        title: options.title || DEFAULT_TITLES[options.tone || "default"],
        tone: options.tone || "default",
        confirmLabel: options.confirmLabel || "OK",
      }),
    [open],
  );

  const askConfirm = useCallback(
    (
      message: string,
      options: { title?: string; tone?: Tone; confirmLabel?: string; cancelLabel?: string } = {},
    ) =>
      open({
        type: "confirm",
        message,
        title: options.title || DEFAULT_TITLES[options.tone || "danger"],
        tone: options.tone || "danger",
        confirmLabel: options.confirmLabel || "Confirm",
        cancelLabel: options.cancelLabel || "Cancel",
      }),
    [open],
  );

  useEffect(() => () => resolver.current?.(false), []);

  const popupNode = useMemo(() => {
    if (!spec) return null;
    const danger = spec.tone === "danger";
    return (
      <FlowModal
        title={spec.title}
        eyebrow="Switzauth"
        tone={danger ? "danger" : "default"}
        size="sm"
        onClose={() => settle(false)}
        footer={
          <div className="fa-popup-actions">
            {spec.type === "confirm" ? (
              <button
                type="button"
                className="flow-btn flow-btn-secondary flow-btn-md"
                onClick={() => settle(false)}
              >
                <span className="flow-btn-sweep" aria-hidden="true" />
                <span className="flow-btn-content">
                  <span className="flow-btn-label">{spec.cancelLabel}</span>
                </span>
              </button>
            ) : null}
            <button
              type="button"
              className={`flow-btn flow-btn-md ${danger ? "flow-btn-danger" : "flow-btn-primary"}`}
              onClick={() => settle(true)}
            >
              <span className="flow-btn-sweep" aria-hidden="true" />
              <span className="flow-btn-content">
                <span className="flow-btn-label">{spec.confirmLabel}</span>
              </span>
            </button>
          </div>
        }
      >
        <div className={`fa-popup-message fa-popup-${spec.tone}`}>
          <span className="fa-popup-icon" aria-hidden="true">
            {TONE_ICONS[spec.tone] ?? TONE_ICONS.default}
          </span>
          <p>{spec.message}</p>
        </div>
      </FlowModal>
    );
  }, [spec, settle]);

  return { popupNode, showNotice, askConfirm };
}
