#!/usr/bin/env bash
# Full 1:1 port pipeline: scrape -> JSX -> branding -> components -> fixes
set -e
cd /home/z/my-project
declare -A PAGES=(
  ["index.html"]="LandingBody"
  ["example 2.html"]="DashboardBody"
  ["example 3.html"]="ProjectsBody"
  ["example 4.html"]="RewardsBody"
  ["example 7.html"]="ObfuscatorBody"
  ["example 14.html"]="ApiBody"
  ["example 15.html"]="McpBody"
  ["example 16.html"]="ChangelogBody"
  ["example 17.html"]="ProfileBody"
  ["example 9.html"]="DocsBody"
)
for src in "${!PAGES[@]}"; do
  python3 scripts/html2jsx.py "/tmp/extracted/${src}" "src/components/clone/${PAGES[$src]}.jsx" > /dev/null
done
python3 scripts/postfix_jsx.py src/components/clone/*.jsx > /dev/null
python3 scripts/postfix2_jsx.py src/components/clone/*.jsx > /dev/null
sed -i 's/flowauth-mobile-navigation/switzauth-mobile-navigation/g; s/{"<"}flowauth_/{"<"}switzauth_/g' src/components/clone/*.jsx
# component wrappers (skip LandingBody: Landing.tsx carries manual interactivity edits)
for name in Dashboard Projects Rewards Obfuscator Api Mcp Changelog Profile Docs; do
  {
    echo "// Auto-generated 1:1 port of scraped FlowAuth page: ${name}"
    echo "export default function ${name}Body() {"
    echo "  return ("
    cat "src/components/clone/${name}Body.jsx"
    echo "  );"
    echo "}"
  } > "src/components/clone/${name}Body.component.tsx"
done
python3 scripts/unfreeze_animations.py src/components/clone/*.component.tsx > /dev/null
python3 scripts/fix_form_props.py src/components/clone/*.component.tsx > /dev/null
echo "pipeline complete"
