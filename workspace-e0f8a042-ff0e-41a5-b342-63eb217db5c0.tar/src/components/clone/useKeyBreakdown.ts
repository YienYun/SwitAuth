"use client";

import { useEffect, useState } from "react";
import { KEYS_CHANGED_EVENT, KEYS_STORAGE_KEY } from "./useKeyCounts";

/**
 * Status breakdown of the persisted key records ("switzauth-keys-v1") —
 * drives the dashboard "Key status" rows so the overview reflects real
 * mint / pause / revoke / expire actions instead of a frozen snapshot.
 * The captured account shipped exactly one active key, so the SSR output
 * (1 active, 0 elsewhere) is identical to the scraped dashboard.
 */

export interface KeyBreakdown {
  total: number;
  active: number;
  paused: number;
  revoked: number;
  expired: number;
}

export const CAPTURED_KEY_BREAKDOWN: KeyBreakdown = {
  total: 1,
  active: 1,
  paused: 0,
  revoked: 0,
  expired: 0,
};

export function readKeyBreakdown(): KeyBreakdown {
  if (typeof window === "undefined") return CAPTURED_KEY_BREAKDOWN;
  try {
    const raw = window.localStorage.getItem(KEYS_STORAGE_KEY);
    if (!raw) return CAPTURED_KEY_BREAKDOWN;
    const records = JSON.parse(raw)?.records;
    if (!Array.isArray(records) || records.length === 0) return CAPTURED_KEY_BREAKDOWN;
    const counts = { total: records.length, active: 0, paused: 0, revoked: 0, expired: 0 };
    for (const record of records) {
      const status = record?.status;
      if (status === "active" || status === "paused" || status === "revoked" || status === "expired") {
        counts[status] += 1;
      }
    }
    return counts;
  } catch {
    return CAPTURED_KEY_BREAKDOWN;
  }
}

export function useKeyBreakdown(): KeyBreakdown {
  const [counts, setCounts] = useState<KeyBreakdown>(CAPTURED_KEY_BREAKDOWN);

  useEffect(() => {
    // Initial read deferred to a rAF (codebase pattern — avoids the
    // synchronous setState-in-effect cascade).
    const frame = requestAnimationFrame(() => setCounts(readKeyBreakdown()));
    const onStorage = (event: StorageEvent) => {
      if (!event.key || event.key === KEYS_STORAGE_KEY) setCounts(readKeyBreakdown());
    };
    const onChanged = () => setCounts(readKeyBreakdown());
    window.addEventListener("storage", onStorage);
    window.addEventListener(KEYS_CHANGED_EVENT, onChanged);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("storage", onStorage);
      window.removeEventListener(KEYS_CHANGED_EVENT, onChanged);
    };
  }, []);

  return counts;
}
