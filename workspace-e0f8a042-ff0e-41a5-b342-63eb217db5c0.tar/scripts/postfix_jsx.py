#!/usr/bin/env python3
"""Post-process generated JSX bodies: internal links, brand text, image fixes."""
import re
import sys
import glob

ATTRS_BRAND = ("aria-label", "title", "alt", "placeholder", "content", "aria-description")

def fix_file(path: str):
    src = open(path, encoding="utf-8").read()
    orig = src

    # 1. internal absolute links -> relative
    src = src.replace('href="https://flowauth.net"', 'href="/"')
    src = re.sub(r'href="https://flowauth\.net/', 'href="/', src)
    src = src.replace('href="http://flowauth.net"', 'href="/"')

    # 2. Next image optimizer -> direct asset
    def img_fix(m):
        tag = m.group(0)
        if 'src="/image"' in tag or "_next/image" in tag:
            mm = re.search(r"url=%2F([^&\"]+)", tag)
            asset = "/" + mm.group(1)
            asset = asset.replace("%3Fv%3D", "?v=").replace("flowauth-logo.png", "flowauth-logo.png")
            # decode simple %2F already handled; strip query
            asset = asset.split("?")[0]
            tag = re.sub(r'\s*srcSet="[^"]*"', "", tag)
            tag = re.sub(r'\s*src="[^"]*"', "", tag)
            tag = tag.replace("<img", '<img src="%s"' % asset, 1)
        return tag
    src = re.sub(r"<img[^>]*/>", img_fix, src)

    # 3. brand text in text nodes (outside tags). Process segments between > and <
    def seg_fix(m):
        mid = m.group(2)
        mid = mid.replace("FLOWAUTH", "SWITZAUTH").replace("FlowAuth", "Switzauth")
        return ">" + m.group(1) + mid + m.group(3) + "<"
    prev = None
    while prev != src:
        prev = src
        src = re.sub(r'>([^<>{}]*)(FLOWAUTH|FlowAuth)([^<>{}]*)<', seg_fix, src)

    # 4. brand in user-facing attributes
    for attr in ATTRS_BRAND:
        pat = re.compile(r'(%s=")([^"]*)(")' % attr)
        def a_fix(m):
            return m.group(1) + m.group(2).replace("FlowAuth", "Switzauth").replace("FLOWAUTH", "SWITZAUTH") + m.group(3)
        src = pat.sub(a_fix, src)

    if src != orig:
        open(path, "w", encoding="utf-8").write(src)
        return True
    return False

def main():
    for f in sys.argv[1:]:
        changed = fix_file(f)
        print(("fixed " if changed else "clean  ") + f)

if __name__ == "__main__":
    main()
