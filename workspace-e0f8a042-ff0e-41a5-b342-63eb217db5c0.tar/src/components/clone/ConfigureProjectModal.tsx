"use client";

import { useEffect, useMemo, useState } from "react";
import { X } from "lucide-react";
import FaSelect from "./FaSelect";
import FaToggle from "./FaToggle";
import type { ToastFn } from "./KeysBody";

/**
 * "Project settings / Manage {project}" dialog — port of the decompiled
 * config modal in chunk 3k6a5lhrkscp5.js (Projects page "Configure" button;
 * visual references: configuration 1/2/3.png). Uses the original global
 * classes (projectConfigModal, projectSettingTile, projectGroupPanel, …)
 * that ship in the ported theme.css, plus the toggle-module__BAu5xq__*
 * switch. All copy is the decompiled text.
 */

const PROJECT_NAME = "jh9iu";

interface ConfigState {
  keyless_enabled: boolean;
  hwid_reset_enabled: boolean;
  reset_cooldown_days: string;
  auto_delete_expired_keys: boolean;
  allow_hwid_key_sharing: boolean;
  instance_limit_enabled: boolean;
  max_instances: string;
  hwidless_keys: boolean;
  key_stacking_enabled: boolean;
  logs_webhook: string;
  logs_enabled: boolean;
  alert_webhook: string;
  alerts_enabled: boolean;
}

const DEFAULT_STATE: ConfigState = {
  keyless_enabled: false,
  hwid_reset_enabled: true,
  reset_cooldown_days: "1",
  auto_delete_expired_keys: false,
  allow_hwid_key_sharing: false,
  instance_limit_enabled: false,
  max_instances: "1",
  hwidless_keys: false,
  key_stacking_enabled: false,
  logs_webhook: "",
  logs_enabled: false,
  alert_webhook: "",
  alerts_enabled: false,
};

const STORAGE_KEY = "switzauth-config-v1";

// Project groups shared by the group-membership picker. The captured
// snapshot shipped zero groups ("No group", "Create a new group (0 of 10)");
// created groups persist locally so the picker, status pill, and permission
// side stay truthful across reloads.
const GROUPS_KEY = "switzauth-project-groups-v1";
const GROUP_LIMIT = 10;

function loadGroups(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(GROUPS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((g) => typeof g === "string") : [];
  } catch {
    return [];
  }
}

function loadConfig(): ConfigState {
  if (typeof window === "undefined") return DEFAULT_STATE;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULT_STATE, ...JSON.parse(raw) } : DEFAULT_STATE;
  } catch {
    return DEFAULT_STATE;
  }
}

/** The visible-label FaToggle markup moved to the shared FaToggle.tsx. */

function webhookHelper(url: string, enabled: boolean, loading: boolean): string {
  if (loading) return "Loading webhooks...";
  if (url.trim()) return "Endpoint saved. Test it from your Discord server.";
  if (enabled) return "Paste an HTTPS URL to route events.";
  return "No endpoint configured. Paste an HTTPS URL to add one.";
}

export default function ConfigureProjectModal({
  onClose,
  onToast,
}: {
  onClose: () => void;
  onToast: ToastFn;
}) {
  // The decompiled modal loads the saved config + webhooks on open; the lazy
  // initializer mirrors the saved-config read (hydration-safe: the dialog
  // only mounts client-side from the projects view).
  const [state, setState] = useState<ConfigState>(() => loadConfig());
  const [saving, setSaving] = useState(false);
  const [webhooksLoading, setWebhooksLoading] = useState(true);
  // Keyless duration picker ("Custom duration" / "Forever") — captured
  // default is Forever.
  const [keylessDuration, setKeylessDuration] = useState("forever");
  // Group membership state (see GROUPS_KEY above).
  const [groups, setGroups] = useState<string[]>(() => loadGroups());
  const [selectedGroup, setSelectedGroup] = useState("");
  const [newGroupName, setNewGroupName] = useState("");
  const [groupKeysInbound, setGroupKeysInbound] = useState(true);

  useEffect(() => {
    // Decompiled modal fetches the saved webhooks on open.
    const timer = setTimeout(() => setWebhooksLoading(false), 350);
    return () => clearTimeout(timer);
  }, []);

  // Persist newly created groups (best effort, matching the config store).
  const persistGroups = (next: string[]) => {
    setGroups(next);
    try {
      window.localStorage.setItem(GROUPS_KEY, JSON.stringify(next));
    } catch {
      /* storage unavailable */
    }
  };

  const createGroup = () => {
    const name = newGroupName.trim();
    if (!name || groups.length >= GROUP_LIMIT || groups.includes(name)) return;
    persistGroups([...groups, name]);
    setSelectedGroup(name);
    setNewGroupName("");
    onToast(
      "success",
      "Group created",
      `${name} can now share keys with up to 20 projects.`,
    );
  };

  const groupSelectOptions = useMemo(
    () => [
      { value: "", label: "Only this project" },
      ...groups.map((name) => ({ value: name, label: name })),
    ],
    [groups],
  );

  const set = <K extends keyof ConfigState>(key: K, value: ConfigState[K]) => {
    setState((current) => ({ ...current, [key]: value }));
  };

  const save = () => {
    if (saving) return;
    setSaving(true);
    setTimeout(() => {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      } catch {
        /* storage unavailable */
      }
      setSaving(false);
      onClose();
      onToast(
        "success",
        "Settings saved",
        `${PROJECT_NAME} now uses the updated access, webhook, and key security rules.`,
      );
    }, 500);
  };

  return (
    <div className="modal-overlay" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div
        className="glass-card modal-content projectConfigModal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="project-config-title"
      >
        <div className="modal-header">
          <div className="projectConfigHeading">
            <p className="projectConfigEyebrow">Project settings</p>
            <h2 id="project-config-title">Manage {PROJECT_NAME}</h2>
            <p>Update access, webhooks, and key security.</p>
          </div>
          <button
            type="button"
            className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm modal-close"
            aria-label="Close project settings"
            onClick={onClose}
            disabled={saving}
          >
            <span className="flow-icon-btn-inner">
              <X size={18} aria-hidden="true" />
            </span>
          </button>
        </div>
        <form
          className="projectConfigBody"
          onSubmit={(event) => {
            event.preventDefault();
            save();
          }}
        >
          <div className="projectConfigField">
            <div className="fa-field projectConfigInput">
              <div className="fa-field-frame">
                <input
                  id="project-config-name"
                  className="fa-field-input"
                  placeholder=" "
                  value={PROJECT_NAME}
                  readOnly
                  aria-label="Project name"
                />
                <label className="fa-field-label" htmlFor="project-config-name">
                  Project name
                </label>
                <span className="fa-field-charge" aria-hidden="true" />
              </div>
            </div>
          </div>

          {/* Keyless panel (projectKeylessPanel styles are not part of the
              extracted CSS — derived from configuration 1.png) */}
          <div className="projectGroupPanel projectKeylessPanel">
            <div className="projectSettingTile projectSettingTileWide">
              <span className="projectSettingIcon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="7.5" cy="15.5" r="5.5" />
                  <path d="m21 2-9.6 9.6" />
                  <path d="m15.5 7.5 3 3L22 7l-3-3" />
                </svg>
              </span>
              <span className="projectSettingCopy">
                <strong>Make all scripts keyless</strong>
                <small>
                  Allow keyless access through existing loader links. Original script settings
                  return for new runs when this ends.
                </small>
              </span>
              <FaToggle
                id="config-keyless"
                checked={state.keyless_enabled}
                onChange={(next) => set("keyless_enabled", next)}
                label="Make all scripts keyless"
              />
            </div>
            {state.keyless_enabled ? (
              <div className="projectConfigField" style={{ padding: "0 18px 18px" }}>
                <FaSelect
                  options={[
                    { value: "custom", label: "Custom duration" },
                    { value: "forever", label: "Forever" },
                  ]}
                  value={keylessDuration}
                  onChange={setKeylessDuration}
                  ariaLabel="Keyless duration"
                />
              </div>
            ) : null}
          </div>

          <div className="projectConfigWebhookGrid">
            <div className="projectConfigField">
              <div className="fa-field fa-field-unlabeled fa-field-iconed projectConfigInput">
                <div className="fa-field-frame">
                  <span className="fa-field-icon" aria-hidden="true">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" />
                    </svg>
                  </span>
                  <input
                    id="config-logs-webhook"
                    type="url"
                    className="fa-field-input"
                    placeholder=" "
                    value={state.logs_webhook}
                    onChange={(event) => set("logs_webhook", event.target.value)}
                    autoComplete="off"
                    aria-label="Logs webhook"
                  />
                  <label className="fa-field-label" htmlFor="config-logs-webhook">
                    Logs webhook
                  </label>
                  <span className="fa-field-charge" aria-hidden="true" />
                </div>
              </div>
              <FaToggle
                id="config-logs-enabled"
                size="sm"
                checked={state.logs_enabled}
                onChange={(next) => set("logs_enabled", next)}
                disabled={webhooksLoading}
                label="Logs webhook enabled"
                showLabel="Enabled"
              />
              <small>
                {webhookHelper(state.logs_webhook, state.logs_enabled, webhooksLoading)} Auth,
                execution, key mint, claim, and reset events.
              </small>
            </div>
            <div className="projectConfigField">
              <div className="fa-field fa-field-unlabeled fa-field-iconed projectConfigInput">
                <div className="fa-field-frame">
                  <span className="fa-field-icon" aria-hidden="true">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                      <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                    </svg>
                  </span>
                  <input
                    id="config-alert-webhook"
                    type="url"
                    className="fa-field-input"
                    placeholder=" "
                    value={state.alert_webhook}
                    onChange={(event) => set("alert_webhook", event.target.value)}
                    autoComplete="off"
                    aria-label="Alert webhook"
                  />
                  <label className="fa-field-label" htmlFor="config-alert-webhook">
                    Alert webhook
                  </label>
                  <span className="fa-field-charge" aria-hidden="true" />
                </div>
              </div>
              <FaToggle
                id="config-alerts-enabled"
                size="sm"
                checked={state.alerts_enabled}
                onChange={(next) => set("alerts_enabled", next)}
                disabled={webhooksLoading}
                label="Alert webhook enabled"
                showLabel="Enabled"
              />
              <small>
                {webhookHelper(state.alert_webhook, state.alerts_enabled, webhooksLoading)} Failed
                auth, suspicious flags, blacklists, revoke, and pause events.
              </small>
            </div>
          </div>

          <div className="projectConfigGrid">
            <label className="projectSettingTile" htmlFor="config-hwid-reset">
              <span className="projectSettingIcon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
                  <path d="M3 3v5h5" />
                </svg>
              </span>
              <span className="projectSettingCopy">
                <strong>Allow HWID reset</strong>
                <small>Customer reset requests</small>
              </span>
              <FaToggle
                id="config-hwid-reset"
                checked={state.hwid_reset_enabled}
                onChange={(next) => set("hwid_reset_enabled", next)}
                label="Allow HWID reset"
              />
            </label>
            <div className="projectSettingTile projectSettingInputTile">
              <span className="projectSettingIcon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <polyline points="12 6 12 12 16 14" />
                </svg>
              </span>
              <span className="projectSettingCopy">
                <strong>Reset cooldown</strong>
                <small>Days between user resets</small>
              </span>
              <div className="fa-field projectConfigNumber">
                <div className="fa-field-frame">
                  <input
                    className="fa-field-input"
                    type="number"
                    min={0}
                    max={30}
                    value={state.reset_cooldown_days}
                    onChange={(event) => set("reset_cooldown_days", event.target.value)}
                    aria-label="Reset cooldown in days"
                  />
                </div>
              </div>
            </div>
            <label className="projectSettingTile" htmlFor="config-auto-delete">
              <span className="projectSettingIcon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M10 11v6" />
                  <path d="M14 11v6" />
                  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                  <path d="M3 6h18" />
                </svg>
              </span>
              <span className="projectSettingCopy">
                <strong>Auto-delete expired users</strong>
                <small>Clean old keys automatically</small>
              </span>
              <FaToggle
                id="config-auto-delete"
                checked={state.auto_delete_expired_keys}
                onChange={(next) => set("auto_delete_expired_keys", next)}
                label="Auto-delete expired users"
              />
            </label>
            <label className="projectSettingTile" htmlFor="config-hwid-sharing">
              <span className="projectSettingIcon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
              </span>
              <span className="projectSettingCopy">
                <strong>Allow cloned HWID sharing</strong>
                <small>Permit shared key sessions</small>
              </span>
              <FaToggle
                id="config-hwid-sharing"
                checked={state.allow_hwid_key_sharing}
                onChange={(next) => set("allow_hwid_key_sharing", next)}
                label="Allow cloned HWID sharing"
              />
            </label>
            <label className="projectSettingTile" htmlFor="config-instance-limit">
              <span className="projectSettingIcon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m12 2 8.5 4.86v6.28L12 18 3.5 13.14V6.86L12 2Z" />
                  <path d="m3.5 6.86 8.5 4.86 8.5-4.86" />
                  <path d="M12 11.72V18" />
                </svg>
              </span>
              <span className="projectSettingCopy">
                <strong>Instance limit</strong>
                <small>Cap active auth sessions</small>
              </span>
              <FaToggle
                id="config-instance-limit"
                checked={state.instance_limit_enabled}
                onChange={(next) => set("instance_limit_enabled", next)}
                label="Instance limit"
              />
            </label>
            <div
              className={`projectSettingTile projectSettingInputTile${state.instance_limit_enabled ? "" : " isDisabled"}`}
            >
              <span className="projectSettingIcon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="2" y="6" width="20" height="12" rx="2" />
                  <path d="M12 12h.01" />
                  <path d="M17 12h.01" />
                  <path d="M7 12h.01" />
                </svg>
              </span>
              <span className="projectSettingCopy">
                <strong>Max instances</strong>
                <small>1 to 20 active tabs</small>
              </span>
              <div className="fa-field projectConfigNumber">
                <div className="fa-field-frame">
                  <input
                    className="fa-field-input"
                    type="number"
                    min={1}
                    max={20}
                    disabled={!state.instance_limit_enabled}
                    value={state.max_instances}
                    onChange={(event) => set("max_instances", event.target.value)}
                    aria-label="Max instances"
                  />
                </div>
              </div>
            </div>
            <label className="projectSettingTile projectSettingTileWide" htmlFor="config-hwidless">
              <span className="projectSettingIcon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="7.5" cy="15.5" r="5.5" />
                  <path d="m21 2-9.6 9.6" />
                  <path d="m15.5 7.5 3 3L22 7l-3-3" />
                </svg>
              </span>
              <span className="projectSettingCopy">
                <strong>HWIDless keys</strong>
                <small>Do not bind keys to devices</small>
              </span>
              <FaToggle
                id="config-hwidless"
                checked={state.hwidless_keys}
                onChange={(next) => set("hwidless_keys", next)}
                label="HWIDless keys"
              />
            </label>
            <label className="projectSettingTile projectSettingTileWide" htmlFor="config-stacking">
              <span className="projectSettingIcon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <polyline points="12 6 12 12 16 14" />
                </svg>
              </span>
              <span className="projectSettingCopy">
                <strong>Stack redeemed keys</strong>
                <small>
                  Add a new key&apos;s time to the customer&apos;s existing key. The new key is
                  consumed once.
                </small>
              </span>
              <FaToggle
                id="config-stacking"
                checked={state.key_stacking_enabled}
                onChange={(next) => set("key_stacking_enabled", next)}
                label="Stack redeemed keys"
              />
            </label>
          </div>

          <div className="projectGroupPanel">
            <div className="projectGroupPanelHeader">
              <div className="projectGroupPanelHeading">
                <span className="projectGroupPanelIcon" aria-hidden="true">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m12 2 8.5 4.86v6.28L12 18 3.5 13.14V6.86L12 2Z" />
                    <path d="m3.5 6.86 8.5 4.86 8.5-4.86" />
                    <path d="M12 11.72V18" />
                  </svg>
                </span>
                <span className="projectGroupPanelTitle">
                  <strong>Project group and key permissions</strong>
                  <small>
                    Share keys with selected projects, or keep this project independent.
                  </small>
                </span>
              </div>
              <span className="projectGroupStatus" data-empty={selectedGroup ? undefined : ""}>{selectedGroup || "No group"}</span>
            </div>
            <div className="projectGroupLayout">
              <div className="projectGroupMembership">
                <div className="projectGroupSectionHeading">
                  <strong>Group membership</strong>
                  <small>Groups can contain up to 20 projects.</small>
                </div>
                <div className="projectGroupSelect">
                  <FaSelect
                    options={groupSelectOptions}
                    value={selectedGroup}
                    onChange={setSelectedGroup}
                    ariaLabel="Project group"
                  />
                </div>
                <small className="projectGroupMembershipHint">
                  {selectedGroup
                    ? `Keys created for this project also work on the other projects in ${selectedGroup}.`
                    : "Keys created for this project work only on this project."}
                </small>
                <div className="projectGroupCreateBlock">
                  <span>Create a new group ({groups.length} of {GROUP_LIMIT})</span>
                  <div className="projectGroupCreateRow">
                    <input
                      type="text"
                      className="fa-field-input"
                      placeholder="Group name"
                      aria-label="New group name"
                      maxLength={60}
                      value={newGroupName}
                      disabled={groups.length >= GROUP_LIMIT}
                      onChange={(event) => setNewGroupName(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter") {
                          event.preventDefault();
                          createGroup();
                        }
                      }}
                    />
                    <button
                      type="button"
                      className="flow-btn flow-btn-secondary flow-btn-sm"
                      disabled={!newGroupName.trim() || groups.length >= GROUP_LIMIT}
                      onClick={createGroup}
                    >
                      <span className="flow-btn-sweep" aria-hidden="true" />
                      <span className="flow-btn-content"><span className="flow-btn-label">Create group</span></span>
                    </button>
                  </div>
                </div>
              </div>
              <div className="projectGroupPermissions">
                <div className="projectGroupSectionHeading">
                  <strong>Key permissions</strong>
                  <small>Choose whose keys are valid on this project.</small>
                </div>
                {selectedGroup ? (
                  <div className="projectGroupPermissionRow">
                    <span className="projectGroupPermissionCopy">
                      <strong>{selectedGroup}</strong>
                      <small>Keys minted for projects in this group are valid here.</small>
                    </span>
                    <FaToggle
                      id="config-group-inbound"
                      size="sm"
                      checked={groupKeysInbound}
                      onChange={setGroupKeysInbound}
                      label={`${selectedGroup} keys valid on this project`}
                    />
                  </div>
                ) : (
                  <div className="projectGroupEmpty">Select a group to configure key permissions.</div>
                )}
                <small className="projectGroupDirectionHint">
                  Each permission is one-way. Changing it here does not change where this
                  project&apos;s keys work.
                </small>
              </div>
            </div>
          </div>
        </form>
        <div className="modal-footer">
          <button
            type="button"
            className="flow-btn flow-btn-secondary flow-btn-md"
            onClick={onClose}
            disabled={saving}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content"><span className="flow-btn-label">Cancel</span></span>
          </button>
          <button
            type="button"
            className="flow-btn flow-btn-primary flow-btn-md"
            onClick={save}
            disabled={saving}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content">
              <span className="flow-btn-label">{saving ? "Saving…" : "Save Settings"}</span>
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
