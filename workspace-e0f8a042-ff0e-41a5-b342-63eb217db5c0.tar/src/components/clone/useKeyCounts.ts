"use client";

import { useEffect, useState } from "react";

/**
 * Live workspace key metrics — the captured dashboard shipped its overview
 * numbers from the server payload (1 key, active; "1 total keys"). The
 * single-tenant clone now derives the same numbers from the persisted key
 * records ("switzauth-keys-v1", seeded with that captured demo key), so the
 * overview keeps the captured values by default and stays truthful as keys
 * are minted, imported, paused or revoked.
 *
 * Updates propagate through the `storage` event (cross-tab) and the
 * `switzauth-keys-changed` custom event (same-tab, dispatched by KeysBody
 * whenever records are written).
 */

export interface KeyCounts {
  total: number;
  active: number;
}

export const KEYS_STORAGE_KEY = "switzauth-keys-v1";
export const KEYS_CHANGED_EVENT = "switzauth-keys-changed";

/** Captured account payload default (1 issued key, active). */
export const CAPTURED_KEY_COUNTS: KeyCounts = { total: 1, active: 1 };

export function readKeyCounts(): KeyCounts {
  if (typeof window === "undefined") return CAPTURED_KEY_COUNTS;
  try {
    const raw = window.localStorage.getItem(KEYS_STORAGE_KEY);
    if (!raw) return CAPTURED_KEY_COUNTS; // no store yet → KeysBody seeds the demo key
    const records = JSON.parse(raw)?.records;
    if (!Array.isArray(records) || records.length === 0) return CAPTURED_KEY_COUNTS;
    return {
      total: records.length,
      active: records.filter((record: { status?: unknown }) => record?.status === "active").length,
    };
  } catch {
    return CAPTURED_KEY_COUNTS;
  }
}

export function useKeyCounts(): KeyCounts {
  const [counts, setCounts] = useState<KeyCounts>(CAPTURED_KEY_COUNTS);

  useEffect(() => {
    // Initial read deferred to a rAF (codebase pattern — avoids the
    // synchronous setState-in-effect cascade).
    const frame = requestAnimationFrame(() => setCounts(readKeyCounts()));
    const onStorage = (event: StorageEvent) => {
      if (!event.key || event.key === KEYS_STORAGE_KEY) setCounts(readKeyCounts());
    };
    const onChanged = () => setCounts(readKeyCounts());
    window.addEventListener("storage", onStorage);
    window.addEventListener(KEYS_CHANGED_EVENT, onChanged);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("storage", onStorage);
      window.removeEventListener(KEYS_CHANGED_EVENT, onChanged);
    };
  }, []);

  return counts;
}
