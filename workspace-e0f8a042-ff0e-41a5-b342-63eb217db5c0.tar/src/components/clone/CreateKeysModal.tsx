"use client";

import { useState } from "react";
import { X } from "lucide-react";
import type { KeyRecord, ToastFn } from "./KeysBody";
import { mintKeyValue, nowLabel } from "./keysMint";

/**
 * "Create access keys" dialog — port of the decompiled `rW` modal in chunk
 * 3k6a5lhrkscp5.js (opened by the keys page "Add user" button; visual
 * reference: added user.png). Uses the original global classes
 * (modal-overlay / glass-card modal-content workspaceFormModal / modal-header
 * / project-edit-grid / modal-footer) that ship in the ported theme.css.
 *
 * Decompiled field contract: quantity 1–500, length 12–64, expiration
 * lifetime | 1d | 7d | 30d | days (1–3650, "Each key starts on first use.")
 * | custom (date). Generate is disabled while a custom day count is invalid.
 */

const EXPIRY_OPTIONS = [
  { value: "lifetime", label: "Lifetime Access" },
  { value: "1d", label: "1 Day" },
  { value: "7d", label: "7 Days" },
  { value: "30d", label: "30 Days" },
  { value: "days", label: "Custom days" },
  { value: "custom", label: "Custom Date" },
];

function expiryLabel(option: string, days: string, date: string): string | null {
  switch (option) {
    case "1d":
      return "1 day";
    case "7d":
      return "7 days";
    case "30d":
      return "30 days";
    case "days": {
      const n = Number(days);
      return `${n} day${n === 1 ? "" : "s"}`;
    }
    case "custom":
      return date
        ? new Date(`${date}T23:59:59`).toLocaleString("en-GB", {
            day: "numeric",
            month: "short",
            year: "numeric",
          })
        : null;
    default:
      return null;
  }
}

export default function CreateKeysModal({
  onClose,
  onToast,
  onCreate,
}: {
  onClose: () => void;
  onToast: ToastFn;
  onCreate: (created: KeyRecord[]) => void;
}) {
  const [tier, setTier] = useState("premium");
  const [quantity, setQuantity] = useState("1");
  const [length, setLength] = useState("24");
  const [expiry, setExpiry] = useState("lifetime");
  const [days, setDays] = useState("30");
  const [date, setDate] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const quantityNum = Number(quantity);
  const lengthNum = Number(length);
  const daysNum = Number(days);
  const daysInvalid =
    expiry === "days" && (!Number.isInteger(daysNum) || daysNum < 1 || daysNum > 3650);
  const dateInvalid = expiry === "custom" && !date;
  const generateDisabled =
    busy ||
    !Number.isInteger(quantityNum) ||
    quantityNum < 1 ||
    quantityNum > 500 ||
    !Number.isInteger(lengthNum) ||
    lengthNum < 12 ||
    lengthNum > 64 ||
    daysInvalid ||
    dateInvalid;

  const generate = () => {
    if (generateDisabled) return;
    setBusy(true);
    // Simulated request latency, then mint locally (single-tenant clone).
    setTimeout(() => {
      const label = expiryLabel(expiry, days, date);
      // Duration metadata for the decompiled key-duration dialog: day-count
      // options are first-use TTLs (expires_after_ms), custom dates are
      // absolute expiries, lifetime is all-null.
      const dayMs = 864e5;
      const ttlDays = expiry === "1d" ? 1 : expiry === "7d" ? 7 : expiry === "30d" ? 30 : expiry === "days" ? daysNum : null;
      const absolute = expiry === "custom" && date ? new Date(`${date}T23:59:59`).getTime() : null;
      // Server-style sequential ids for the "Access key #N" eyebrow.
      let maxNumeric = 0;
      try {
        const raw = window.localStorage.getItem("switzauth-keys-v1");
        const records = raw ? (JSON.parse(raw)?.records as Array<{ numericId?: number }> | undefined) : undefined;
        maxNumeric = (records ?? []).reduce((max, r) => Math.max(max, r.numericId ?? 0), 0);
      } catch {
        /* storage unavailable */
      }
      const created: KeyRecord[] = Array.from({ length: quantityNum }, (_, i) => ({
        id: `k-${Date.now().toString(36)}-${i}`,
        value: mintKeyValue(lengthNum),
        note,
        tier: tier === "free" ? "free" : "premium",
        status: "active" as const,
        createdLabel: nowLabel(),
        hwid: null,
        expiresLabel: label,
        numericId: maxNumeric + 1 + i,
        expiresAtMs: absolute,
        claimedAtMs: null,
        expiresAfterMs: ttlDays !== null ? ttlDays * dayMs : null,
        pausedAtMs: null,
        pausedRemainingMs: null,
      }));
      setBusy(false);
      onCreate(created);
      onToast(
        "success",
        quantityNum === 1 ? "Access key generated" : `${quantityNum} access keys generated`,
        label ? `Keys expire ${label === null ? "never" : `on ${label}`}.` : "Keys have lifetime access.",
      );
    }, 500);
  };

  return (
    <div className="modal-overlay" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div
        className="glass-card modal-content workspaceFormModal"
        role="dialog"
        aria-modal="true"
        aria-label="Create access keys"
      >
        <div className="modal-header">
          <h2>Create access keys</h2>
          <button
            type="button"
            className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm modal-close"
            aria-label="Close key generator"
            onClick={onClose}
          >
            <span className="flow-icon-btn-inner">
              <X size={18} aria-hidden="true" />
            </span>
          </button>
        </div>
        <form
          className="project-edit-grid"
          onSubmit={(event) => {
            event.preventDefault();
            generate();
          }}
        >
          <div className="form-group">
            <label htmlFor="create-keys-project">Target project</label>
            <div className="fa-select">
              <button
                id="create-keys-project"
                type="button"
                className="fa-select-trigger"
                aria-haspopup="listbox"
                aria-expanded="false"
                aria-label="Target project, jh9iu"
              >
                <span className="fa-select-value">jh9iu</span>
                <span className="fa-select-chevron">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </span>
              </button>
            </div>
          </div>
          <div className="form-group">
            <label htmlFor="create-keys-tier">Key tier</label>
            <select
              id="create-keys-tier"
              className="fa-select-trigger"
              value={tier}
              onChange={(event) => setTier(event.target.value)}
              aria-label="Key tier"
            >
              <option value="premium">Premium</option>
              <option value="free">Free</option>
            </select>
          </div>
          <div className="project-edit-row">
            <div className="form-group">
              <label htmlFor="create-keys-quantity">Key quantity (max 500)</label>
              <input
                id="create-keys-quantity"
                className="fa-field-input"
                type="number"
                min={1}
                max={500}
                value={quantity}
                onChange={(event) => setQuantity(event.target.value)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="create-keys-length">Key character length</label>
              <input
                id="create-keys-length"
                className="fa-field-input"
                type="number"
                min={12}
                max={64}
                value={length}
                onChange={(event) => setLength(event.target.value)}
              />
            </div>
          </div>
          <div className="project-edit-row">
            <div className="form-group">
              <label htmlFor="create-keys-expiry">Expiration option</label>
              <select
                id="create-keys-expiry"
                className="fa-select-trigger"
                value={expiry}
                onChange={(event) => setExpiry(event.target.value)}
                aria-label="Expiration option"
              >
                {EXPIRY_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            {expiry === "days" ? (
              <div className="form-group">
                <label htmlFor="new-key-days">Days per key</label>
                <input
                  id="new-key-days"
                  className="fa-field-input"
                  type="number"
                  min={1}
                  max={3650}
                  step={1}
                  value={days}
                  onChange={(event) => setDays(event.target.value)}
                />
                <small>1–3650 days. Each key starts on first use.</small>
              </div>
            ) : null}
            {expiry === "custom" ? (
              <div className="form-group">
                <label htmlFor="new-key-date">Custom Expiry Date</label>
                <input
                  id="new-key-date"
                  className="fa-field-input"
                  type="date"
                  value={date}
                  onChange={(event) => setDate(event.target.value)}
                />
              </div>
            ) : null}
          </div>
          <div className="form-group">
            <label htmlFor="create-keys-note">Operator note</label>
            <input
              id="create-keys-note"
              className="fa-field-input"
              type="text"
              value={note}
              placeholder="e.g. Reseller #5 Group Sale"
              maxLength={120}
              onChange={(event) => setNote(event.target.value)}
            />
          </div>
        </form>
        <div className="modal-footer">
          <button
            type="button"
            className="flow-btn flow-btn-secondary flow-btn-md"
            onClick={onClose}
            disabled={busy}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content"><span className="flow-btn-label">Cancel</span></span>
          </button>
          <button
            type="button"
            className="flow-btn flow-btn-primary flow-btn-md"
            onClick={generate}
            disabled={generateDisabled}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content">
              <span className="flow-btn-label">{busy ? "Generating…" : "Generate"}</span>
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
