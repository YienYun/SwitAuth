"use client";

import { useEffect, useId, useState } from "react";

/**
 * "Project collaborators" dialog — ported 1:1 from the decompiled owner view
 * (chunk 3k6a5lhrkscp5.js, components aJ/aY/aB and the permission model in
 * module 84250). Every class below is the extracted
 * `project-collaborators-module__FbxJEW__*` stylesheet from dash-b.css, so
 * the dialog-in/out motion, blurred overlay, permission presets, confirmation
 * panels and footer render exactly like the original capture
 * (reference screenshots "collaboration 1.png" / "collaboration 2.png").
 */

export type PermissionKey =
  | "view_source"
  | "upload"
  | "edit_source"
  | "rename"
  | "delete"
  | "toggle"
  | "settings";

export type Permissions = Record<PermissionKey, boolean>;

export interface PendingInvite {
  id: string;
  email: string;
  permissions: Permissions;
  expiresAt: string; // ISO date
}

const PROJECT_NAME = "jh9iu";

const PERMISSIONS: { key: PermissionKey; label: string; description: string }[] = [
  { key: "view_source", label: "View & download source", description: "Read the original source in the script editor." },
  { key: "upload", label: "Upload scripts", description: "Add new scripts to this project." },
  { key: "edit_source", label: "Edit source", description: "Replace or update existing script code." },
  { key: "rename", label: "Rename scripts", description: "Change script names." },
  { key: "delete", label: "Delete scripts", description: "Permanently remove scripts from this project." },
  { key: "toggle", label: "Enable & disable scripts", description: "Control whether a script can run." },
  { key: "settings", label: "Change script settings", description: "Change targeting, keyless access, protection, and delivery." },
];

const ALL_ON = Object.fromEntries(PERMISSIONS.map(({ key }) => [key, true])) as Permissions;
const ALL_OFF = Object.fromEntries(PERMISSIONS.map(({ key }) => [key, false])) as Permissions;

/** Permission summary tag — exact strings from the decompiled l() helper. */
function permissionLabel(value: Permissions): string {
  const on = PERMISSIONS.filter(({ key }) => value[key]).length;
  if (on === PERMISSIONS.length) return "Full script access";
  if (on === 0) return "View only";
  return "Custom access";
}

/** Permission summary sentence — exact string from the decompiled d() helper. */

const STORAGE_KEY = "switzauth-collaborators-v1";

const formatDate = (iso: string) =>
  new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric" });

function loadInvites(): PendingInvite[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    if (Array.isArray(parsed?.invitations)) return parsed.invitations as PendingInvite[];
  } catch {
    /* ignore corrupted state */
  }
  return [];
}

function saveInvites(invites: PendingInvite[]) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ invitations: invites }));
  } catch {
    /* storage unavailable */
  }
}

function Avatar({ name }: { name: string }) {
  return (
    <span className="project-collaborators-module__FbxJEW__avatar">
      <span className="fa-avatar-fallback">{(name || "?").charAt(0).toUpperCase()}</span>
    </span>
  );
}

const CheckIcon = ({ size = 12 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 6 9 17l-5-5" />
  </svg>
);

const UsersIcon = ({ size = 13 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
    <path d="M16 3.128a4 4 0 0 1 0 7.744" />
    <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
    <circle cx="9" cy="7" r="4" />
  </svg>
);

const SlidersIcon = ({ size = 14 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
    <line x1="21" x2="14" y1="4" y2="4" />
    <line x1="10" x2="3" y1="4" y2="4" />
    <line x1="21" x2="12" y1="12" y2="12" />
    <line x1="8" x2="3" y1="12" y2="12" />
    <line x1="21" x2="16" y1="20" y2="20" />
    <line x1="12" x2="3" y1="20" y2="20" />
    <line x1="14" x2="14" y1="2" y2="6" />
    <line x1="8" x2="8" y1="10" y2="14" />
    <line x1="16" x2="16" y1="18" y2="22" />
  </svg>
);

/** Permission editor — exact DOM of the decompiled aB component. */
function PermissionPanel({
  value,
  onChange,
  disabled,
}: {
  value: Permissions;
  onChange: (next: Permissions) => void;
  disabled?: boolean;
}) {
  const uid = useId().replace(/[^a-zA-Z0-9-]/g, "");
  return (
    <fieldset className="project-collaborators-module__FbxJEW__permissions" disabled={disabled}>
      <legend>Script permissions</legend>
      <div className="project-collaborators-module__FbxJEW__presets">
        <button
          type="button"
          className="project-collaborators-module__FbxJEW__secondary"
          aria-pressed={permissionLabel(value) === "View only"}
          onClick={() => onChange({ ...ALL_OFF })}
        >
          View only
        </button>
        <button
          type="button"
          className="project-collaborators-module__FbxJEW__secondary"
          aria-pressed={permissionLabel(value) === "Full script access"}
          onClick={() => onChange({ ...ALL_ON })}
        >
          Full script access
        </button>
        <span>Or choose each action below</span>
      </div>
      <div>
        {PERMISSIONS.map(({ key, label, description }) => (
          <label key={key} className="project-collaborators-module__FbxJEW__permissionOption" htmlFor={`${uid}-${key}`}>
            <input
              id={`${uid}-${key}`}
              type="checkbox"
              aria-labelledby={`${uid}-${key}-label`}
              aria-describedby={`${uid}-${key}-description`}
              checked={value[key]}
              onChange={(event) => onChange({ ...value, [key]: event.target.checked })}
            />
            <span className="project-collaborators-module__FbxJEW__permissionCheck" aria-hidden="true">
              <CheckIcon size={12} />
            </span>
            <span>
              <strong id={`${uid}-${key}-label`}>{label}</strong>
              <small id={`${uid}-${key}-description`}>{description}</small>
            </span>
          </label>
        ))}
      </div>
      <p className="project-collaborators-module__FbxJEW__helper">
        Everyone can view project and script details. Project settings, keys, and sharing stay with the owner.
      </p>
    </fieldset>
  );
}

interface EditTarget {
  kind: "invitation";
  id: string;
  name: string;
  email: string;
}

export default function CollaboratorsModal({ onClose }: { onClose: () => void }) {
  // The dialog only mounts after a user click inside the client-only SPA, so
  // reading localStorage in the lazy initializer is hydration-safe.
  const [invites, setInvites] = useState<PendingInvite[]>(() => loadInvites());
  const [email, setEmail] = useState("");
  const [invitePerms, setInvitePerms] = useState<Permissions>({ ...ALL_ON });
  const [disclosureOpen, setDisclosureOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [editing, setEditing] = useState<EditTarget | null>(null);
  const [editValue, setEditValue] = useState<Permissions>({ ...ALL_ON });
  const emailId = useId().replace(/[^a-zA-Z0-9-]/g, "");

  // Escape: with the edit panel open the original swallowed Escape and just
  // closed the panel (cancelConfirmation in aJ); otherwise it closed the dialog.
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      event.stopPropagation();
      event.preventDefault();
      if (editing) {
        setEditing(null);
        return;
      }
      onClose();
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [editing, onClose]);

  const persist = (next: PendingInvite[]) => {
    setInvites(next);
    saveInvites(next);
  };

  const submitInvite = (event: React.FormEvent) => {
    event.preventDefault();
    const value = email.trim().toLowerCase();
    if (!value) return;
    if (value === "baderialailatul491@gmail.com") {
      setError("You already own this project.");
      setNotice("");
      return;
    }
    if (invites.some((inv) => inv.email === value)) {
      setError("An invitation is already waiting for this person.");
      setNotice("");
      return;
    }
    const expires = new Date();
    expires.setDate(expires.getDate() + 7);
    const invite: PendingInvite = {
      id:
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `inv-${Date.now()}`,
      email: value,
      permissions: { ...invitePerms },
      expiresAt: expires.toISOString(),
    };
    persist([...invites, invite]);
    setEmail("");
    setError("");
    setNotice("Invitation sent. They can accept it in their Switzauth inbox.");
  };

  const cancelInvite = (id: string) => {
    persist(invites.filter((inv) => inv.id !== id));
    setError("");
    setNotice("Invitation cancelled.");
  };

  const savePermissions = () => {
    if (!editing) return;
    persist(
      invites.map((inv) => (inv.id === editing.id ? { ...inv, permissions: { ...editValue } } : inv)),
    );
    setEditing(null);
    setError("");
    setNotice("Permissions saved. The new access applies immediately.");
  };

  const openEdit = (invite: PendingInvite) => {
    setEditing({ kind: "invitation", id: invite.id, name: invite.email, email: invite.email });
    setEditValue({ ...invite.permissions });
    setNotice("");
    setError("");
  };

  return (
    <>
      <div
        className="project-collaborators-module__FbxJEW__overlay"
        data-state="open"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="project-collaborators-module__FbxJEW__dialog"
        data-state="open"
        role="dialog"
        aria-modal="true"
        aria-labelledby="collab-dialog-title"
        aria-describedby="collab-dialog-description"
      >
        <header className="project-collaborators-module__FbxJEW__header">
          <div className="project-collaborators-module__FbxJEW__heading">
            <span className="project-collaborators-module__FbxJEW__eyebrow">
              <UsersIcon size={13} /> Project sharing
            </span>
            <h2 id="collab-dialog-title" className="project-collaborators-module__FbxJEW__title">
              {editing ? "Edit permissions" : "Project collaborators"}
            </h2>
            <p id="collab-dialog-description" className="project-collaborators-module__FbxJEW__description">
              {editing ? `${editing.name} · ${PROJECT_NAME}` : PROJECT_NAME}
            </p>
          </div>
          <button type="button" className="project-collaborators-module__FbxJEW__close" aria-label="Close" onClick={onClose}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </header>

        {editing ? (
          <div className="project-collaborators-module__FbxJEW__body">
            <PermissionPanel value={editValue} onChange={setEditValue} />
            <div className="project-collaborators-module__FbxJEW__confirmActions">
              <button
                type="button"
                className="project-collaborators-module__FbxJEW__secondary"
                onClick={() => setEditing(null)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="project-collaborators-module__FbxJEW__primary"
                onClick={savePermissions}
              >
                Save permissions
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="project-collaborators-module__FbxJEW__body">
              {error ? (
                <p role="alert" className="project-collaborators-module__FbxJEW__error">
                  {error}
                </p>
              ) : notice ? (
                <p role="status" className="project-collaborators-module__FbxJEW__notice">
                  <CheckIcon size={16} /> {notice}
                </p>
              ) : null}

              <form className="project-collaborators-module__FbxJEW__form" onSubmit={submitInvite}>
                <label htmlFor={emailId}>Invite by email</label>
                <div className="project-collaborators-module__FbxJEW__inputRow">
                  <div className="project-collaborators-module__FbxJEW__emailInput">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7" />
                      <rect x="2" y="4" width="20" height="16" rx="2" />
                    </svg>
                    <input
                      id={emailId}
                      type="email"
                      maxLength={254}
                      required
                      autoComplete="off"
                      placeholder="teammate@example.com"
                      value={email}
                      onChange={(event) => setEmail(event.target.value)}
                      aria-describedby={`${emailId}-help`}
                    />
                  </div>
                  <button
                    type="submit"
                    className="project-collaborators-module__FbxJEW__primary"
                    disabled={!email.trim()}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="m22 2-7 20-4-9-9-4Z" />
                      <path d="M22 2 11 13" />
                    </svg>{" "}
                    Send invite
                  </button>
                </div>
                <p id={`${emailId}-help`} className="project-collaborators-module__FbxJEW__helper">
                  Use their Switzauth account email. Invites expire in 7 days.
                </p>

                <button
                  type="button"
                  className="project-collaborators-module__FbxJEW__permissionDisclosure"
                  aria-expanded={disclosureOpen}
                  onClick={() => setDisclosureOpen((open) => !open)}
                >
                  <SlidersIcon size={14} /> Invitation permissions{" "}
                  <span>{permissionLabel(invitePerms)}</span>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </button>
                {disclosureOpen ? (
                  <PermissionPanel value={invitePerms} onChange={setInvitePerms} />
                ) : null}
              </form>

              <div className="project-collaborators-module__FbxJEW__sectionTitle">
                <h3>People with access</h3>
                <span>{1}</span>
                <span className="project-collaborators-module__FbxJEW__private">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="16" r="1" />
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                  </svg>{" "}
                  Invite only
                </span>
              </div>
              <div className="project-collaborators-module__FbxJEW__people">
                <div className="project-collaborators-module__FbxJEW__identity" data-row="owner">
                  <Avatar name="Zed" />
                  <div className="project-collaborators-module__FbxJEW__person">
                    <strong>
                      Zed
                      <span className="project-collaborators-module__FbxJEW__you">You</span>
                    </strong>
                    <span>Manages this project</span>
                  </div>
                  <span className="project-collaborators-module__FbxJEW__tag">Owner</span>
                </div>
              </div>

              {invites.length ? (
                <section className="project-collaborators-module__FbxJEW__pendingSection" aria-label="Pending invitations">
                  <div className="project-collaborators-module__FbxJEW__sectionTitle">
                    <h3>Pending invitations</h3>
                    <span>{invites.length}</span>
                  </div>
                  {invites.map((invite) => (
                    <div key={invite.id} className="project-collaborators-module__FbxJEW__member" data-row={`invite-${invite.id}`}>
                      <div className="project-collaborators-module__FbxJEW__identity">
                        <Avatar name={invite.email} />
                        <div className="project-collaborators-module__FbxJEW__person">
                          <strong title={invite.email}>{invite.email}</strong>
                          <span>
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                              <circle cx="12" cy="12" r="10" />
                              <path d="M12 6v6l4 2" />
                            </svg>{" "}
                            Pending · expires {formatDate(invite.expiresAt)}
                          </span>
                        </div>
                        <div className="project-collaborators-module__FbxJEW__memberActions">
                          <button
                            type="button"
                            className="project-collaborators-module__FbxJEW__permissionButton"
                            onClick={() => openEdit(invite)}
                            aria-expanded={false}
                          >
                            <SlidersIcon size={13} /> Permissions
                          </button>
                          <button
                            type="button"
                            className="project-collaborators-module__FbxJEW__secondary"
                            onClick={() => cancelInvite(invite.id)}
                          >
                            Cancel invite
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </section>
              ) : null}
            </div>
            <footer className="project-collaborators-module__FbxJEW__footer">
              <UsersIcon size={15} />
              <p>
                Each collaborator has their own permissions.
                <span>Only the owner manages project settings and access.</span>
              </p>
            </footer>
          </>
        )}
      </div>
    </>
  );
}
