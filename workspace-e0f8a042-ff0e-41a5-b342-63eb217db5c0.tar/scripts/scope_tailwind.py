#!/usr/bin/env python3
"""Scope dash-tailwind.css (Tailwind v4 output) under .dashboard-layout.
Comment-aware tokenizer for compiled Tailwind output."""
import re

SRC = "/home/z/my-project/src/app/styles/dash-tailwind.css"
OUT = "/home/z/my-project/src/app/styles/dash-tailwind.css"
PREFIX = ".dashboard-layout"

def find_block_end(css: str, open_idx: int) -> int:
    """Return index of matching '}' for '{' at open_idx (comment aware)."""
    depth = 0
    i = open_idx
    n = len(css)
    while i < n:
        c = css[i]
        if c == "/" and i + 1 < n and css[i + 1] == "*":
            end = css.find("*/", i + 2)
            i = end + 2 if end != -1 else n
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return n - 1

def prefix_selector_list(group: str) -> str:
    parts = group.split(",")
    out = []
    for p in parts:
        s = p.strip()
        if not s:
            continue
        if s == "*":
            out.append("%s *" % PREFIX)
        elif s == "html":
            out.append(PREFIX)
        elif s == ":host" or s.startswith(":host("):
            # Inert in the original document (no shadow DOM) -> drop entirely.
            continue
        elif s == "body":
            out.append('body[data-view="app"]')
        elif s.startswith("::"):
            out.append("%s %s" % (PREFIX, s))
        elif s.startswith(":"):
            out.append("%s :is(%s)" % (PREFIX, s))
        else:
            out.append("%s %s" % (PREFIX, s))
    return ",".join(out)

def process(css: str) -> str:
    out = []
    i = 0
    n = len(css)
    while i < n:
        c = css[i]
        # pass comments through
        if c == "/" and i + 1 < n and css[i + 1] == "*":
            end = css.find("*/", i + 2)
            stop = end + 2 if end != -1 else n
            out.append(css[i:stop])
            i = stop
            continue
        if css[i] == "@":
            brace = css.find("{", i)
            at_head = css[i:brace]
            name = at_head[1:].strip().split()[0].split("(")[0]
            if name in ("media", "supports", "layer"):
                end = find_block_end(css, brace)
                inner = css[brace + 1:end]
                out.append(at_head + "{" + process(inner) + "}")
                i = end + 1
            elif name == "keyframes":
                end = find_block_end(css, brace)
                out.append(css[i:end + 1])
                i = end + 1
            else:
                # @property etc: copy block verbatim
                end = find_block_end(css, brace)
                out.append(css[i:end + 1])
                i = end + 1
            continue
        # normal rule
        brace = css.find("{", i)
        if brace == -1:
            out.append(css[i:])
            break
        sel = css[i:brace]
        end = find_block_end(css, brace)
        decl = css[brace:end + 1]
        # declarations block? (top-level blocks are always rules here)
        sel_s = sel.strip()
        if sel_s:
            out.append(prefix_selector_list(sel) + decl)
        else:
            out.append(sel + decl)
        i = end + 1
    return "".join(out)

css = open(SRC, encoding="utf-8").read()
scoped = process(css)
open(OUT, "w", encoding="utf-8").write(scoped)
print("scoped:", len(scoped), "chars; occurrences of prefix:", scoped.count(".dashboard-layout"))
