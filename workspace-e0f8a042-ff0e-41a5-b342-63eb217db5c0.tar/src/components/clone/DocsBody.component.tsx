// Auto-generated 1:1 port of scraped FlowAuth page: Docs
export default function DocsBody() {
  return (
  <div className="dashboard-layout">
    <div className="dot-pattern-module__UBH-QW__root dotPatternBackground" data-dashboard-background="dot-pattern" aria-hidden="true">
      <svg className="dot-pattern-module__UBH-QW__pattern">
        <defs>
          <pattern id="_r_1_" patternUnits="userSpaceOnUse" patternContentUnits="userSpaceOnUse" x="0" y="0"><circle cx="1" cy="1" r="1" /></pattern>
        </defs>
        <rect width="100%" height="100%" strokeWidth="0" fill="url(#_r_1_)" />
      </svg>
    </div>
    <div className="sidebar-module__9SB1EG__desktopSlot">
      <aside className="sidebar-module__9SB1EG__desktop enhanced-sidebar-module__5H-W0q__shell flowAceternitySidebar" data-open="false">
        <div className="enhanced-sidebar-module__5H-W0q__inner">
          <a href="/" className="enhanced-sidebar-module__5H-W0q__brand" aria-label="Switzauth home">
            <span className="enhanced-sidebar-module__5H-W0q__brandMark"><img alt="" src="/brand/flowauth-logo.png" /></span>
            <span className="enhanced-sidebar-module__5H-W0q__brandName" aria-hidden="true">Switzauth</span>
          </a>
          <nav className="enhanced-sidebar-module__5H-W0q__navigation" aria-label="Workspace navigation">
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="Dashboard" title="Dashboard">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M13.6903 19.4567C13.5 18.9973 13.5 18.4149 13.5 17.25C13.5 16.0851 13.5 15.5027 13.6903 15.0433C13.944 14.4307 14.4307 13.944 15.0433 13.6903C15.5027 13.5 16.0851 13.5 17.25 13.5C18.4149 13.5 18.9973 13.5 19.4567 13.6903C20.0693 13.944 20.556 14.4307 20.8097 15.0433C21 15.5027 21 16.0851 21 17.25C21 18.4149 21 18.9973 20.8097 19.4567C20.556 20.0693 20.0693 20.556 19.4567 20.8097C18.9973 21 18.4149 21 17.25 21C16.0851 21 15.5027 21 15.0433 20.8097C14.4307 20.556 13.944 20.0693 13.6903 19.4567Z" stroke="currentColor" strokeLinecap="square" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M13.6903 8.95671C13.5 8.49728 13.5 7.91485 13.5 6.75C13.5 5.58515 13.5 5.00272 13.6903 4.54329C13.944 3.93072 14.4307 3.44404 15.0433 3.1903C15.5027 3 16.0851 3 17.25 3C18.4149 3 18.9973 3 19.4567 3.1903C20.0693 3.44404 20.556 3.93072 20.8097 4.54329C21 5.00272 21 5.58515 21 6.75C21 7.91485 21 8.49728 20.8097 8.95671C20.556 9.56928 20.0693 10.056 19.4567 10.3097C18.9973 10.5 18.4149 10.5 17.25 10.5C16.0851 10.5 15.5027 10.5 15.0433 10.3097C14.4307 10.056 13.944 9.56928 13.6903 8.95671Z" stroke="currentColor" strokeLinecap="square" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M3.1903 19.4567C3 18.9973 3 18.4149 3 17.25C3 16.0851 3 15.5027 3.1903 15.0433C3.44404 14.4307 3.93072 13.944 4.54329 13.6903C5.00272 13.5 5.58515 13.5 6.75 13.5C7.91485 13.5 8.49728 13.5 8.95671 13.6903C9.56928 13.944 10.056 14.4307 10.3097 15.0433C10.5 15.5027 10.5 16.0851 10.5 17.25C10.5 18.4149 10.5 18.9973 10.3097 19.4567C10.056 20.0693 9.56928 20.556 8.95671 20.8097C8.49728 21 7.91485 21 6.75 21C5.58515 21 5.00272 21 4.54329 20.8097C3.93072 20.556 3.44404 20.0693 3.1903 19.4567Z" stroke="currentColor" strokeLinecap="square" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M3.1903 8.95671C3 8.49728 3 7.91485 3 6.75C3 5.58515 3 5.00272 3.1903 4.54329C3.44404 3.93072 3.93072 3.44404 4.54329 3.1903C5.00272 3 5.58515 3 6.75 3C7.91485 3 8.49728 3 8.95671 3.1903C9.56928 3.44404 10.056 3.93072 10.3097 4.54329C10.5 5.00272 10.5 5.58515 10.5 6.75C10.5 7.91485 10.5 8.49728 10.3097 8.95671C10.056 9.56928 9.56928 10.056 8.95671 10.3097C8.49728 10.5 7.91485 10.5 6.75 10.5C5.58515 10.5 5.00272 10.5 4.54329 10.3097C3.93072 10.056 3.44404 9.56928 3.1903 8.95671Z" stroke="currentColor" strokeLinecap="square" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Dashboard</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="Projects" title="Projects">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 7H16.75C18.8567 7 19.91 7 20.6667 7.50559C20.9943 7.72447 21.2755 8.00572 21.4944 8.33329C22 9.08996 22 10.1433 22 12.25C22 15.7612 22 17.5167 21.1573 18.7779C20.7926 19.3238 20.3238 19.7926 19.7779 20.1573C18.5167 21 16.7612 21 13.25 21H12C7.28595 21 4.92893 21 3.46447 19.5355C2 18.0711 2 15.714 2 11V7.94427C2 6.1278 2 5.21956 2.38032 4.53806C2.65142 4.05227 3.05227 3.65142 3.53806 3.38032C4.21956 3 5.1278 3 6.94427 3C8.10802 3 8.6899 3 9.19926 3.19101C10.3622 3.62712 10.8418 4.68358 11.3666 5.73313L12 7" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M14 17C14 17 17 14.7905 17 14C17 13.2094 14 11 14 11" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M9.99998 17C9.99998 17 7.00001 14.7905 7 14C6.99999 13.2094 10 11 10 11" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Projects</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="Users / Keys" title="Users / Keys">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M16 21C15.7668 18.0685 13.3422 15.7477 10.3085 15.5521L9.49999 15.5C9.21121 15.5076 8.94209 15.5178 8.68816 15.5298C5.68124 15.6723 3.23089 18.0974 3 21" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M12.75 9.75C12.75 11.5449 11.2949 13 9.5 13C7.70508 13 6.25 11.5449 6.25 9.75C6.25 7.95507 7.70508 6.5 9.5 6.5C11.2949 6.5 12.75 7.95507 12.75 9.75Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M21 17.501C20.7709 14.6314 18.4541 12.2748 15.5 11.9961" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M15.9877 9C16.8965 8.42434 17.5001 7.40788 17.5001 6.25C17.5001 4.45507 16.0496 3 14.2602 3C13.3811 3 12.5838 3.35121 12.0001 3.92139" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Users / Keys</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="Rewards" title="Rewards">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M4 11V15C4 18.2998 4 19.9497 5.02513 20.9749C6.05025 22 7.70017 22 11 22H13C16.2998 22 17.9497 22 18.9749 20.9749C20 19.9497 20 18.2998 20 15V11" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M3 9C3 8.25231 3 7.87846 3.20096 7.6C3.33261 7.41758 3.52197 7.26609 3.75 7.16077C4.09808 7 4.56538 7 5.5 7H18.5C19.4346 7 19.9019 7 20.25 7.16077C20.478 7.26609 20.6674 7.41758 20.799 7.6C21 7.87846 21 8.25231 21 9C21 9.74769 21 10.1215 20.799 10.4C20.6674 10.5824 20.478 10.7339 20.25 10.8392C19.9019 11 19.4346 11 18.5 11H5.5C4.56538 11 4.09808 11 3.75 10.8392C3.52197 10.7339 3.33261 10.5824 3.20096 10.4C3 10.1215 3 9.74769 3 9Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M6 3.78571C6 2.79949 6.79949 2 7.78571 2H8.14286C10.2731 2 12 3.7269 12 5.85714V7H9.21429C7.43908 7 6 5.56091 6 3.78571Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M18 3.78571C18 2.79949 17.2005 2 16.2143 2H15.8571C13.7269 2 12 3.7269 12 5.85714V7H14.7857C16.5609 7 18 5.56091 18 3.78571Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M12 11L12 22" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Rewards</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="Discord" title="Discord">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15.5 17.5C16.5 19 17.3333 19.6667 18 20C19.3333 19.6667 22 18.2 22 15C22 11.8 20.6667 7.33333 20 5.5C18 4.3 15.8333 4 15 4L14.198 5.60393C13.4135 5.28708 12.4058 5.25438 12 5.27763C11.5942 5.25438 10.5865 5.28708 9.80197 5.60393L9 4C8.16667 4 6 4.3 4 5.5C3.33333 7.33333 2 11.8 2 15C2 18.2 4.66667 19.6667 6 20C6.66667 19.6667 7.5 19 8.5 17.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M17.3652 11.5C17.3652 12.6046 16.5817 13.5 15.6152 13.5C14.6487 13.5 13.8652 12.6046 13.8652 11.5C13.8652 10.3954 14.6487 9.5 15.6152 9.5C16.5817 9.5 17.3652 10.3954 17.3652 11.5Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M10 11.5C10 12.6046 9.2165 13.5 8.25 13.5C7.2835 13.5 6.5 12.6046 6.5 11.5C6.5 10.3954 7.2835 9.5 8.25 9.5C9.2165 9.5 10 10.3954 10 11.5Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M17.5 16.5C16.4022 17.3967 14.3502 18 12 18C9.64981 18 7.59785 17.3967 6.5 16.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Discord</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="Obfuscator" title="Obfuscator">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M13.9258 12.7775L11.7775 10.6292C11.4847 10.3364 11.3383 10.19 11.1803 10.1117C10.8798 9.96277 10.527 9.96277 10.2264 10.1117C10.0685 10.19 9.92207 10.3364 9.62923 10.6292C9.33638 10.9221 9.18996 11.0685 9.11169 11.2264C8.96277 11.527 8.96277 11.8798 9.11169 12.1803C9.18996 12.3383 9.33638 12.4847 9.62923 12.7775L11.7775 14.9258M13.9258 12.7775L20.3708 19.2225C20.6636 19.5153 20.81 19.6617 20.8883 19.8197C21.0372 20.1202 21.0372 20.473 20.8883 20.7736C20.81 20.9315 20.6636 21.0779 20.3708 21.3708C20.0779 21.6636 19.9315 21.81 19.7736 21.8883C19.473 22.0372 19.1202 22.0372 18.8197 21.8883C18.6617 21.81 18.5153 21.6636 18.2225 21.3708L11.7775 14.9258M13.9258 12.7775L11.7775 14.9258" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M17 2L17.2948 2.7966C17.6813 3.84117 17.8746 4.36345 18.2556 4.74445C18.6366 5.12545 19.1588 5.31871 20.2034 5.70523L21 6L20.2034 6.29477C19.1588 6.68129 18.6366 6.87456 18.2556 7.25555C17.8746 7.63655 17.6813 8.15883 17.2948 9.2034L17 10L16.7052 9.2034C16.3187 8.15884 16.1254 7.63655 15.7444 7.25555C15.3634 6.87455 14.8412 6.68129 13.7966 6.29477L13 6L13.7966 5.70523C14.8412 5.31871 15.3634 5.12545 15.7444 4.74445C16.1254 4.36345 16.3187 3.84117 16.7052 2.7966L17 2Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M6 4L6.22108 4.59745C6.51097 5.38087 6.65592 5.77259 6.94167 6.05834C7.22741 6.34408 7.61913 6.48903 8.40255 6.77892L9 7L8.40255 7.22108C7.61913 7.51097 7.22741 7.65592 6.94166 7.94167C6.65592 8.22741 6.51097 8.61913 6.22108 9.40255L6 10L5.77892 9.40255C5.48903 8.61913 5.34408 8.22741 5.05833 7.94167C4.77259 7.65592 4.38087 7.51097 3.59745 7.22108L3 7L3.59745 6.77892C4.38087 6.48903 4.77259 6.34408 5.05833 6.05833C5.34408 5.77259 5.48903 5.38087 5.77892 4.59745L6 4Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Obfuscator</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="Decompiler" title="Decompiler">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M2 6C2 5.05719 2 4.58579 2.29289 4.29289C2.58579 4 3.05719 4 4 4C4.94281 4 5.41421 4 5.70711 4.29289C6 4.58579 6 5.05719 6 6V8C6 8.94281 6 9.41421 5.70711 9.70711C5.41421 10 4.94281 10 4 10C3.05719 10 2.58579 10 2.29289 9.70711C2 9.41421 2 8.94281 2 8V6Z" stroke="currentColor" strokeWidth="1.8" />
                  <path d="M6.5 16C6.5 15.0572 6.5 14.5858 6.79289 14.2929C7.08579 14 7.55719 14 8.5 14C9.44281 14 9.91421 14 10.2071 14.2929C10.5 14.5858 10.5 15.0572 10.5 16V18C10.5 18.9428 10.5 19.4142 10.2071 19.7071C9.91421 20 9.44281 20 8.5 20C7.55719 20 7.08579 20 6.79289 19.7071C6.5 19.4142 6.5 18.9428 6.5 18V16Z" stroke="currentColor" strokeWidth="1.8" />
                  <path d="M13.5 6C13.5 5.05719 13.5 4.58579 13.7929 4.29289C14.0858 4 14.5572 4 15.5 4C16.4428 4 16.9142 4 17.2071 4.29289C17.5 4.58579 17.5 5.05719 17.5 6V8C17.5 8.94281 17.5 9.41421 17.2071 9.70711C16.9142 10 16.4428 10 15.5 10C14.5572 10 14.0858 10 13.7929 9.70711C13.5 9.41421 13.5 8.94281 13.5 8V6Z" stroke="currentColor" strokeWidth="1.8" />
                  <path d="M13.5 16C13.5 15.0572 13.5 14.5858 13.7929 14.2929C14.0858 14 14.5572 14 15.5 14C16.4428 14 16.9142 14 17.2071 14.2929C17.5 14.5858 17.5 15.0572 17.5 16V18C17.5 18.9428 17.5 19.4142 17.2071 19.7071C16.9142 20 16.4428 20 15.5 20C14.5572 20 14.0858 20 13.7929 19.7071C13.5 19.4142 13.5 18.9428 13.5 18V16Z" stroke="currentColor" strokeWidth="1.8" />
                  <path d="M9 5L10.5 4V10" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M2 15L3.5 14V20" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M20.5 5L22 4V10" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M20.5 15L22 14V20" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Decompiler</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link sidebar-module__9SB1EG__linkActive" aria-label="Docs" aria-current="page" title="Docs">
              <span className="sidebar-module__9SB1EG__activeSurface" aria-hidden="true" style={{transform: "none", transformOrigin: "50% 50% 0px", opacity: "1"}} />
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15.5 7H8.5M12.499 11H8.49902" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M20 22H6C4.89543 22 4 21.1046 4 20M4 20C4 18.8954 4.89543 18 6 18H20V6C20 4.11438 20 3.17157 19.4142 2.58579C18.8284 2 17.8856 2 16 2H10C7.17157 2 5.75736 2 4.87868 2.87868C4 3.75736 4 5.17157 4 8V20Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M19.5 18C19.5 18 18.5 18.7628 18.5 20C18.5 21.2372 19.5 22 19.5 22" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Docs</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="API" title="API">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M4.00004 17C4.00004 17 9.99999 12.5811 10 11C10 9.41884 4 5 4 5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M12 19H20" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">API</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="MCP Server" title="MCP Server">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19 4H5C4.06812 4 3.60218 4 3.23463 4.15224C2.74458 4.35523 2.35523 4.74458 2.15224 5.23463C2 5.60218 2 6.06812 2 7C2 7.93188 2 8.39782 2.15224 8.76537C2.35523 9.25542 2.74458 9.64477 3.23463 9.84776C3.60218 10 4.06812 10 5 10H19C19.9319 10 20.3978 10 20.7654 9.84776C21.2554 9.64477 21.6448 9.25542 21.8478 8.76537C22 8.39782 22 7.93188 22 7C22 6.06812 22 5.60218 21.8478 5.23463C21.6448 4.74458 21.2554 4.35523 20.7654 4.15224C20.3978 4 19.9319 4 19 4Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M19 14H5C4.06812 14 3.60218 14 3.23463 14.1522C2.74458 14.3552 2.35523 14.7446 2.15224 15.2346C2 15.6022 2 16.0681 2 17C2 17.9319 2 18.3978 2.15224 18.7654C2.35523 19.2554 2.74458 19.6448 3.23463 19.8478C3.60218 20 4.06812 20 5 20H19C19.9319 20 20.3978 20 20.7654 19.8478C21.2554 19.6448 21.6448 19.2554 21.8478 18.7654C22 18.3978 22 17.9319 22 17C22 16.0681 22 15.6022 21.8478 15.2346C21.6448 14.7446 21.2554 14.3552 20.7654 14.1522C20.3978 14 19.9319 14 19 14Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M6.125 7H6M6.25 7C6.25 7.13807 6.13807 7.25 6 7.25C5.86193 7.25 5.75 7.13807 5.75 7C5.75 6.86193 5.86193 6.75 6 6.75C6.13807 6.75 6.25 6.86193 6.25 7Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M10.125 7H10M10.25 7C10.25 7.13807 10.1381 7.25 10 7.25C9.86193 7.25 9.75 7.13807 9.75 7C9.75 6.86193 9.86193 6.75 10 6.75C10.1381 6.75 10.25 6.86193 10.25 7Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M6.125 17H6M6.25 17C6.25 17.1381 6.13807 17.25 6 17.25C5.86193 17.25 5.75 17.1381 5.75 17C5.75 16.8619 5.86193 16.75 6 16.75C6.13807 16.75 6.25 16.8619 6.25 17Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M10.125 17H10M10.25 17C10.25 17.1381 10.1381 17.25 10 17.25C9.86193 17.25 9.75 17.1381 9.75 17C9.75 16.8619 9.86193 16.75 10 16.75C10.1381 16.75 10.25 16.8619 10.25 17Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">MCP Server</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="Changelog" title="Changelog">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.8" />
                  <path d="M12 8V12L14 14" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Changelog</span>
            </button>
            <button type="button" className="sidebar-module__9SB1EG__link" aria-label="Profile" title="Profile">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18.4984 19.1511C17.3377 17.4018 15.2947 16.2009 12.9313 16.0569L11.9984 16C11.6652 16.0083 11.3547 16.0194 11.0617 16.0325C8.71722 16.1376 6.66598 17.3796 5.5 19.1511" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M14.9961 10C14.9961 11.6569 13.6529 13 11.9961 13C10.3392 13 8.99609 11.6569 8.99609 10C8.99609 8.34315 10.3392 7 11.9961 7C13.6529 7 14.9961 8.34315 14.9961 10Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                  <path d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                </svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Profile</span>
            </button>
            <span className="enhanced-sidebar-module__5H-W0q__divider" aria-hidden="true" />
            <button type="button" className="sidebar-module__9SB1EG__link enhanced-sidebar-module__5H-W0q__logout" aria-label="Log out" title="Log out">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-log-out" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m16 17 5-5-5-5" /><path d="M21 12H9" /><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /></svg>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel" aria-hidden="true">Log out</span>
            </button>
          </nav>
          <div className="enhanced-sidebar-module__5H-W0q__account">
            <button type="button" className="sidebar-module__9SB1EG__link enhanced-sidebar-module__5H-W0q__accountButton" aria-label="Zed" title="Zed">
              <span className="sidebar-module__9SB1EG__linkIcon" aria-hidden="true">
                <span className="fa-avatar fa-avatar-sm enhanced-sidebar-module__5H-W0q__avatar" title="Zed">
                  <span className="fa-avatar-fallback" style={{background: "linear-gradient(135deg, rgb(68, 95, 17), rgb(9, 62, 10))", color: "rgb(203, 248, 119)", borderRadius: "inherit"}}>Z</span>
                </span>
              </span>
              <span className="sidebar-module__9SB1EG__linkLabel enhanced-sidebar-module__5H-W0q__accountLabel" aria-hidden="true">Zed</span>
            </button>
          </div>
        </div>
      </aside>
    </div>
    <div className="sidebar-module__9SB1EG__mobileShell">
      <div className="sidebar-module__9SB1EG__mobileBar">
        <span className="sidebar-module__9SB1EG__mobileLabel"><small>Switzauth</small><strong>Docs</strong></span>
        <button type="button" className="sidebar-module__9SB1EG__mobileMenuButton" aria-label="Open workspace navigation" aria-expanded="false" aria-controls="switzauth-mobile-navigation">
          <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-menu" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M4 5h16" /><path d="M4 12h16" /><path d="M4 19h16" /></svg>
          <span>Menu</span>
        </button>
      </div>
    </div>
    <div className="main-content" style={{overflow: "visible !important"}}>
      <header className="enhancedTopBar" style={{opacity: "1", transform: "none"}}>
        <div className="enhancedBreadcrumb" style={{opacity: "1", transform: "none"}}><span>Switzauth</span><span className="enhancedBreadcrumbSlash">/</span><strong>Docs</strong></div>
        <div className="enhancedTopActions" style={{opacity: "1", transform: "none"}}>
          <span className="fa-tip">
            <button type="button" className="flow-btn flow-btn-ghost flow-btn-md enhancedCommandTrigger">
              <span className="flow-btn-sweep" aria-hidden="true" />
              <span className="flow-btn-content">
                <span className="flow-btn-label">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-search" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m21 21-4.34-4.34" /><circle cx="11" cy="11" r="8" /></svg>
                  <span>Search workspace</span>
                  <kbd className="fa-kbd">Ctrl K</kbd>
                </span>
              </span>
            </button>
            <span role="tooltip" className="fa-tip-bubble fa-tip-top">Open command palette<span className="fa-tip-arrow" aria-hidden="true" /></span>
          </span>
          <button type="button" aria-haspopup="dialog" aria-expanded="false" data-state="closed" className="project-collaborators-module__FbxJEW__inboxTrigger" aria-label="Project invitations" title="Project invitations">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-bell" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
              <path d="M10.268 21a2 2 0 0 0 3.464 0" />
              <path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326" />
            </svg>
          </button>
          <button type="button" className="account-menu-module__u2BZwG__trigger" aria-label="Open account menu" id="radix-_r_5_" aria-haspopup="menu" aria-expanded="false" data-state="closed" data-slot="dropdown-menu-trigger">
            <span className="fa-avatar fa-avatar-sm" title="Zed">
              <span className="fa-avatar-fallback" style={{background: "linear-gradient(135deg, rgb(68, 95, 17), rgb(9, 62, 10))", color: "rgb(203, 248, 119)", borderRadius: "inherit"}}>Z</span>
            </span>
            <span className="account-menu-module__u2BZwG__triggerLabel">Account</span>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-down account-menu-module__u2BZwG__chevron" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m6 9 6 6 6-6" /></svg>
          </button>
        </div>
      </header>
      <div data-slot="dialog-header" className="ui-dialog-header sr-only">
        <h2 id="radix-_r_8_" data-slot="dialog-title" className="ui-dialog-title">Switzauth Command Palette</h2>
        <p id="radix-_r_9_" data-slot="dialog-description" className="ui-dialog-description">Search dashboard sections and tools.</p>
      </div>
      <main className="mainWorkspace enhancedMainWorkspace dashboardTabMotionEven" data-active-tab="docs" style={{padding: "32px", overflow: "visible !important"}}>
        <div className="docs-manual-module__BwnM0G__docsExperience" data-docs-manual="true" data-nav-open="false" style={{"--docs-sticky-top": "64px"} as React.CSSProperties}>
          <aside data-docs-sidebar="true" className="docs-manual-module__BwnM0G__docsSidebar">
            <button type="button" className="docs-manual-module__BwnM0G__docsMobileMenu" aria-expanded="false" aria-controls="flowauth-docs-navigation">
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-book-open" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 5v16" />
                <path d="M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z" />
              </svg>
              <span>Quickstart</span>
              <small>Browse guides</small>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
            </button>
            <div className="docs-manual-module__BwnM0G__docsNavHeader">
              <span className="docs-manual-module__BwnM0G__docsNavMark">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-book-open" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 5v16" />
                  <path d="M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z" />
                </svg>
              </span>
              <span><strong>Switzauth Docs</strong><small>Guides & API reference</small></span>
            </div>
            <label className="docs-manual-module__BwnM0G__docsSearch">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-search" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m21 21-4.34-4.34" /><circle cx="11" cy="11" r="8" /></svg>
              <input placeholder="Search docs…" aria-label="Search documentation" type="search" defaultValue="" />
              <kbd>Ctrl K</kbd>
            </label>
            <nav id="flowauth-docs-navigation" data-docs-navigation="true" className="docs-manual-module__BwnM0G__docsNavList" aria-label="Documentation sections">
              <div className="docs-manual-module__BwnM0G__docsNavGroup">
                <span className="docs-manual-module__BwnM0G__docsNavGroupLabel">Get started</span>
                <div className="docs-manual-module__BwnM0G__docsNavGroupItems">
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="intro">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-book-open" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 5v16" />
                      <path d="M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z" />
                    </svg>
                    <span>Overview</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem docs-manual-module__BwnM0G__active" data-docs-section="quickstart" aria-current="page">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-rocket" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" />
                      <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09" />
                      <path d="M9 12a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.4 22.4 0 0 1-4 2z" />
                      <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 .05 5 .05" />
                    </svg>
                    <span>Quickstart</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                </div>
              </div>
              <div className="docs-manual-module__BwnM0G__docsNavGroup">
                <span className="docs-manual-module__BwnM0G__docsNavGroupLabel">Build</span>
                <div className="docs-manual-module__BwnM0G__docsNavGroupItems">
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="projects">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-server-cog" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="m10.852 14.772-.383.923" />
                      <path d="M13.148 14.772a3 3 0 1 0-2.296-5.544l-.383-.923" />
                      <path d="m13.148 9.228.383-.923" />
                      <path d="m13.53 15.696-.382-.924a3 3 0 1 1-2.296-5.544" />
                      <path d="m14.772 10.852.923-.383" />
                      <path d="m14.772 13.148.923.383" />
                      <path d="M4.5 10H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-.5" />
                      <path d="M4.5 14H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-.5" />
                      <path d="M6 18h.01" />
                      <path d="M6 6h.01" />
                      <path d="m9.228 10.852-.923-.383" />
                      <path d="m9.228 13.148-.923.383" />
                    </svg>
                    <span>Projects & scripts</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="loader">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-monitor-smartphone" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M18 8V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8" />
                      <path d="M10 19v-3.96 3.15" />
                      <path d="M7 19h5" />
                      <rect width="6" height="10" x="16" y="12" rx="2" />
                    </svg>
                    <span>Loader & executors</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="server">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-link2 lucide-link-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9 17H7A5 5 0 0 1 7 7h2" />
                      <path d="M15 7h2a5 5 0 1 1 0 10h-2" />
                      <line x1="8" x2="16" y1="12" y2="12" />
                    </svg>
                    <span>Loader & server</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="protection">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-shield-check" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
                      <path d="m9 12 2 2 4-4" />
                    </svg>
                    <span>Protection modes</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="uilib">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-layers" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z" />
                      <path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12" />
                      <path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17" />
                    </svg>
                    <span>Shared UI loader</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="keys">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-key-round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z" />
                      <circle cx="16.5" cy="7.5" r=".5" fill="currentColor" />
                    </svg>
                    <span>Users & keys</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="groups">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-link2 lucide-link-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9 17H7A5 5 0 0 1 7 7h2" />
                      <path d="M15 7h2a5 5 0 1 1 0 10h-2" />
                      <line x1="8" x2="16" y1="12" y2="12" />
                    </svg>
                    <span>Project groups</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                </div>
              </div>
              <div className="docs-manual-module__BwnM0G__docsNavGroup">
                <span className="docs-manual-module__BwnM0G__docsNavGroupLabel">Connect</span>
                <div className="docs-manual-module__BwnM0G__docsNavGroupItems">
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="rewards">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-earth" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M21.54 15H17a2 2 0 0 0-2 2v4.54" />
                      <path d="M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17" />
                      <path d="M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05" />
                      <circle cx="12" cy="12" r="10" />
                    </svg>
                    <span>Reward gateway</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="integrations">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-bot" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <path d="M12 8V4H8" />
                      <rect width="16" height="12" x="4" y="8" rx="2" />
                      <path d="M2 14h2" />
                      <path d="M20 14h2" />
                      <path d="M15 13v2" />
                      <path d="M9 13v2" />
                    </svg>
                    <span>Discord bot</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="api">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-terminal" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M12 19h8" /><path d="m4 17 6-6-6-6" /></svg>
                    <span>Automation & API</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                </div>
              </div>
              <div className="docs-manual-module__BwnM0G__docsNavGroup">
                <span className="docs-manual-module__BwnM0G__docsNavGroupLabel">Help</span>
                <div className="docs-manual-module__BwnM0G__docsNavGroupItems">
                  <button type="button" className="docs-manual-module__BwnM0G__docsNavItem" data-docs-section="troubleshooting">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-life-buoy" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="12" cy="12" r="10" />
                      <path d="m4.93 4.93 4.24 4.24" />
                      <path d="m14.83 9.17 4.24-4.24" />
                      <path d="m14.83 14.83 4.24 4.24" />
                      <path d="m9.17 14.83-4.24 4.24" />
                      <circle cx="12" cy="12" r="4" />
                    </svg>
                    <span>Troubleshooting</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right docs-manual-module__BwnM0G__bullet" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
                  </button>
                </div>
              </div>
            </nav>
            <div className="docs-manual-module__BwnM0G__docsVersionBox">
              <span>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-life-buoy" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="12" cy="12" r="10" />
                  <path d="m4.93 4.93 4.24 4.24" />
                  <path d="m14.83 9.17 4.24-4.24" />
                  <path d="m14.83 14.83 4.24 4.24" />
                  <path d="m9.17 14.83-4.24 4.24" />
                  <circle cx="12" cy="12" r="4" />
                </svg>{" "}
                Need a hand?
              </span>
              <a href="https://discord.gg/XnMhR8U4VQ" target="_blank" rel="noreferrer">
                Ask the community{" "}
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-external-link" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15 3h6v6" />
                  <path d="M10 14 21 3" />
                  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                </svg>
              </a>
            </div>
          </aside>
          <div className="docs-manual-module__BwnM0G__docsBody">
            <div className="docs-manual-module__BwnM0G__docsBreadcrumb" aria-label="Documentation location">
              <span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-book-open" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 5v16" />
                  <path d="M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z" />
                </svg>{" "}
                Documentation
              </span>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
              <strong>Quickstart</strong>
            </div>
            <details className="docs-manual-module__BwnM0G__docsMobileContents">
              <summary>
                On this page{" "}
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m9 18 6-6-6-6" /></svg>
              </summary>
              <nav aria-label="Page contents">
                <a href="/docs/quickstart#docs-quickstart-the-exact-command-to-test">The exact command to test</a>
              </nav>
            </details>
            <div className="docs-manual-module__BwnM0G__docsReadingLayout">
              <article data-docs-content="true" className="docs-manual-module__BwnM0G__docsContent" tabIndex={-1}>
                <section className="docs-manual-module__BwnM0G__docsSection">
                  <header className="docs-manual-module__BwnM0G__docsSectionHeader">
                    <span>First project</span>
                    <h1>Get a working loader in four steps</h1>
                    <p>Do this once with a test key. Add rewards and integrations only after the loader appears in Live Logs.</p>
                  </header>
                  <div className="docs-manual-module__BwnM0G__docsStepList">
                    <article className="docs-manual-module__BwnM0G__docsStepCard">
                      <div className="docs-manual-module__BwnM0G__docsStepIndex">01</div>
                      <div>
                        <h3>Create the project</h3>
                        <p>Open Projects, choose New Project, and use a short name your team will recognize in keys, rewards, and logs.</p>
                        <span className="docs-manual-module__BwnM0G__docsStepResult">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-circle-check" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></svg>
                          {" "}One project now owns the scripts, keys, and audit history.
                        </span>
                      </div>
                    </article>
                    <article className="docs-manual-module__BwnM0G__docsStepCard">
                      <div className="docs-manual-module__BwnM0G__docsStepIndex">02</div>
                      <div>
                        <h3>Publish one script</h3>
                        <p>Choose Add Script, paste or upload the Lua/Luau source, select its scope and access tier, then publish it.</p>
                        <span className="docs-manual-module__BwnM0G__docsStepResult">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-circle-check" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></svg>
                          {" "}The script row now has a unique loader URL.
                        </span>
                      </div>
                    </article>
                    <article className="docs-manual-module__BwnM0G__docsStepCard">
                      <div className="docs-manual-module__BwnM0G__docsStepIndex">03</div>
                      <div>
                        <h3>Create a test key</h3>
                        <p>Open Users / Keys and create one Premium key for this project. Copy the full value; keys are case-sensitive.</p>
                        <span className="docs-manual-module__BwnM0G__docsStepResult">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-circle-check" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></svg>
                          {" "}The key is ready but its timed duration has not started yet.
                        </span>
                      </div>
                    </article>
                    <article className="docs-manual-module__BwnM0G__docsStepCard">
                      <div className="docs-manual-module__BwnM0G__docsStepIndex">04</div>
                      <div>
                        <h3>Run the two-line loader</h3>
                        <p>
                          Put script_key directly above the copied loader command. Run both lines together, then verify the success entry in Live Logs.
                        </p>
                        <span className="docs-manual-module__BwnM0G__docsStepResult">
                          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-circle-check" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" /><path d="m9 12 2 2 4-4" /></svg>
                          {" "}The loader is ready to hand to a real user.
                        </span>
                      </div>
                    </article>
                  </div>
                  <h2 className="docs-manual-module__BwnM0G__docsSubheading" id="docs-quickstart-the-exact-command-to-test">The exact command to test</h2>
                  <div data-docs-code="true" className="docs-manual-module__BwnM0G__docsCodePanel docs-manual-module__BwnM0G__isWrapped">
                    <div className="docs-manual-module__BwnM0G__docsCodeHead">
                      <span className="docs-manual-module__BwnM0G__docsCodeLabel">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-file-code-corner" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                          <path d="M4 12.15V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-3.35" />
                          <path d="M14 2v5a1 1 0 0 0 1 1h5" />
                          <path d="m5 16-3 3 3 3" />
                          <path d="m9 22 3-3-3-3" />
                        </svg>{" "}
                        Premium loader · paste both lines together
                      </span>
                      <div className="docs-manual-module__BwnM0G__docsCodeTools">
                        <span className="docs-manual-module__BwnM0G__docsCodeLanguage">Luau</span>
                        <button type="button" className="docs-manual-module__BwnM0G__docsCodeAction" aria-label="Wrap lines" aria-pressed="true" title="Wrap lines">
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-text-wrap" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m16 16-3 3 3 3" /><path d="M3 12h14.5a1 1 0 0 1 0 7H13" /><path d="M3 19h6" /><path d="M3 5h18" /></svg>
                        </button>
                        <button type="button" className="docs-manual-module__BwnM0G__docsCodeAction docs-manual-module__BwnM0G__docsCopyBtn" aria-label="Copy Premium loader · paste both lines together">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-copy" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                            <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
                            <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
                          </svg>
                          <span aria-live="polite">Copy</span>
                        </button>
                      </div>
                    </div>
                    <pre className="docs-manual-module__BwnM0G__docsCodeBlock" tabIndex={0} aria-label="Premium loader · paste both lines together">
                      <code>
                        <span className="docs-manual-module__BwnM0G__docsCodeLine">
                          <i aria-hidden="true">01</i>
                          <span data-docs-code-text="true" className="docs-manual-module__BwnM0G__docsCodeText">
                            <span className="docs-manual-module__BwnM0G__docsCodeToken" data-token="plain">script_key=</span>
                            <span className="docs-manual-module__BwnM0G__docsCodeToken" data-token="string">"FLOW-REPLACE-WITH-YOUR-KEY"</span>
                            <span className="docs-manual-module__BwnM0G__docsCodeToken" data-token="plain">;</span>
                          </span>
                        </span>
                        <span className="docs-manual-module__BwnM0G__docsCodeLine">
                          <i aria-hidden="true">02</i>
                          <span data-docs-code-text="true" className="docs-manual-module__BwnM0G__docsCodeText">
                            <span className="docs-manual-module__BwnM0G__docsCodeToken" data-token="plain">loadstring(game:HttpGet(</span>
                            <span className="docs-manual-module__BwnM0G__docsCodeToken" data-token="string">"https://switzauth.net/v1/loaders/{"<"}loader-hash{">"}.lua"</span>
                            <span className="docs-manual-module__BwnM0G__docsCodeToken" data-token="plain">))(script_key)</span>
                          </span>
                        </span>
                      </code>
                    </pre>
                  </div>
                  <div className="docs-manual-module__BwnM0G__docsCallout" data-tone="note">
                    <div className="docs-manual-module__BwnM0G__docsCalloutIcon">
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-key-round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                        <path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z" />
                        <circle cx="16.5" cy="7.5" r=".5" fill="currentColor" />
                      </svg>
                    </div>
                    <div>
                      <strong>script_key is a temporary global, not a workspace file</strong>
                      <p>
                        The official command passes{" "}
                        <code>script_key</code>{" "}
                        directly into the launcher. The runtime also reads the executor global for compatibility, trims leading/trailing whitespace, then clears it before authentication. Keep the Lua quotes around the value and never rename the variable.
                      </p>
                    </div>
                  </div>
                  <div className="docs-manual-module__BwnM0G__docsFlowStrip">
                    <span>Project</span>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
                    <span>Script</span>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
                    <span>Test key</span>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
                    <span>Live Logs</span>
                  </div>
                  <div className="docs-manual-module__BwnM0G__docsChecklist">
                    <h3>Before you invite users</h3>
                    <ul>
                      <li>Run the loader in the scope you selected.</li>
                      <li>Confirm a successful auth and fetch in Live Logs.</li>
                      <li>Try one bad key so you know the failure message is clear.</li>
                      <li>Keep the test project separate if you plan to change settings often.</li>
                    </ul>
                  </div>
                </section>
                <footer className="docs-manual-module__BwnM0G__docsPager" aria-label="Documentation pagination">
                  <button type="button">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m12 19-7-7 7-7" /><path d="M19 12H5" /></svg>
                    <span><small>Previous</small><strong>Overview</strong></span>
                  </button>
                  <button type="button">
                    <span><small>Next</small><strong>Projects & scripts</strong></span>
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
                  </button>
                </footer>
              </article>
              <aside className="docs-manual-module__BwnM0G__docsPageIndex" aria-label="On this page">
                <span>On this page</span>
                <nav>
                  <a href="/docs/quickstart#docs-quickstart-the-exact-command-to-test" aria-current="location">The exact command to test</a>
                </nav>
                <a className="docs-manual-module__BwnM0G__docsIndexSupport" href="https://discord.gg/XnMhR8U4VQ" target="_blank" rel="noreferrer">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-life-buoy" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" />
                    <path d="m4.93 4.93 4.24 4.24" />
                    <path d="m14.83 9.17 4.24-4.24" />
                    <path d="m14.83 14.83 4.24 4.24" />
                    <path d="m9.17 14.83-4.24 4.24" />
                    <circle cx="12" cy="12" r="4" />
                  </svg>{" "}
                  Get help{" "}
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-right" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M5 12h14" /><path d="m12 5 7 7-7 7" /></svg>
                </a>
              </aside>
            </div>
          </div>
        </div>
      </main>
    </div>
  </div>  );
}
