#!/usr/bin/env python3
"""Convert controlled value/checked props on static ported markup to
defaultValue/defaultChecked (the ported pages are display snapshots)."""
import re
import sys

def fix(path: str) -> None:
    src = open(path, encoding="utf-8").read()
    def tag_fix(m):
        tag = m.group(0)
        tag = re.sub(r'(?<![-\w])value="', 'defaultValue="', tag)
        tag = re.sub(r'(?<![-\w])checked(?![\w-])', 'defaultChecked', tag)
        return tag
    out = re.sub(r'<(?:input|textarea|select)\b[^>]*>', tag_fix, src, flags=re.S)
    if out != src:
        open(path, "w", encoding="utf-8").write(out)
        print("fixed", path)
    else:
        print("clean", path)

for p in sys.argv[1:]:
    fix(p)
