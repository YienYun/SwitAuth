#!/usr/bin/env python3
"""Convert scraped FlowAuth HTML bodies into JSX components (1:1 port). v2"""
import re
import sys
from bs4 import BeautifulSoup, Comment, NavigableString, Tag

VOID = {
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link",
    "meta", "param", "source", "track", "wbr", "circle", "ellipse", "line",
    "path", "polygon", "polyline", "rect", "stop", "use",
}

TAG_FIX = {
    "lineargradient": "linearGradient", "radialgradient": "radialGradient",
    "clippath": "clipPath", "textpath": "textPath", "fegaussianblur": "feGaussianBlur",
    "feblend": "feBlend", "fecolormatrix": "feColorMatrix", "feoffset": "feOffset",
    "feflood": "feFlood", "fecomposite": "feComposite", "femerge": "feMerge",
    "femergenode": "feMergeNode", "linearGradient": "linearGradient",
    "mask": "mask", "filter": "filter", "lineargradient": "linearGradient",
}

ATTR_MAP = {
    "class": "className", "for": "htmlFor", "tabindex": "tabIndex",
    "colspan": "colSpan", "rowspan": "rowSpan", "srcset": "srcSet",
    "readonly": "readOnly", "maxlength": "maxLength", "minlength": "minLength",
    "datetime": "dateTime", "crossorigin": "crossOrigin",
    "referrerpolicy": "referrerPolicy", "spellcheck": "spellCheck",
    "autocomplete": "autoComplete", "autofocus": "autoFocus",
    "autoplay": "autoPlay", "enctype": "encType", "novalidate": "noValidate",
    "frameborder": "frameBorder", "allowfullscreen": "allowFullScreen",
    "playsinline": "playsInline", "accesskey": "accessKey",
    "cellpadding": "cellPadding", "cellspacing": "cellSpacing",
    "contenteditable": "contentEditable", "contextmenu": "contextMenu",
    "usemap": "useMap", "xmlns:xlink": "xmlnsXlink", "xlink:href": "xlinkHref",
    "viewbox": "viewBox", "stroke-width": "strokeWidth",
    "stroke-linecap": "strokeLinecap", "stroke-linejoin": "strokeLinejoin",
    "stroke-dasharray": "strokeDasharray", "stroke-dashoffset": "strokeDashoffset",
    "stroke-miterlimit": "strokeMiterlimit", "stroke-opacity": "strokeOpacity",
    "fill-rule": "fillRule", "fill-opacity": "fillOpacity",
    "clip-rule": "clipRule", "clip-path": "clipPath",
    "stop-color": "stopColor", "stop-opacity": "stopOpacity",
    "flood-color": "floodColor", "flood-opacity": "floodOpacity",
    "font-family": "fontFamily", "font-size": "fontSize",
    "font-weight": "fontWeight", "text-anchor": "textAnchor",
    "dominant-baseline": "dominantBaseline", "gradientunits": "gradientUnits",
    "patternunits": "patternUnits", "patterncontentunits": "patternContentUnits",
    "preserveaspectratio": "preserveAspectRatio", "maskunits": "maskUnits",
    "maskcontentunits": "maskContentUnits", "filterunits": "filterUnits",
    "spreadmethod": "spreadMethod", "gradienttransform": "gradientTransform",
    "patterntransform": "patternTransform", "strokewidth": "strokeWidth",
    "marker-end": "markerEnd", "marker-start": "markerStart",
    "clippathunits": "clipPathUnits", "color-interpolation-filters": "colorInterpolationFilters",
    "baseprofile": "baseProfile", "requiredextensions": "requiredExtensions",
    "xlink:title": "xlinkTitle", "xlink:show": "xlinkShow",
    "charoff": "charOff", "charset": "charSet", "scramble": "data-scramble",
    "alphabetic": "alphabetic", "accent-height": "accentHeight",
    "keypoints": "keyPoints", "keysplines": "keySplines", "keytimes": "keyTimes",
    "repeatcount": "repeatCount", "attributename": "attributeName",
    "calcmode": "calcMode", "tablevalues": "tableValues",
    "vals": "values", "values": "values", "result": "result", "in2": "in2",
    "in": "in", "mode": "mode", "stddeviation": "stdDeviation",
    "word-spacing": "wordSpacing", "letter-spacing": "letterSpacing",
    "paint-order": "paintOrder", "shape-rendering": "shapeRendering",
    "text-rendering": "textRendering", "image-rendering": "imageRendering",
    "vector-effect": "vectorEffect", "alignment-baseline": "alignmentBaseline",
    "baseline-shift": "baselineShift", "color-interpolation": "colorInterpolation",
    "enable-background": "enableBackground", "writing-mode": "writingMode",
    "glyph-orientation-vertical": "glyphOrientationVertical",
    "pathlength": "pathLength", "systemlanguage": "systemLanguage",
    "requiredfeatures": "requiredFeatures", "zoomandpan": "zoomAndPan",
}

KEEP_KEBAB = ("data-", "aria-")

def map_attr_name(name: str) -> str:
    low = name.lower()
    if low.startswith(KEEP_KEBAB):
        return name
    if low in ATTR_MAP:
        return ATTR_MAP[low]
    if "-" in low:
        return low
    return low

def camelize_css_prop(p: str) -> str:
    p = p.strip().lower()
    if p.startswith("--"):
        return '"%s"' % p
    parts = p.split("-")
    return parts[0] + "".join(w.capitalize() for w in parts[1:])

def convert_style(style: str) -> str:
    decls = [d for d in style.split(";") if d.strip()]
    out = []
    for d in decls:
        if ":" not in d:
            continue
        prop, val = d.split(":", 1)
        out.append("%s: %s" % (camelize_css_prop(prop), js_str(val.strip())))
    return "{%s}" % ", ".join(out)

def js_str(v: str) -> str:
    v = v.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    return '"%s"' % v

def esc_text_core(t: str) -> str:
    """Escape text so JSX preserves it exactly. Use expression braces for
    characters that would break JSX parsing; leave & as-is."""
    out = []
    for ch in t:
        if ch == "<":
            out.append('{"<"}')
        elif ch == ">":
            out.append('{">"}')
        elif ch == "{":
            out.append('{"{"}')
        elif ch == "}":
            out.append('{"}"}')
        else:
            out.append(ch)
    return "".join(out)

def rewrite_src(src: str) -> str:
    m = re.match(r"^\.?/?example \d+_files/(.+)$", src)
    if m:
        name = m.group(1)
        name = name.replace("flowauth-logo.png", "brand/flowauth-logo.png")
        name = name.replace("icon.png", "brand/icon.png")
        name = name.replace("favicon.ico", "brand/favicon.ico")
        return "/" + name
    return src

def render_attrs(tag: Tag) -> str:
    parts = []
    NUMERIC_PROPS = {"tabIndex", "colSpan", "rowSpan", "maxLength", "minLength"}
    # Elements that legitimately accept width/height attributes
    SIZEABLE = VOID | {"svg", "iframe", "video", "embed", "object", "canvas"}
    for name, val in tag.attrs.items():
        if isinstance(val, list):
            val = " ".join(val)
        low = name.lower()
        # recharts renders width/height/xmlns on <div> wrappers; React DOM
        # rejects them. The inline style already carries the real size.
        if tag.name not in SIZEABLE and low in ("width", "height", "xmlns"):
            continue
        if low == "style":
            if not str(val).strip():
                continue
            style_obj = convert_style(val)
            # Custom properties are not in React's CSSProperties type.
            if '"--' in style_obj or "'--" in style_obj:
                style_obj += " as React.CSSProperties"
            parts.append("style={%s}" % style_obj)
            continue
        mapped = map_attr_name(name)
        if low == "src" and isinstance(val, str):
            val = rewrite_src(val)
        if mapped in NUMERIC_PROPS and isinstance(val, str) and re.fullmatch(r"-?\d+", val):
            parts.append("%s={%s}" % (mapped, val))
            continue
        if val is True or val == "":
            if name.lower() in ("disabled", "checked", "selected", "readonly", "multiple", "hidden", "required", "open", "autofocus", "autoplay", "controls", "loop", "muted"):
                parts.append(mapped)
            else:
                parts.append('%s=""' % mapped)
        else:
            if name.lower() == "style":
                parts.append("style={%s}" % convert_style(val))
            else:
                parts.append("%s=%s" % (mapped, js_str(str(val))))
    return (" " + " ".join(parts)) if parts else ""

def render(tag: Tag, depth: int) -> str:
    pad = "  " * depth
    raw_name = tag.name
    name = TAG_FIX.get(raw_name, TAG_FIX.get(raw_name.lower(), raw_name))
    low = raw_name.lower()
    attrs = render_attrs(tag)
    if low in ("script", "style"):
        return ""
    # build parts: ('text', s) | ('ws',) | ('tag', jsx)
    parts = []
    for c in tag.children:
        if isinstance(c, Comment):
            continue
        if isinstance(c, NavigableString):
            s = str(c)
            if low in ("pre", "textarea"):
                parts.append(("text", esc_text_core(s)))
                continue
            s = re.sub(r"\s+", " ", s)
            if s == " ":
                parts.append(("ws", None))
                continue
            lead = s.startswith(" ")
            trail = s.endswith(" ")
            core = s.strip()
            if lead:
                parts.append(("ws", None))
            parts.append(("text", esc_text_core(core)))
            if trail:
                parts.append(("ws", None))
        else:
            r = render(c, 0)
            if r:
                parts.append(("tag", r))
    if low in VOID or not parts:
        return "%s<%s%s />" % (pad, name, attrs)
    # inline check
    total = sum(len(p[1]) if p[0] != "ws" else 1 for p in parts)
    inline = total < 112 and all(p[0] != "tag" or len(p[1]) < 112 for p in parts)
    if inline:
        buf = []
        for p in parts:
            if p[0] == "ws":
                buf.append(" ")
            elif p[0] == "text":
                buf.append(p[1])
            else:
                buf.append(p[1])
        return "%s<%s%s>%s</%s>" % (pad, name, attrs, "".join(buf), name)
    # multiline: attach ws markers to neighbour lines
    lines = []
    pending_pre = None  # ws before next content on next line
    for p in parts:
        if p[0] == "ws":
            if lines:
                # attach to end of previous line if room
                if lines[-1].endswith('{" "}') is False and len(lines[-1]) < 200:
                    lines[-1] = lines[-1] + '{" "}'
                else:
                    pending_pre = True
            else:
                pending_pre = True
            continue
        content_parts = []
        if pending_pre is True:
            content_parts.append('{" "}')
            pending_pre = None
        if p[0] == "text":
            content_parts.append(p[1])
            lines.append("%s  %s" % (pad, "".join(content_parts)))
        else:
            sub = p[1]
            first = True
            for ln in sub.split("\n"):
                if first and content_parts:
                    lines.append("%s  %s%s" % (pad, "".join(content_parts), ln))
                    content_parts = []
                    first = False
                else:
                    lines.append("%s  %s" % (pad, ln))
    return "%s<%s%s>\n%s\n%s</%s>" % (pad, name, attrs, "\n".join(lines), pad, name)

def clean_soup(soup: BeautifulSoup):
    for sel in ["script", "noscript", "aside#flowauth-startup-recovery", "style"]:
        for el in soup.select(sel):
            el.decompose()
    for el in soup.find_all("div", attrs={"hidden": True}):
        el.decompose()
    for c in list(soup.find_all(string=lambda s: isinstance(s, Comment))):
        c.extract()

def find_root(body: BeautifulSoup):
    for sel in ["div.landing-module__I_lyca__page", "div.dashboard-layout"]:
        el = body.select_one(sel)
        if el:
            return el
    for child in body.children:
        if isinstance(child, Tag):
            return child
    return body

def main():
    src_file, out_file = sys.argv[1], sys.argv[2]
    raw = open(src_file, encoding="utf-8").read()
    body_html = raw[raw.find("<body"):]
    soup = BeautifulSoup(body_html, "html5lib")
    body = soup.body if soup.body else soup
    clean_soup(body)
    root = find_root(body)
    jsx = render(root, 1)
    open(out_file, "w", encoding="utf-8").write(jsx)
    print("wrote", out_file, len(jsx), "chars")

if __name__ == "__main__":
    main()
