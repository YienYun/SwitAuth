#!/usr/bin/env python3
"""Unfreeze scraped entry animations on dashboard bodies:
- sidebar clip-path (captured mid-collapse) -> expanded
- opacity:0 frozen labels/cards -> visible"""
import re
import sys

PATTERNS = [
    (re.compile(r' style=\{\{clipPath: "inset\([^)]*\)"\}\}'), ""),
    (re.compile(r' style=\{\{opacity: "0", transform: "translateX\(-0\.0001961px\)"\}\}'), ""),
    (re.compile(r' style=\{\{opacity: "0", transform: "translateX\(-8px\)"\}\}'), ""),
    (re.compile(r' style=\{\{opacity: "0", transform: "translateY\([0-9.]+px\)"\}\}'), ""),
]

def main():
    for path in sys.argv[1:]:
        src = open(path, encoding="utf-8").read()
        orig = src
        for pat, repl in PATTERNS:
            src = pat.sub(repl, src)
        if src != orig:
            open(path, "w", encoding="utf-8").write(src)
            print("unfroze", path)
        else:
            print("clean  ", path)

if __name__ == "__main__":
    main()
