"use client";

import { useKeyCounts } from "./useKeyCounts";

/**
 * The "Users chart" panel-header total. Rendered identically to the captured
 * static strong ("1") for SSR, then follows the persisted key count live.
 */
export default function LivePanelTotal() {
  const { total } = useKeyCounts();
  return <strong>{total}</strong>;
}
