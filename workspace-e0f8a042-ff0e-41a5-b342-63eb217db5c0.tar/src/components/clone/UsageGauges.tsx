"use client";

import { useEffect, useState } from "react";
import { useKeyCounts } from "./useKeyCounts";

/**
 * "Your limits" gauge grid — the captured static server payload made live.
 *
 * The scraped dashboard shipped three usage gauges rendered from the account
 * payload (issued keys 1/100, obfuscations 4/1,000, executions·24h uncapped
 * with 0 device IDs). The single-tenant clone now hydrates the same markup
 * from its honest local sources, keeping the initial render byte-identical
 * to the capture:
 *
 *   • Issued keys      → length of the persisted key records
 *                        ("switzauth-keys-v1", seeded with the captured
 *                        demo key → 1), "N left on this plan" = 100 − N.
 *   • Obfuscations     → captured plan baseline 4 plus the obfuscation runs
 *                        this browser performed ("switzauth-obf-runs-v1"),
 *                        "N left on this plan" = 1,000 − N.
 *   • Executions · 24h → executions_24h / unique_devices_24h from the
 *                        decompiled activity contract
 *                        (GET /api/v1/public/activity?range=24h — the same
 *                        endpoint LiveExecutionsChart validates against).
 *
 * Geometry reproduces the capture exactly: the dial is a 270° arc of radius
 * 42 whose full length is 197.92033717615698; strokeDashoffset =
 * length · (1 − used/cap) — which re-produces the captured inline values
 * 195.9411338043954 (1 of 100) and 197.12865582745235 (4 of 1,000) bit for
 * bit, and stays 0 for the uncapped card. `--ug-figure-size` follows the
 * captured 24.8px for 1–2 digit figures and steps down for longer values.
 */

const ARC_LENGTH = 197.92033717615698;
const KEY_CAP = 100;
const OBFUSCATION_CAP = 1000;
/** Captured account payload baseline (server-side plan usage). */
const OBFUSCATION_BASELINE = 4;
const RUNS_KEY = "switzauth-obf-runs-v1";
/** Same-tab propagation (dispatched by recordObfuscationRun); cross-tab
 * propagation rides the native `storage` event — the same dual-channel the
 * key-count metrics use ("switzauth-keys-changed" + storage). */
export const OBF_RUNS_CHANGED_EVENT = "switzauth-obf-runs-changed";

/** Record the completed obfuscation so the gauge reflects this browser's runs.
 * Returns the new plan-usage count (captured baseline + local runs). */
export function recordObfuscationRun(): number {
  let next = OBFUSCATION_BASELINE + 1;
  try {
    const raw = window.localStorage.getItem(RUNS_KEY);
    const runs = raw ? Number(JSON.parse(raw)?.runs) : 0;
    next = OBFUSCATION_BASELINE + (Number.isSafeInteger(runs) && runs >= 0 ? runs + 1 : 1);
    window.localStorage.setItem(RUNS_KEY, JSON.stringify({ runs: next - OBFUSCATION_BASELINE }));
    window.dispatchEvent(new CustomEvent(OBF_RUNS_CHANGED_EVENT));
  } catch {
    /* persistence is best-effort — the pipeline result is unaffected */
  }
  return next;
}

/** Current plan-usage count (captured baseline + runs this browser made). */
export function readObfuscationCount(): number {
  return countObfuscations();
}

function figureSizeFor(value: number): string {
  const digits = String(value).length;
  if (digits <= 2) return "24.8px";
  if (digits === 3) return "21px";
  if (digits === 4) return "18px";
  return "15px";
}

function figureLabel(value: number): string {
  return value >= 1000 ? value.toLocaleString("en-US") : String(value);
}

function dashOffsetFor(used: number, cap: number): number {
  const ratio = Math.min(used / cap, 1);
  return ARC_LENGTH * (1 - ratio);
}

function countObfuscations(): number {
  try {
    const raw = window.localStorage.getItem(RUNS_KEY);
    const runs = raw ? Number(JSON.parse(raw)?.runs) : 0;
    return OBFUSCATION_BASELINE + (Number.isSafeInteger(runs) && runs >= 0 ? runs : 0);
  } catch {
    return OBFUSCATION_BASELINE;
  }
}

/** Live plan-usage count for the Obfuscations gauge — follows the runs store
 * across tabs (native `storage` event) and within the tab (the
 * `switzauth-obf-runs-changed` event dispatched by recordObfuscationRun),
 * so a second open dashboard tab updates without a remount. */
export function useObfuscationCount(): number {
  const [count, setCount] = useState<number>(OBFUSCATION_BASELINE);

  useEffect(() => {
    // Initial read deferred to a rAF (codebase pattern — avoids the
    // synchronous setState-in-effect cascade).
    const frame = requestAnimationFrame(() => setCount(countObfuscations()));
    const onStorage = (event: StorageEvent) => {
      if (!event.key || event.key === RUNS_KEY) setCount(countObfuscations());
    };
    const onChanged = () => setCount(countObfuscations());
    window.addEventListener("storage", onStorage);
    window.addEventListener(OBF_RUNS_CHANGED_EVENT, onChanged);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("storage", onStorage);
      window.removeEventListener(OBF_RUNS_CHANGED_EVENT, onChanged);
    };
  }, []);

  return count;
}

export default function UsageGauges() {
  // Issued keys follow the shared live metrics hook (same source as the
  // "Active keys" stat and the users-chart total).
  const { total: keyCount } = useKeyCounts();
  // Obfuscations follow the live runs store (cross-tab included).
  const obfCount = useObfuscationCount();
  const [executions, setExecutions] = useState(0);
  const [devices, setDevices] = useState(0);

  useEffect(() => {
    // Same decompiled activity contract LiveExecutionsChart consumes — the
    // gauge stays at the captured zero series if the fetch fails.
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 20000);
    fetch("/api/v1/public/activity?range=24h", { signal: controller.signal })
      .then((response) => (response.ok ? response.json() : Promise.reject(new Error(String(response.status)))))
      .then((data: unknown) => {
        const payload = data as { executions_24h?: unknown; unique_devices_24h?: unknown };
        const nextExecutions = Number(payload?.executions_24h);
        const nextDevices = Number(payload?.unique_devices_24h);
        if (Number.isSafeInteger(nextExecutions) && nextExecutions >= 0) setExecutions(nextExecutions);
        if (Number.isSafeInteger(nextDevices) && nextDevices >= 0) setDevices(nextDevices);
      })
      .catch(() => {
        /* keep the captured zero series */
      })
      .finally(() => window.clearTimeout(timeout));
    return () => {
      controller.abort();
      window.clearTimeout(timeout);
    };
  }, []);

  const keysLeft = Math.max(KEY_CAP - keyCount, 0);
  const obfLeft = Math.max(OBFUSCATION_CAP - obfCount, 0);

  return (
    <div className="usageGrid usage-gauge-module__vRAYnG__grid">
      <article className="usage-gauge-module__vRAYnG__card">
        <div className="usage-gauge-module__vRAYnG__dial">
          <svg viewBox="0 0 108 108" aria-hidden="true">
            <defs>
              <linearGradient id="ug_r_a_" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#7c5cff" /><stop offset="100%" stopColor="#c44be8" /></linearGradient>
            </defs>
            <path className="usage-gauge-module__vRAYnG__track" d="M 24.301515190165006 83.698484809835 A 42 42 0 1 1 83.69848480983504 83.69848480983497" />
            <path className="usage-gauge-module__vRAYnG__value" d="M 24.301515190165006 83.698484809835 A 42 42 0 1 1 83.69848480983504 83.69848480983497" stroke="#6a46ff" strokeDasharray={ARC_LENGTH} strokeDashoffset={dashOffsetFor(keyCount, KEY_CAP)} />
          </svg>
          <div className="usage-gauge-module__vRAYnG__readout">
            <span className="usage-gauge-module__vRAYnG__figure" title={String(keyCount)} style={{"--ug-figure-size": figureSizeFor(keyCount)} as React.CSSProperties}>{figureLabel(keyCount)}</span>
            <span className="usage-gauge-module__vRAYnG__cap">of {KEY_CAP}</span>
          </div>
        </div>
        <div className="usage-gauge-module__vRAYnG__body">
          <span className="usage-gauge-module__vRAYnG__label">Issued keys</span>
          <span className="usage-gauge-module__vRAYnG__sub">{keysLeft} left on this plan</span>
        </div>
      </article>
      <article className="usage-gauge-module__vRAYnG__card">
        <div className="usage-gauge-module__vRAYnG__dial">
          <svg viewBox="0 0 108 108" aria-hidden="true">
            <defs>
              <linearGradient id="ug_r_b_" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#7c5cff" /><stop offset="100%" stopColor="#c44be8" /></linearGradient>
            </defs>
            <path className="usage-gauge-module__vRAYnG__track" d="M 24.301515190165006 83.698484809835 A 42 42 0 1 1 83.69848480983504 83.69848480983497" />
            <path className="usage-gauge-module__vRAYnG__value" d="M 24.301515190165006 83.698484809835 A 42 42 0 1 1 83.69848480983504 83.69848480983497" stroke="#6a46ff" strokeDasharray={ARC_LENGTH} strokeDashoffset={dashOffsetFor(obfCount, OBFUSCATION_CAP)} />
          </svg>
          <div className="usage-gauge-module__vRAYnG__readout">
            <span className="usage-gauge-module__vRAYnG__figure" title={String(obfCount)} style={{"--ug-figure-size": figureSizeFor(obfCount)} as React.CSSProperties}>{figureLabel(obfCount)}</span>
            <span className="usage-gauge-module__vRAYnG__cap">of 1,000</span>
          </div>
        </div>
        <div className="usage-gauge-module__vRAYnG__body">
          <span className="usage-gauge-module__vRAYnG__label">Obfuscations</span>
          <span className="usage-gauge-module__vRAYnG__sub">{obfLeft.toLocaleString("en-US")} left on this plan</span>
          <span className="usage-gauge-module__vRAYnG__note">Resets in 3d</span>
        </div>
      </article>
      <article className="usage-gauge-module__vRAYnG__card usage-gauge-module__vRAYnG__uncapped">
        <div className="usage-gauge-module__vRAYnG__dial">
          <svg viewBox="0 0 108 108" aria-hidden="true">
            <defs>
              <linearGradient id="ug_r_c_" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#7c5cff" /><stop offset="100%" stopColor="#c44be8" /></linearGradient>
            </defs>
            <path className="usage-gauge-module__vRAYnG__track" d="M 24.301515190165006 83.698484809835 A 42 42 0 1 1 83.69848480983504 83.69848480983497" />
            <path className="usage-gauge-module__vRAYnG__value" d="M 24.301515190165006 83.698484809835 A 42 42 0 1 1 83.69848480983504 83.69848480983497" stroke="#6a46ff" strokeDasharray={ARC_LENGTH} strokeDashoffset={0} />
          </svg>
          <div className="usage-gauge-module__vRAYnG__readout">
            <span className="usage-gauge-module__vRAYnG__figure" title={String(executions)} style={{"--ug-figure-size": figureSizeFor(executions)} as React.CSSProperties}>{figureLabel(executions)}</span>
            <span className="usage-gauge-module__vRAYnG__cap">no cap</span>
          </div>
        </div>
        <div className="usage-gauge-module__vRAYnG__body">
          <span className="usage-gauge-module__vRAYnG__label">Executions · 24h</span>
          <span className="usage-gauge-module__vRAYnG__sub">Repeated runs included · {devices} device ID{devices === 1 ? "" : "s"}</span>
        </div>
      </article>
    </div>
  );
}
