"use client";

import { useEffect, useRef, useState } from "react";

/**
 * 1:1 recovery of the decompiled dashboard LiveExecutionsChart (chunk
 * 3am5ktae-r2q0.js + EXECUTION_RANGES module 84322 + parseExecutionActivity).
 * The static scrape captured the section frozen with a closed range menu and
 * an all-zero series; this component restores the original behaviour:
 *
 *  - the range control is the real DropdownMenu (FlowButton ghost/sm trigger
 *    with the extracted .liveExecutionsRangeButton rules — uppercase 12px
 *    bold; glass panel via the design-system .fa-menu-panel / .fa-menu-item
 *    classes that ship in the ported theme.css) offering 24h / 7d / 30d with
 *    a Check mark + aria-current on the active option;
 *  - data is fetched from /api/v1/public/activity?range=… (mirror of the
 *    decompiled /v1/me/activity?range=… contract) with an AbortController and
 *    the decompiled 20s timeout, then validated with the exact
 *    parseExecutionActivity invariants;
 *  - loading / error states reproduce the decompiled markup:
 *    .liveExecutionsStatus ("Loading last 24 hours…") and .liveExecutionsError
 *    (role=alert, "Couldn't update …", Retry button);
 *  - the chart geometry (1132×239 viewBox, 45/1120 × 12/205 plot area,
 *    recharts monotone cubic path math, compact y ticks, per-hour/per-day x
 *    labels, cursor line + activeDot + tooltip) is byte-compatible with the
 *    captured recharts markup for the captured all-zero series.
 */

const EXECUTION_RANGES: Record<string, { label: string; buckets: number; bucketMs: number }> = {
  "24h": { label: "Last 24 hours", buckets: 24, bucketMs: 3_600_000 },
  "7d": { label: "Last 7 days", buckets: 7, bucketMs: 86_400_000 },
  "30d": { label: "Last 30 days", buckets: 30, bucketMs: 86_400_000 },
};

const PLOT = { x0: 45, x1: 1120, y0: 12, y1: 205 };
const VW = 1132;
const VH = 239;

interface ActivityPayload {
  range: string;
  start: number;
  bucket_ms: number;
  total: number;
  executions_24h: number;
  unique_devices_24h: number;
  points: Array<{ t: number; executions: number }>;
}

/** Decompiled parseExecutionActivity — validates the exact response invariants. */
function parseExecutionActivity(payload: unknown, range: string): ActivityPayload {
  const spec = EXECUTION_RANGES[range];
  const data = payload as ActivityPayload;
  const safe = (value: unknown) =>
    typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
  if (
    !data ||
    data.range !== range ||
    data.bucket_ms !== spec.bucketMs ||
    !Number.isSafeInteger(data.start) ||
    data.start < 0 ||
    !safe(data.total) ||
    !safe(data.executions_24h) ||
    !safe(data.unique_devices_24h) ||
    !Array.isArray(data.points) ||
    data.points.length !== spec.buckets ||
    data.points.some(
      (point, index) =>
        !point ||
        point.t !== data.start + index * spec.bucketMs ||
        !safe(point.executions),
    ) ||
    data.points.reduce((acc, point) => acc + point.executions, 0) !== data.total
  ) {
    throw new Error("The server returned inconsistent execution data.");
  }
  return data;
}

/** recharts `type:"monotone"` (Fritsch–Carlson) — identical `C` segments. */
function monotonePath(points: Array<[number, number]>, step: number): string {
  const n = points.length;
  if (n === 0) return "";
  if (n === 1) return `M${points[0][0]},${points[0][1]}`;
  const delta: number[] = [];
  for (let i = 0; i < n - 1; i += 1) {
    delta.push((points[i + 1][1] - points[i][1]) / (points[i + 1][0] - points[i][0]));
  }
  const m: number[] = new Array(n);
  m[0] = delta[0];
  m[n - 1] = delta[n - 2];
  for (let i = 1; i < n - 1; i += 1) {
    m[i] = delta[i - 1] * delta[i] <= 0 ? 0 : (delta[i - 1] + delta[i]) / 2;
  }
  for (let i = 0; i < n - 1; i += 1) {
    if (delta[i] === 0) {
      m[i] = 0;
      m[i + 1] = 0;
      continue;
    }
    const a = m[i] / delta[i];
    const b = m[i + 1] / delta[i];
    const s = a * a + b * b;
    if (s > 9) {
      const t = 3 / Math.sqrt(s);
      m[i] = t * a * delta[i];
      m[i + 1] = t * b * delta[i];
    }
  }
  let d = `M${points[0][0]},${points[0][1]}`;
  for (let i = 0; i < n - 1; i += 1) {
    const c1x = points[i][0] + step / 3;
    const c1y = points[i][1] + (m[i] * step) / 3;
    const c2x = points[i + 1][0] - step / 3;
    const c2y = points[i + 1][1] - (m[i + 1] * step) / 3;
    d += `C${c1x},${c1y},${c2x},${c2y},${points[i + 1][0]},${points[i + 1][1]}`;
  }
  return d;
}

const compact = (value: number) =>
  new Intl.NumberFormat(undefined, { notation: "compact", maximumFractionDigits: 1 }).format(value);

export default function LiveExecutionsChart() {
  const [range, setRange] = useState("24h");
  // Bumped by the Retry button — re-runs the fetch effect for the same range.
  const [attempt, setAttempt] = useState(0);
  const [data, setData] = useState<ActivityPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [hover, setHover] = useState<number | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const plotRef = useRef<HTMLDivElement | null>(null);

  const spec = EXECUTION_RANGES[range];
  const perHour = range === "24h";
  const gradientId = `executions-${range}`;

  useEffect(() => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20_000); // decompiled 2e4
    let cancelled = false;
    setLoading(true);
    setError("");
    (async () => {
      try {
        const response = await fetch(`/api/v1/public/activity?range=${range}`, {
          signal: controller.signal,
        });
        if (!response.ok) throw new Error("Failed to fetch");
        const parsed = parseExecutionActivity(await response.json(), range);
        if (cancelled) return;
        setData(parsed);
        setError("");
        setLoading(false);
      } catch (err) {
        if (cancelled) return;
        setData(null);
        setError(err instanceof Error ? err.message : "Failed to fetch");
        setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
      clearTimeout(timeout);
      controller.abort();
    };
  }, [range, attempt]);

  // Dropdown dismissal — Escape (Radix) + pointerdown outside.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      event.stopPropagation();
      setMenuOpen(false);
    };
    const onPointerDown = (event: PointerEvent) => {
      if (menuRef.current?.contains(event.target as Node)) return;
      setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey, true);
    document.addEventListener("pointerdown", onPointerDown);
    return () => {
      window.removeEventListener("keydown", onKey, true);
      document.removeEventListener("pointerdown", onPointerDown);
    };
  }, [menuOpen]);

  const points = data?.points ?? [];
  const count = points.length;
  const step = count > 1 ? (PLOT.x1 - PLOT.x0) / (count - 1) : 0;
  const maxRaw = points.reduce((acc, point) => Math.max(acc, point.executions), 0);
  const tickStep = Math.max(1, Math.ceil(maxRaw / 4));
  const maxTick = tickStep * 4; // all-zero data → 4, exactly like the capture
  const yFor = (value: number) => PLOT.y1 - (value / maxTick) * (PLOT.y1 - PLOT.y0);
  const coords = points.map(
    (point, index) => [PLOT.x0 + index * step, yFor(point.executions)] as [number, number],
  );
  const curvePath = monotonePath(coords, step);
  const areaPath = curvePath
    ? `${curvePath}L${PLOT.x1},${PLOT.y1}L${PLOT.x0},${PLOT.y1}Z`
    : "";

  // X ticks — recharts' categorical fit with minTickGap 28: it walks from the
  // END backwards ("preserveEnd"), keeping a tick only when the gap between
  // label edges is at least minTickGap. That is why the captured 24h axis
  // shows every second hour ending at the newest bucket. Label widths are
  // estimated at ~6.4px/char (fontSize 11), the same order recharts measures.
  const xTickLabels = points.map((point) => xTickLabel(point.t, perHour, spec.bucketMs));
  const labelWidth = (text: string) => Math.min(120, text.length * 6.4);
  const xTicks: number[] = [];
  if (count) {
    let keptX = PLOT.x1;
    xTicks.push(count - 1);
    for (let i = count - 2; i >= 0; i -= 1) {
      const x = PLOT.x0 + i * step;
      if (keptX - (x + labelWidth(xTickLabels[i]) / 2) >= 28) {
        xTicks.unshift(i);
        keptX = x - labelWidth(xTickLabels[i]) / 2;
      }
    }
  }

  const hoverCoord = hover != null ? coords[hover] : null;

  const onPlotMouseMove = (event: React.MouseEvent<SVGSVGElement>) => {
    if (!count || !plotRef.current) return;
    const rect = plotRef.current.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width) * VW;
    const index = Math.round((x - PLOT.x0) / step);
    setHover(Math.max(0, Math.min(count - 1, index)));
  };

  const updatedAt = data ? data.start + count * data.bucket_ms : 0;
  const labelLower = spec.label.toLowerCase();

  return (
    <section
      className="liveExecutionsChart glass-card dashboardLiveExecutions"
      aria-label="Execution activity"
      data-execution-range={range}
      aria-busy={loading || undefined}
    >
      <div className="liveExecutionsHeader">
        <div className="liveExecutionsHeading">
          <div className="liveExecutionsTitleRow">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-activity liveExecutionsTitleIcon" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
              <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" />
            </svg>
            <h2 className="liveExecutionsTitle">Live executions</h2>
          </div>
          <p className="liveExecutionsSubtitle">Authorized script deliveries · {perHour ? "per hour" : "per day"}</p>
        </div>
        <div className="liveExecutionsHeaderRight">
          <div className="liveExecutionsTotal" aria-live="polite" aria-atomic="true">
            <strong>{data ? data.total.toLocaleString() : "—"}</strong>
            <span>executions · {labelLower}</span>
          </div>
          <div className="fa-menu" ref={menuRef}>
            <button
              type="button"
              className="flow-btn flow-btn-ghost flow-btn-sm liveExecutionsRangeButton"
              aria-label="Execution date range"
              aria-haspopup="menu"
              aria-expanded={menuOpen}
              data-state={menuOpen ? "open" : "closed"}
              data-slot="dropdown-menu-trigger"
              onClick={() => setMenuOpen((current) => !current)}
            >
              <span className="flow-btn-sweep" aria-hidden="true" />
              <span className="flow-btn-content">
                <span className="flow-btn-label">{range}</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-down" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m6 9 6 6 6-6" /></svg>
              </span>
            </button>
            {menuOpen ? (
              <div className="fa-menu-panel" style={{ right: 0, minWidth: 160 }} role="menu" aria-label="Execution date range">
                {Object.entries(EXECUTION_RANGES).map(([key, value]) => (
                  <button
                    key={key}
                    type="button"
                    role="menuitem"
                    aria-current={range === key ? "true" : undefined}
                    className="fa-menu-item"
                    onClick={() => {
                      setMenuOpen(false);
                      if (key !== range) setRange(key);
                    }}
                  >
                    <span className="fa-menu-item-label">{value.label}</span>
                    {range === key ? (
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M20 6 9 17l-5-5" /></svg>
                    ) : null}
                  </button>
                ))}
              </div>
            ) : null}
          </div>
        </div>
      </div>
      {error ? (
        <div className="liveExecutionsError" role="alert">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-alert-circle" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="10" /><path d="M12 8v4" /><path d="M12 16h.01" /></svg>
          <div>
            <strong>Couldn’t update {labelLower}</strong>
            <p>
              {error}
              {data ? " Showing the last successful update for this range." : " No data is shown for this range until it loads."}
            </p>
          </div>
          <button
            type="button"
            className="flow-btn flow-btn-ghost flow-btn-sm"
            disabled={loading}
            onClick={() => setAttempt((current) => current + 1)}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-refresh-cw" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" /><path d="M21 3v5h-5" /><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" /><path d="M8 16H3v5" /></svg>
              <span className="flow-btn-label">Retry</span>
            </span>
          </button>
        </div>
      ) : null}
      <div className="liveExecutionsBody">
        {data ? (
          <div
            data-slot="chart"
            data-chart={`chart-executions-${range}`}
            className="reuiChartContainer liveExecutionsFrame"
            ref={plotRef}
            // The original ChartContainer injects the series color inline
            // (decompiled config eG: executions → #78bd91).
            style={{ "--color-executions": "#78bd91" } as React.CSSProperties}
          >
            <div className="recharts-wrapper" style={{ position: "relative", cursor: "default", width: "100%", height: "100%" }}>
              <div
                tabIndex={-1}
                className="recharts-tooltip-wrapper"
                style={{
                  visibility: hoverCoord ? "visible" : "hidden",
                  pointerEvents: "none",
                  position: "absolute",
                  // Percentage left/top resolve against the wrapper (the full
                  // chart); the transform only centers/raises the tooltip.
                  left: hoverCoord ? `${(hoverCoord[0] / VW) * 100}%` : "0px",
                  top: hoverCoord ? `${(hoverCoord[1] / VH) * 100}%` : "0px",
                  transform: "translate(-50%, -115%)",
                }}
              >
                {hoverCoord && hover != null ? (
                  <div className="liveExecutionsTooltip rounded-lg border bg-popover p-2 text-xs text-popover-foreground shadow-md" style={{ whiteSpace: "nowrap" }}>
                    <div style={{ display: "grid", gap: 6 }}>
                      <div style={{ fontWeight: 600 }}>{tooltipLabel(points, hover, data.bucket_ms, perHour, updatedAt)}</div>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16 }}>
                        <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                          <span aria-hidden="true" style={{ width: 8, height: 8, borderRadius: "50%", background: "#78bd91", display: "inline-block" }} />
                          Executions
                        </span>
                        <span style={{ fontVariantNumeric: "tabular-nums", fontWeight: 500 }}>{points[hover].executions.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
              <svg
                role="application"
                tabIndex={0}
                className="recharts-surface"
                width={VW}
                height={VH}
                viewBox={`0 0 ${VW} ${VH}`}
                style={{ width: "100%", height: "100%", display: "block" }}
                onMouseMove={onPlotMouseMove}
                onMouseLeave={() => setHover(null)}
              >
                <title />
                <desc />
                <g tabIndex={-1} className="recharts-zIndex-layer_-100">
                  <g className="recharts-cartesian-grid">
                    <g className="recharts-cartesian-grid-horizontal">
                      {[0, 1, 2, 3, 4].map((line) => (
                        <line key={line} stroke="var(--fl-line)" strokeDasharray="3 5" x1={PLOT.x0} y1={PLOT.y1 - line * ((PLOT.y1 - PLOT.y0) / 4)} x2={PLOT.x1} y2={PLOT.y1 - line * ((PLOT.y1 - PLOT.y0) / 4)} fill="none" />
                      ))}
                    </g>
                  </g>
                </g>
                <g tabIndex={-1} className="recharts-zIndex-layer_-50" />
                <defs>
                  <clipPath id={`recharts-${range}-clip`}><rect x={PLOT.x0} y={PLOT.y0} height={PLOT.y1 - PLOT.y0} width={PLOT.x1 - PLOT.x0} /></clipPath>
                </defs>
                <defs>
                  <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-executions)" stopOpacity="0.3" />
                    <stop offset="95%" stopColor="var(--color-executions)" stopOpacity="0.03" />
                  </linearGradient>
                </defs>
                <g tabIndex={-1} className="recharts-zIndex-layer_100">
                  <g className="recharts-layer recharts-area">
                    <g className="recharts-layer">
                      <g className="recharts-layer recharts-shape">
                        {areaPath ? (
                          <path strokeWidth="2" fill={`url(#${gradientId})`} fillOpacity="0.6" height={PLOT.y1 - PLOT.y0} width={PLOT.x1 - PLOT.x0} className="recharts-curve recharts-area-area" d={areaPath} />
                        ) : null}
                        {curvePath ? (
                          <path strokeWidth="2" fill="none" fillOpacity="0.6" height={PLOT.y1 - PLOT.y0} width={PLOT.x1 - PLOT.x0} className="recharts-curve recharts-area-curve" stroke="var(--color-executions)" d={curvePath} />
                        ) : null}
                      </g>
                    </g>
                  </g>
                </g>
                {hoverCoord ? (
                  <g tabIndex={-1} className="recharts-zIndex-layer_200">
                    <line x1={hoverCoord[0]} y1={PLOT.y0} x2={hoverCoord[0]} y2={PLOT.y1} stroke="var(--fl-line-2)" strokeWidth="1" />
                    <circle cx={hoverCoord[0]} cy={hoverCoord[1]} r="4" strokeWidth="0" fill="var(--color-executions)" />
                  </g>
                ) : null}
                <g tabIndex={-1} className="recharts-zIndex-layer_2000">
                  <g className="recharts-cartesian-axis-tick-labels recharts-xAxis-tick-labels">
                    {xTicks.map((index) => (
                      <g key={index} className="recharts-layer recharts-cartesian-axis-tick-label">
                        <text orientation="bottom" stroke="none" fontSize="11" x={PLOT.x0 + index * step} y="221" className="recharts-text recharts-cartesian-axis-tick-value" textAnchor="middle" fill="var(--fl-ink-2)">
                          <tspan x={PLOT.x0 + index * step} dy="0.71em">{xTickLabels[index]}</tspan>
                        </text>
                      </g>
                    ))}
                  </g>
                  <g className="recharts-cartesian-axis-tick-labels recharts-yAxis-tick-labels">
                    {[0, 1, 2, 3, 4].map((tick) => (
                      <g key={tick} className="recharts-layer recharts-cartesian-axis-tick-label">
                        <text orientation="left" stroke="none" fontSize="11" x="31" y={PLOT.y1 - tick * ((PLOT.y1 - PLOT.y0) / 4)} className="recharts-text recharts-cartesian-axis-tick-value" textAnchor="end" fill="var(--fl-ink-2)">
                          <tspan x="31" dy="0.355em">{compact(tick * tickStep)}</tspan>
                        </text>
                      </g>
                    ))}
                  </g>
                </g>
              </svg>
            </div>
          </div>
        ) : (
          <div className="liveExecutionsStatus" role="status">
            {loading ? `Loading ${labelLower}…` : error ? "Execution activity unavailable" : "No execution activity available."}
          </div>
        )}
        {data && data.total === 0 ? <div className="liveExecutionsEmpty">No executions recorded in this period.</div> : null}
      </div>
      <div className="liveExecutionsFooter">
        <details open>
          <summary>
            How executions are counted{" "}
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-down" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path d="m6 9 6 6 6-6" /></svg>
          </summary>
          <p>
            One count per authorized script delivery. Repeat runs and keyless scripts count too; an issued key may never be used. Delivery does not confirm that a script finished running. The “Executions · 24h” gauge always covers the last 24 hours.
          </p>
        </details>
        <span>
          {data && updatedAt
            ? `Updated ${new Date(updatedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}${loading ? " · Refreshing…" : ""}`
            : ""}
        </span>
      </div>
    </section>
  );
}

function tooltipLabel(
  points: Array<{ t: number; executions: number }>,
  hover: number,
  bucketMs: number,
  perHour: boolean,
  end: number,
): string {
  const t = points[hover]?.t;
  if (!Number.isFinite(t)) return "";
  const until = Math.min(t + bucketMs, end || Infinity);
  const fmt = { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" } as const;
  return `${new Date(t).toLocaleString([], fmt)} – ${new Date(until).toLocaleString([], perHour ? { hour: "numeric", minute: "2-digit" } : fmt)}`;
}

function xTickLabel(t: number, perHour: boolean, bucketMs: number): string {
  const date = new Date(t + (perHour ? 0 : bucketMs));
  if (!Number.isFinite(date.getTime())) return "";
  return perHour
    ? date.toLocaleTimeString([], { hour: "numeric" })
    : date.toLocaleDateString([], { month: "short", day: "numeric" });
}
