import { NextResponse } from "next/server";

/**
 * Execution activity endpoint mirroring the decompiled dashboard contract
 * `GET /v1/me/activity?range={24h|7d|30d}` (chunk 3k6a5lhrkscp5.js +
 * EXECUTION_RANGES module 84322). The client validates the response with
 * `parseExecutionActivity`, so the payload reproduces the exact invariants:
 *
 *   points.length === buckets
 *   points[n].t    === start + n * bucketMs
 *   sum(points.executions) === total
 *   start >= 0, all counters safe non-negative integers
 *
 * The captured workspace account has no recorded runs, so every bucket is 0 —
 * the same all-zero series the scraped dashboard snapshot shows. Buckets are
 * aligned to wall-clock steps exactly like a real backend would emit them.
 */

const RANGES: Record<string, { buckets: number; bucketMs: number }> = {
  "24h": { buckets: 24, bucketMs: 3_600_000 },
  "7d": { buckets: 7, bucketMs: 86_400_000 },
  "30d": { buckets: 30, bucketMs: 86_400_000 },
};

export async function GET(request: Request) {
  const url = new URL(request.url);
  const range = url.searchParams.get("range") ?? "24h";
  const spec = RANGES[range];
  if (!spec) {
    return NextResponse.json(
      { error: "Unknown range. Use 24h, 7d or 30d." },
      { status: 400, headers: { "cache-control": "no-store" } },
    );
  }

  const { buckets, bucketMs } = spec;
  const now = Date.now();
  const start = Math.floor(now / bucketMs) * bucketMs;

  const points = Array.from({ length: buckets }, (_, index) => ({
    t: start + index * bucketMs,
    executions: 0,
  }));

  return NextResponse.json(
    {
      range,
      start,
      bucket_ms: bucketMs,
      total: 0,
      executions_24h: 0,
      unique_devices_24h: 0,
      points,
    },
    { headers: { "cache-control": "no-store" } },
  );
}
