"use client"

/**
 * AnimatedBeam — a glowing pulse traveling along a curved bezier path between
 * two elements (MagicUI registry API: containerRef / fromRef / toRef /
 * curvature / endXOffset / endYOffset / reverse / delay / duration / colors).
 *
 * Implementation notes:
 * - The path is measured once (and on resize) via getBoundingClientRect and
 *   drawn as a cubic bezier whose two control points sit at the horizontal
 *   midpoint, offset vertically by `curvature` — the classic MagicUI shape.
 * - The traveling light uses `pathLength={1}` normalization + a CSS
 *   stroke-dashoffset animation (`.centurion-beam-pulse`), so every path —
 *   short or long — loops seamlessly with the same duration. No per-frame
 *   JS, GPU friendly.
 * - A second, wider stroke of the same animation renders as the soft aura.
 */

import { useCallback, useEffect, useId, useState, type RefObject } from "react"

export interface AnimatedBeamProps {
  containerRef: RefObject<HTMLElement | null>
  fromRef: RefObject<HTMLElement | null>
  toRef: RefObject<HTMLElement | null>
  curvature?: number
  endXOffset?: number
  endYOffset?: number
  reverse?: boolean
  delay?: number
  duration?: number
  gradientStartColor?: string
  gradientStopColor?: string
  pathColor?: string
  pathWidth?: number
  pathOpacity?: number
}

export const AnimatedBeam = ({
  containerRef,
  fromRef,
  toRef,
  curvature = 0,
  endXOffset = 0,
  endYOffset = 0,
  reverse = false,
  delay = 0,
  duration = 2.6,
  gradientStartColor = "#7c5cff",
  gradientStopColor = "#74ffbc",
  pathColor = "#7c5cff",
  pathWidth = 1.5,
  pathOpacity = 0.16,
}: AnimatedBeamProps) => {
  const id = useId().replace(/[^a-zA-Z0-9_-]/g, "")
  const [pathD, setPathD] = useState("M 0 0")
  const [grad, setGrad] = useState({ x1: 0, y1: 0, x2: 0, y2: 0 })

  const updatePath = useCallback(() => {
    const container = containerRef.current
    const from = fromRef.current
    const to = toRef.current
    if (!container || !from || !to) return
    const cr = container.getBoundingClientRect()
    const fr = from.getBoundingClientRect()
    const tr = to.getBoundingClientRect()
    // Start at the edge of `from` facing `to`, end at the facing edge of `to`.
    let sx = fr.left - cr.left + fr.width
    const sy = fr.top - cr.top + fr.height / 2
    let ex = tr.left - cr.left
    let ey = tr.top - cr.top + tr.height / 2
    if (fr.left >= tr.left) {
      sx = fr.left - cr.left
      ex = tr.left - cr.left + tr.width
    }
    ex += endXOffset
    ey += endYOffset
    const mx = (sx + ex) / 2
    setPathD(`M ${sx},${sy} C ${mx},${sy + curvature} ${mx},${ey + curvature} ${ex},${ey}`)
    setGrad(
      reverse
        ? { x1: ex, y1: ey, x2: sx, y2: sy }
        : { x1: sx, y1: sy, x2: ex, y2: ey },
    )
  }, [containerRef, fromRef, toRef, curvature, endXOffset, endYOffset, reverse])

  useEffect(() => {
    updatePath()
    const container = containerRef.current
    if (!container) return
    const ro = new ResizeObserver(updatePath)
    ro.observe(container)
    window.addEventListener("resize", updatePath)
    return () => {
      ro.disconnect()
      window.removeEventListener("resize", updatePath)
    }
  }, [updatePath, containerRef])

  const animStyle = {
    animationDuration: `${duration}s`,
    animationDelay: `-${delay % duration}s`,
  } as const

  return (
    <svg
      className="centurionBeamSvg"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient
          id={id}
          gradientUnits="userSpaceOnUse"
          x1={grad.x1}
          y1={grad.y1}
          x2={grad.x2}
          y2={grad.y2}
        >
          <stop stopColor={gradientStartColor} stopOpacity="0" />
          <stop offset="0.5" stopColor={gradientStartColor} />
          <stop offset="1" stopColor={gradientStopColor} />
        </linearGradient>
      </defs>
      {/* faint base rail */}
      <path
        d={pathD}
        stroke={pathColor}
        strokeOpacity={pathOpacity}
        strokeWidth={pathWidth}
        pathLength={1}
      />
      {/* soft aura */}
      <path
        d={pathD}
        stroke={`url(#${id})`}
        strokeOpacity={0.22}
        strokeWidth={pathWidth * 3.4}
        pathLength={1}
        strokeLinecap="round"
        className="centurion-beam-pulse"
        data-reverse={reverse ? "true" : undefined}
        style={animStyle}
      />
      {/* bright traveling pulse */}
      <path
        d={pathD}
        stroke={`url(#${id})`}
        strokeWidth={pathWidth}
        pathLength={1}
        strokeLinecap="round"
        className="centurion-beam-pulse"
        data-reverse={reverse ? "true" : undefined}
        style={animStyle}
      />
    </svg>
  )
}

export default AnimatedBeam
