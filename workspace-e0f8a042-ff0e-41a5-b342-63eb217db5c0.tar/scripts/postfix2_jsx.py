#!/usr/bin/env python3
"""Second pass: localize remote assets, finish branding in code text."""
import re
import sys

def protect_classes(line: str):
    """Replace FlowAuth outside className="..." values."""
    parts = re.split(r'(className="[^"]*")', line)
    for i, p in enumerate(parts):
        if p.startswith('className="'):
            continue
        parts[i] = p.replace("FLOWAUTH", "SWITZAUTH").replace("FlowAuth", "Switzauth")
    return "".join(parts)

def fix_file(path: str):
    src = open(path, encoding="utf-8").read()
    # 1. localize remote brand assets
    src = src.replace('src="https://flowauth.net/brand/', 'src="/brand/')
    src = src.replace('srcSet="https://flowauth.net/brand/', 'srcSet="/brand/')
    # 2. API copy domain
    src = src.replace("flowauth.net", "switzauth.net")
    # 3. remaining brand text outside classNames
    lines = src.split("\n")
    lines = [protect_classes(l) for l in lines]
    src = "\n".join(lines)
    open(path, "w", encoding="utf-8").write(src)

def main():
    for f in sys.argv[1:]:
        fix_file(f)
        print("pass2 done", f)

if __name__ == "__main__":
    main()
