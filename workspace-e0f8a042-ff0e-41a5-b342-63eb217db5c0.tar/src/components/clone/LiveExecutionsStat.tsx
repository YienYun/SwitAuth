"use client";

import { useExecutions24h } from "./useExecutions24h";

/**
 * The "Executions · 24h" overview stat — a fourth live metric on the
 * dashboard hero grid. Rendered as a plain 0 for SSR (identical to the
 * captured all-zero snapshot), then hydrated from the same activity
 * endpoint the Live executions chart uses (module TTL cache dedupes the
 * request).
 */
export default function LiveExecutionsStat() {
  const { total } = useExecutions24h();
  return <span className="fa-stat-number">{total}</span>;
}
