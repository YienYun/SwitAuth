  <div className="landing-module__I_lyca__page">
    <div className="landing-module__I_lyca__backdrop" aria-hidden="true" data-animated="true">
      <span className="landing-module__I_lyca__backdropMesh" />
      <span className="landing-module__I_lyca__backdropScrim" />
      <span className="landing-module__I_lyca__backdropFade" />
    </div>
    <header className="landing-module__I_lyca__header">
      <div className="landing-module__I_lyca__headerInner">
        <a href="/" className="landing-module__I_lyca__brand" aria-label="Switzauth home">
          <svg width="26" height="26" viewBox="0 0 100 100" fill="none" role="presentation" aria-hidden="true">
            <defs>
              <linearGradient id="fam_R_55fj5b_-f" x1="10" y1="14" x2="86" y2="88" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#6E7BF0" />
                <stop offset="0.36" stopColor="#C9A8F2" />
                <stop offset="1" stopColor="#C44BE8" />
              </linearGradient>
            </defs>
            <g transform="translate(0 2.2)" fill="#3A2160" opacity="0.28">
              <path d="M23 37.5 Q23 18 42 18 L79 18 Q87 18 87 27.6 Q87 37.5 76 37.5 Z" />
              <path d="M12.7 60.6 Q12.7 41.2 31.7 41.2 L67 41.2 Q74.7 41.2 74.7 50.8 Q74.7 60.6 64 60.6 Z" />
              <path d="M23 64.6 L46.4 64.6 Q46.4 85.8 23 85.8 Z" />
            </g>
            <g fill="url(#fam_R_55fj5b_-f)">
              <path d="M23 37.5 Q23 18 42 18 L79 18 Q87 18 87 27.6 Q87 37.5 76 37.5 Z" />
              <path d="M12.7 60.6 Q12.7 41.2 31.7 41.2 L67 41.2 Q74.7 41.2 74.7 50.8 Q74.7 60.6 64 60.6 Z" />
              <path d="M23 64.6 L46.4 64.6 Q46.4 85.8 23 85.8 Z" />
            </g>
          </svg>
        </a>
        <nav className="landing-module__I_lyca__nav" aria-label="Primary">
          <a href="/#flow-features" className="landing-module__I_lyca__navLink landing-module__I_lyca__navHideSmall">Features</a>
          <a href="/#flow-pricing" className="landing-module__I_lyca__navLink">Pricing</a>
          <a href="/docs" className="landing-module__I_lyca__navLink">Docs</a>
          <a href="/#flow-faq" className="landing-module__I_lyca__navLink landing-module__I_lyca__navHideSmall">FAQ</a>
          <a href="https://discord.gg/XnMhR8U4VQ" target="_blank" rel="noopener noreferrer" className="landing-module__I_lyca__navLink landing-module__I_lyca__navHideSmall">Discord</a>
        </nav>
        <div className="landing-module__I_lyca__headerActions" aria-busy="false">
          <a href="/login" className="landing-module__I_lyca__btn landing-module__I_lyca__btnQuiet">Log in</a>
          <a href="/register" className="landing-module__I_lyca__btn landing-module__I_lyca__btnGlass">Start free</a>
        </div>
      </div>
    </header>
    <main className="landing-module__I_lyca__main">
      <section className="landing-module__I_lyca__shell landing-module__I_lyca__hero">
        <h1 className="landing-module__I_lyca__wordmark landing-module__I_lyca__enter landing-module__I_lyca__d1">SWITZAUTH</h1>
        <p className="landing-module__I_lyca__heroSub landing-module__I_lyca__enter landing-module__I_lyca__d2">Key authentication and source protection for Roblox script hubs.</p>
        <div className="landing-module__I_lyca__heroActions landing-module__I_lyca__enter landing-module__I_lyca__d3">
          <a href="/register" className="landing-module__I_lyca__btn">Start free</a>
          <a href="https://discord.gg/XnMhR8U4VQ" target="_blank" rel="noopener noreferrer" className="landing-module__I_lyca__btn landing-module__I_lyca__btnGlass">Join the Discord</a>
        </div>
        <p className="landing-module__I_lyca__heroFine landing-module__I_lyca__enter landing-module__I_lyca__d4">Free plan, no card. Using Switzauth means you agree to the <a href="/terms">Terms of Service</a>.</p>
        <div className="landing-module__I_lyca__totalExecutions landing-module__I_lyca__enter landing-module__I_lyca__d5">
          <p className="landing-module__I_lyca__totalExecutionsValue" role="status" aria-live="polite" aria-atomic="true">—<span className="sr-only"> total executions across Switzauth, all time</span></p>
          <p className="landing-module__I_lyca__totalExecutionsLabel">Total executions <span aria-hidden="true">·</span> All time</p>
        </div>
        <div className="landing-module__I_lyca__execWrap landing-module__I_lyca__enter landing-module__I_lyca__d5">
          <p className="landing-module__I_lyca__execHead">Runs on 16 executors</p>
          <ul className="landing-module__I_lyca__execList">
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/delta-official.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Delta</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/vega-x.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Vega X</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/codex.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Codex</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/sirhurt.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>SirHurt</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/solara.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Solara</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/xeno.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Xeno</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/volt.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Volt</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/potassium.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Potassium</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/wave.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Wave</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/synapse-z.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Synapse Z</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/madium.jpg" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Madium</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/cosmic.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Cosmic</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/real-projectreal.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Real</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/velocity.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Velocity</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/macsploit.webp" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>MacSploit</span>
            </li>
            <li className="landing-module__I_lyca__execItem">
              <img className="landing-module__I_lyca__execLogo" src="/executors/opiumware.png" alt="" width="21" height="21" loading="lazy" decoding="async" />
              <span>Opiumware</span>
            </li>
          </ul>
        </div>
      </section>
      <section className="landing-module__I_lyca__shell landing-module__I_lyca__section" id="flow-features">
        <header className="landing-module__I_lyca__secHead landing-module__I_lyca__reveal">
          <h2 className="landing-module__I_lyca__secTitle">Everything a hub needs.</h2>
          <p className="landing-module__I_lyca__secLede">Keys, devices, gateways and logs in one place, so you are not gluing three services together at 2am.</p>
        </header>
        <div className="landing-module__I_lyca__cards">
          <article className="landing-module__I_lyca__card landing-module__I_lyca__reveal">
            <span className="landing-module__I_lyca__cardIcon" aria-hidden="true">
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M15.5 14.5C18.8137 14.5 21.5 11.8137 21.5 8.5C21.5 5.18629 18.8137 2.5 15.5 2.5C12.1863 2.5 9.5 5.18629 9.5 8.5C9.5 9.38041 9.68962 10.2165 10.0303 10.9697L2.5 18.5V21.5H5.5V19.5H7.5V17.5H9.5L13.0303 13.9697C13.7835 14.3104 14.6196 14.5 15.5 14.5Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M17.5 6.5L16.5 7.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
              </svg>
            </span>
            <h3>Key system</h3>
            <p>Issue, pause, expire, reset and bulk import keys per project. Set them to run out in a day or never.</p>
          </article>
          <article className="landing-module__I_lyca__card landing-module__I_lyca__reveal">
            <span className="landing-module__I_lyca__cardIcon" aria-hidden="true">
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M12.9994 2H9.99936C6.22812 2 4.34251 2 3.17093 3.17157C1.99936 4.34315 1.99936 6.22876 1.99936 10C1.99936 13.7712 1.99936 15.6569 3.17093 16.8284C4.34251 18 6.22812 18 9.99936 18H13.9994C17.7706 18 19.6563 18 20.8278 16.8284C21.481 16.1752 21.77 15.3001 21.8979 14" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
                <path d="M11.9994 18V22" stroke="currentColor" strokeWidth="1.8" />
                <path d="M7.99936 22H15.9994" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
                <path d="M10.9994 15H12.9994" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M16.7501 5.37603C16.7501 5.31603 16.7487 4.55715 16.7501 4.12257C16.7514 3.72548 16.7165 3.34257 16.9061 2.99217C17.6165 1.57857 19.6565 1.72257 20.1605 3.16257C20.2478 3.39964 20.2531 3.77549 20.2505 4.12257C20.2472 4.56606 20.2565 5.37603 20.2565 5.37603M16.7501 5.37603C15.6701 5.37603 15.2165 6.15603 15.0965 6.63603C14.9765 7.11603 14.9765 8.85603 15.0485 9.57603C15.2885 10.476 15.8885 10.848 16.4765 10.968C17.0165 11.016 19.2965 10.998 19.9565 10.998C20.9165 11.016 21.6365 10.656 21.9365 9.57603C21.9965 9.21603 22.0565 7.23603 21.9065 6.63603C21.5885 5.67603 20.8565 5.37603 20.2565 5.37603M16.7501 5.37603H20.2565" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
              </svg>
            </span>
            <h3>HWID lock</h3>
            <p>
              A key binds to the first machine that uses it. Mismatches get refused and logged, and you can clear a binding when a real buyer changes PC.
            </p>
          </article>
          <article className="landing-module__I_lyca__card landing-module__I_lyca__reveal">
            <span className="landing-module__I_lyca__cardIcon" aria-hidden="true">
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M18.7088 3.49534C16.8164 2.55382 14.5008 2 11.9999 2C9.49904 2 7.18344 2.55382 5.2911 3.49534C4.36312 3.95706 3.89913 4.18792 3.44954 4.91378C2.99994 5.63965 2.99994 6.34248 2.99994 7.74814V11.2371C2.99994 16.9205 7.54229 20.0804 10.173 21.4338C10.9066 21.8113 11.2734 22 11.9999 22C12.7264 22 13.0932 21.8113 13.8269 21.4338C16.4576 20.0804 20.9999 16.9205 20.9999 11.2371L20.9999 7.74814C20.9999 6.34249 20.9999 5.63966 20.5503 4.91378C20.1007 4.18791 19.6367 3.95706 18.7088 3.49534Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M11.9999 11C13.1045 11 13.9999 10.1046 13.9999 9C13.9999 7.89543 13.1045 7 11.9999 7C10.8954 7 9.99994 7.89543 9.99994 9C9.99994 10.1046 10.8954 11 11.9999 11ZM11.9999 11V13.5M13.9999 16H12.9999C12.4477 16 11.9999 15.5523 11.9999 15V13.5M11.9999 13.5H13.4999" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
              </svg>
            </span>
            <h3>Source protection</h3>
            <p>
              Your Lua/Luau stays server side and ships as a versioned protected package once the checks pass. It is never exposed as a static file.
            </p>
          </article>
          <article className="landing-module__I_lyca__card landing-module__I_lyca__reveal">
            <span className="landing-module__I_lyca__cardIcon" aria-hidden="true">
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M4 11V15C4 18.2998 4 19.9497 5.02513 20.9749C6.05025 22 7.70017 22 11 22H13C16.2998 22 17.9497 22 18.9749 20.9749C20 19.9497 20 18.2998 20 15V11" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M3 9C3 8.25231 3 7.87846 3.20096 7.6C3.33261 7.41758 3.52197 7.26609 3.75 7.16077C4.09808 7 4.56538 7 5.5 7H18.5C19.4346 7 19.9019 7 20.25 7.16077C20.478 7.26609 20.6674 7.41758 20.799 7.6C21 7.87846 21 8.25231 21 9C21 9.74769 21 10.1215 20.799 10.4C20.6674 10.5824 20.478 10.7339 20.25 10.8392C19.9019 11 19.4346 11 18.5 11H5.5C4.56538 11 4.09808 11 3.75 10.8392C3.52197 10.7339 3.33261 10.5824 3.20096 10.4C3 10.1215 3 9.74769 3 9Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M6 3.78571C6 2.79949 6.79949 2 7.78571 2H8.14286C10.2731 2 12 3.7269 12 5.85714V7H9.21429C7.43908 7 6 5.56091 6 3.78571Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M18 3.78571C18 2.79949 17.2005 2 16.2143 2H15.8571C13.7269 2 12 3.7269 12 5.85714V7H14.7857C16.5609 7 18 5.56091 18 3.78571Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M12 11L12 22" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
              </svg>
            </span>
            <h3>Reward gateways</h3>
            <p>Send people through checkpoints before a key is minted, with custom getkey pages on the higher plans.</p>
          </article>
          <article className="landing-module__I_lyca__card landing-module__I_lyca__reveal">
            <span className="landing-module__I_lyca__cardIcon" aria-hidden="true">
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M15.5 17.5C16.5 19 17.3333 19.6667 18 20C19.3333 19.6667 22 18.2 22 15C22 11.8 20.6667 7.33333 20 5.5C18 4.3 15.8333 4 15 4L14.198 5.60393C13.4135 5.28708 12.4058 5.25438 12 5.27763C11.5942 5.25438 10.5865 5.28708 9.80197 5.60393L9 4C8.16667 4 6 4.3 4 5.5C3.33333 7.33333 2 11.8 2 15C2 18.2 4.66667 19.6667 6 20C6.66667 19.6667 7.5 19 8.5 17.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M17.3652 11.5C17.3652 12.6046 16.5817 13.5 15.6152 13.5C14.6487 13.5 13.8652 12.6046 13.8652 11.5C13.8652 10.3954 14.6487 9.5 15.6152 9.5C16.5817 9.5 17.3652 10.3954 17.3652 11.5Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M10 11.5C10 12.6046 9.2165 13.5 8.25 13.5C7.2835 13.5 6.5 12.6046 6.5 11.5C6.5 10.3954 7.2835 9.5 8.25 9.5C9.2165 9.5 10 10.3954 10 11.5Z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
                <path d="M17.5 16.5C16.4022 17.3967 14.3502 18 12 18C9.64981 18 7.59785 17.3967 6.5 16.5" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.8" />
              </svg>
            </span>
            <h3>Discord bot</h3>
            <p>Redeem, reset and check keys straight from your server. Multi tenant on Premium, dedicated on Enterprise.</p>
          </article>
          <article className="landing-module__I_lyca__card landing-module__I_lyca__reveal">
            <span className="landing-module__I_lyca__cardIcon" aria-hidden="true">
              <svg width="21" height="21" viewBox="0 0 24 24" fill="none" color="currentColor" className="" strokeWidth="1.8" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M7 17L7 13" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
                <path d="M12 17L12 7" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
                <path d="M17 17L17 11" stroke="currentColor" strokeLinecap="round" strokeWidth="1.8" />
                <path d="M2.5 12C2.5 7.52166 2.5 5.28249 3.89124 3.89124C5.28249 2.5 7.52166 2.5 12 2.5C16.4783 2.5 18.7175 2.5 20.1088 3.89124C21.5 5.28249 21.5 7.52166 21.5 12C21.5 16.4783 21.5 18.7175 20.1088 20.1088C18.7175 21.5 16.4783 21.5 12 21.5C7.52166 21.5 5.28249 21.5 3.89124 20.1088C2.5 18.7175 2.5 16.4783 2.5 12Z" stroke="currentColor" strokeLinejoin="round" strokeWidth="1.8" />
              </svg>
            </span>
            <h3>Execution logs</h3>
            <p>
              Every run, rejection, HWID mismatch and gateway failure lands in your logs, with webhooks if you want it pushed.
            </p>
          </article>
        </div>
      </section>
      <section className="landing-module__I_lyca__shell landing-module__I_lyca__section" id="flow-pricing">
        <header className="landing-module__I_lyca__secHead landing-module__I_lyca__reveal">
          <h2 className="landing-module__I_lyca__secTitle">Start free. Pay when it pays you.</h2>
          <p className="landing-module__I_lyca__secLede">
            Every account opens on Free with 25 projects, 100 keys and 1,000 Centurion obfuscations a month, with no card and no timer.
          </p>
        </header>
        <div className="landing-module__I_lyca__cycleWrap landing-module__I_lyca__reveal">
          <div className="landing-module__I_lyca__cycle">
            <div className="fa-seg fa-seg-md pricingCycleSegmented" role="radiogroup" aria-label="Choose an option" style={{"--fa-seg-count": "2", "--fa-seg-index": "1"} as React.CSSProperties}>
              <span className="fa-seg-indicator" aria-hidden="true" />
              <button type="button" role="radio" aria-checked="false" tabIndex={-1} className="fa-seg-item">Monthly</button>
              <button type="button" role="radio" aria-checked="true" tabIndex={0} className="fa-seg-item fa-seg-active"><span>Yearly</span><span className="landing-module__I_lyca__cycleSave">20% off</span></button>
            </div>
          </div>
        </div>
        <div className="landing-module__I_lyca__plans">
          <article className="landing-module__I_lyca__plan landing-module__I_lyca__reveal">
            <div className="landing-module__I_lyca__planTop"><h3 className="landing-module__I_lyca__planName">Plus</h3></div>
            <div className="landing-module__I_lyca__planPrice"><strong>$48</strong><span>/yr</span></div>
            <p className="landing-module__I_lyca__planNote">$4/mo, billed yearly</p>
            <p className="landing-module__I_lyca__planDesc">One hub with a real customer base behind it.</p>
            <ul className="landing-module__I_lyca__planFeatures">
              <li><span>100 projects</span></li>
              <li><span>1,000 keys</span></li>
              <li><span>3,000 Centurion obfuscations a month</span></li>
              <li><span>All reward gateways</span></li>
              <li><span>5 webhooks + Discord bot</span></li>
              <li><span>HWID reset + getkey gateway</span></li>
              <li><span>Priority email support</span></li>
            </ul>
            <div className="landing-module__I_lyca__planFoot">
              <a href="https://discord.gg/XnMhR8U4VQ" target="_blank" rel="noopener noreferrer" className="landing-module__I_lyca__btn landing-module__I_lyca__btnBlock landing-module__I_lyca__btnGlass" aria-label="Select the Plus plan at $48/yr">Get Plus</a>
            </div>
          </article>
          <article className="landing-module__I_lyca__plan landing-module__I_lyca__planPopular landing-module__I_lyca__reveal">
            <div className="landing-module__I_lyca__planTop">
              <h3 className="landing-module__I_lyca__planName">Premium</h3>
              <span className="landing-module__I_lyca__planTag">Most hubs</span>
            </div>
            <div className="landing-module__I_lyca__planPrice"><strong>$192</strong><span>/yr</span></div>
            <p className="landing-module__I_lyca__planNote">$16/mo, billed yearly</p>
            <p className="landing-module__I_lyca__planDesc">Several hubs, and enough volume to feel it.</p>
            <ul className="landing-module__I_lyca__planFeatures">
              <li><span>500 projects</span></li>
              <li><span>Unlimited keys</span></li>
              <li><span>10,000 monthly Centurion obfuscations</span></li>
              <li><span>All gateways + custom getkey pages</span></li>
              <li><span>Priority packaging queue</span></li>
              <li><span>Unlimited webhooks</span></li>
              <li><span>Multi tenant Discord bot</span></li>
              <li><span>Datacenter IP detection + access rules</span></li>
            </ul>
            <div className="landing-module__I_lyca__planFoot">
              <a href="https://discord.gg/XnMhR8U4VQ" target="_blank" rel="noopener noreferrer" className="landing-module__I_lyca__btn landing-module__I_lyca__btnBlock" aria-label="Select the Premium plan at $192/yr">Get Premium</a>
            </div>
          </article>
          <article className="landing-module__I_lyca__plan landing-module__I_lyca__reveal">
            <div className="landing-module__I_lyca__planTop"><h3 className="landing-module__I_lyca__planName">Enterprise</h3></div>
            <div className="landing-module__I_lyca__planPrice"><strong>$720</strong><span>/yr</span></div>
            <p className="landing-module__I_lyca__planNote">$60/mo, billed yearly</p>
            <p className="landing-module__I_lyca__planDesc">Dedicated limits for large distributors.</p>
            <ul className="landing-module__I_lyca__planFeatures">
              <li><span>Unlimited projects</span></li>
              <li><span>Unlimited keys</span></li>
              <li><span>100,000 monthly Centurion obfuscations</span></li>
              <li><span>1,500 monthly Luraph script protections</span></li>
              <li><span>Dedicated packaging queue</span></li>
              <li><span>Custom rate limits & IP rules</span></li>
              <li><span>SLA backed uptime</span></li>
              <li><span>Dedicated Discord bot instance</span></li>
              <li><span>Direct engineer support</span></li>
            </ul>
            <div className="landing-module__I_lyca__planFoot">
              <a href="https://discord.gg/XnMhR8U4VQ" target="_blank" rel="noopener noreferrer" className="landing-module__I_lyca__btn landing-module__I_lyca__btnBlock landing-module__I_lyca__btnGlass" aria-label="Select the Enterprise plan at $720/yr">Get Enterprise</a>
            </div>
          </article>
        </div>
      </section>
      <section className="landing-module__I_lyca__shell landing-module__I_lyca__shellNarrow landing-module__I_lyca__section" id="flow-faq">
        <header className="landing-module__I_lyca__secHead landing-module__I_lyca__reveal"><h2 className="landing-module__I_lyca__secTitle">Questions.</h2></header>
        <div className="landing-module__I_lyca__faqGrid">
          <details className="landing-module__I_lyca__faqItem landing-module__I_lyca__reveal">
            <summary>Can buyers see my source code?<span className="landing-module__I_lyca__faqSign" aria-hidden="true" /></summary>
            <p className="landing-module__I_lyca__faqAnswer">
              No. Your Lua/Luau assets stay server side in Switzauth and are delivered as protected packages only after the request passes your configured customer access flow. There is no public source endpoint to copy and reuse.
            </p>
          </details>
          <details className="landing-module__I_lyca__faqItem landing-module__I_lyca__reveal">
            <summary>How does HWID binding work?<span className="landing-module__I_lyca__faqSign" aria-hidden="true" /></summary>
            <p className="landing-module__I_lyca__faqAnswer">
              Keys can bind to the first approved machine. Later mismatches are rejected and logged, and you can reset a binding from the dashboard when a real customer changes devices.
            </p>
          </details>
          <details className="landing-module__I_lyca__faqItem landing-module__I_lyca__reveal">
            <summary>What stops someone replaying a request?<span className="landing-module__I_lyca__faqSign" aria-hidden="true" /></summary>
            <p className="landing-module__I_lyca__faqAnswer">
              Each delivery is tied to a signed session that expires quickly. Stale or replayed requests fail instead of turning into reusable links.
            </p>
          </details>
          <details className="landing-module__I_lyca__faqItem landing-module__I_lyca__reveal">
            <summary>Which executors does the loader run on?<span className="landing-module__I_lyca__faqSign" aria-hidden="true" /></summary>
            <p className="landing-module__I_lyca__faqAnswer">
              The loader is tested against 16 executors, including Delta, Vega X, Codex, SirHurt, plus the rest listed at the top of this page.
            </p>
          </details>
          <details className="landing-module__I_lyca__faqItem landing-module__I_lyca__reveal">
            <summary>Can I change plans later?<span className="landing-module__I_lyca__faqSign" aria-hidden="true" /></summary>
            <p className="landing-module__I_lyca__faqAnswer">
              Yes. Plans are monthly and you can move up or down at any time. The new limits apply from your current tier immediately.
            </p>
          </details>
          <details className="landing-module__I_lyca__faqItem landing-module__I_lyca__reveal">
            <summary>Do you offer refunds?<span className="landing-module__I_lyca__faqSign" aria-hidden="true" /></summary>
            <p className="landing-module__I_lyca__faqAnswer">See our refund policy for the full details on eligibility and how to request one.</p>
          </details>
        </div>
      </section>
    </main>
    <footer className="landing-module__I_lyca__shell landing-module__I_lyca__footer">
      <div className="landing-module__I_lyca__footerGrid">
        <div className="landing-module__I_lyca__footerBrand">
          <span className="landing-module__I_lyca__footerWordmark">
            <svg width="24" height="24" viewBox="0 0 100 100" fill="none" role="presentation" aria-hidden="true">
              <defs>
                <linearGradient id="fam_R_am5fj5b_-f" x1="10" y1="14" x2="86" y2="88" gradientUnits="userSpaceOnUse">
                  <stop offset="0" stopColor="#6E7BF0" />
                  <stop offset="0.36" stopColor="#C9A8F2" />
                  <stop offset="1" stopColor="#C44BE8" />
                </linearGradient>
              </defs>
              <g transform="translate(0 2.2)" fill="#3A2160" opacity="0.28">
                <path d="M23 37.5 Q23 18 42 18 L79 18 Q87 18 87 27.6 Q87 37.5 76 37.5 Z" />
                <path d="M12.7 60.6 Q12.7 41.2 31.7 41.2 L67 41.2 Q74.7 41.2 74.7 50.8 Q74.7 60.6 64 60.6 Z" />
                <path d="M23 64.6 L46.4 64.6 Q46.4 85.8 23 85.8 Z" />
              </g>
              <g fill="url(#fam_R_am5fj5b_-f)">
                <path d="M23 37.5 Q23 18 42 18 L79 18 Q87 18 87 27.6 Q87 37.5 76 37.5 Z" />
                <path d="M12.7 60.6 Q12.7 41.2 31.7 41.2 L67 41.2 Q74.7 41.2 74.7 50.8 Q74.7 60.6 64 60.6 Z" />
                <path d="M23 64.6 L46.4 64.6 Q46.4 85.8 23 85.8 Z" />
              </g>
            </svg>
            Switzauth
          </span>
          <p className="landing-module__I_lyca__footerTagline">The key system and source protection Roblox script hubs run on.</p>
        </div>
        <div className="landing-module__I_lyca__footerCol">
          <h4>Product</h4>
          <a href="/#flow-features" className="landing-module__I_lyca__footerLink">Features</a>
          <a href="/#flow-pricing" className="landing-module__I_lyca__footerLink">Pricing</a>
          <a className="landing-module__I_lyca__footerLink" href="/business">Business info</a>
          <a href="/register" className="landing-module__I_lyca__footerLink">Start free</a>
        </div>
        <div className="landing-module__I_lyca__footerCol">
          <h4>Platform</h4>
          <a href="/#flow-features" className="landing-module__I_lyca__footerLink">Key system</a>
          <a href="/#flow-features" className="landing-module__I_lyca__footerLink">Source protection</a>
          <a href="/#flow-features" className="landing-module__I_lyca__footerLink">Execution logs</a>
          <a href="/#flow-features" className="landing-module__I_lyca__footerLink">Discord bot</a>
        </div>
        <div className="landing-module__I_lyca__footerCol">
          <h4>Resources</h4>
          <a href="/docs" className="landing-module__I_lyca__footerLink">Documentation</a>
          <a href="/docs" className="landing-module__I_lyca__footerLink">Loader setup</a>
          <a className="landing-module__I_lyca__footerLink" href="/refund-policy">Refund policy</a>
          <a href="/login" className="landing-module__I_lyca__footerLink">Log in</a>
        </div>
        <div className="landing-module__I_lyca__footerCol">
          <h4>Company</h4>
          <a className="landing-module__I_lyca__footerLink" href="/terms">Terms of service</a>
          <a className="landing-module__I_lyca__footerLink" href="/privacy">Privacy policy</a>
          <a href="https://discord.gg/XnMhR8U4VQ" className="landing-module__I_lyca__footerLink">Contact</a>
          <a href="https://discord.gg/XnMhR8U4VQ" className="landing-module__I_lyca__footerLink">Discord</a>
        </div>
      </div>
      <div className="landing-module__I_lyca__footerLegal">
        <span className="landing-module__I_lyca__footerSignoff">Made by people who got tired of watching their scripts get leaked.</span>
        <span>© 2026 Switzauth. All rights reserved. Switzauth is not affiliated with or endorsed by Roblox Corporation.</span>
      </div>
    </footer>
  </div>