"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type ToastKind = "success" | "info" | "error" | "warning";

export type ToastItem = {
  id: number;
  kind: ToastKind;
  title: string;
  desc?: string;
  leaving?: boolean;
};

function ToastIcon({ kind }: { kind: ToastKind }) {
  const common = {
    width: 14,
    height: 14,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
  };
  if (kind === "success") {
    return (
      <svg {...common}>
        <path d="M20 6 9 17l-5-5" />
      </svg>
    );
  }
  if (kind === "error") {
    return (
      <svg {...common}>
        <circle cx="12" cy="12" r="10" />
        <path d="M12 8v4M12 16h.01" />
      </svg>
    );
  }
  if (kind === "warning") {
    return (
      <svg {...common}>
        <path d="M21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" />
        <path d="M12 9v4M12 17h.01" />
      </svg>
    );
  }
  return (
    <svg {...common}>
      <circle cx="12" cy="12" r="10" />
      <path d="M12 16v-4M12 8h.01" />
    </svg>
  );
}

export function Toaster({
  toasts,
  onDismiss,
}: {
  toasts: ToastItem[];
  onDismiss: (id: number) => void;
}) {
  if (toasts.length === 0) return null;
  return (
    <div className="fa-toaster" role="region" aria-label="Notifications">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={
            toast.leaving
              ? `fa-toast fa-toast-${toast.kind} fa-toast-leaving`
              : `fa-toast fa-toast-${toast.kind}`
          }
          role="status"
          aria-live="polite"
        >
          <span className="fa-toast-icon" aria-hidden="true">
            <ToastIcon kind={toast.kind} />
          </span>
          <span className="fa-toast-text">
            <span className="fa-toast-title">{toast.title}</span>
            {toast.desc ? <span className="fa-toast-desc">{toast.desc}</span> : null}
          </span>
          <button
            type="button"
            className="fa-toast-close"
            aria-label="Dismiss notification"
            onClick={() => onDismiss(toast.id)}
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </div>
      ))}
    </div>
  );
}

export function useToasts() {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const nextId = useRef(1);
  const timers = useRef<Map<number, ReturnType<typeof setTimeout>[]>>(new Map());

  const dismiss = useCallback((id: number) => {
    setToasts((list) =>
      list.map((t) => (t.id === id ? { ...t, leaving: true } : t))
    );
    const t = setTimeout(() => {
      setToasts((list) => list.filter((item) => item.id !== id));
    }, 400);
    const existing = timers.current.get(id) || [];
    timers.current.set(id, [...existing, t]);
  }, []);

  const push = useCallback(
    (kind: ToastKind, title: string, desc?: string) => {
      const id = nextId.current++;
      setToasts((list) => [...list.slice(-3), { id, kind, title, desc }]);
      const t = setTimeout(() => dismiss(id), 3400);
      timers.current.set(id, [t]);
    },
    [dismiss]
  );

  useEffect(() => {
    const map = timers.current;
    return () => {
      map.forEach((list) => list.forEach(clearTimeout));
      map.clear();
    };
  }, []);

  return { toasts, push, dismiss };
}
