"use client";

import { useEffect, useState } from "react";

/**
 * Live "Executions · 24h" value for the dashboard overview — the same
 * `/api/v1/public/activity?range=24h` contract the LiveExecutionsChart
 * consumes, deduplicated through a module-level TTL cache so the stat card,
 * the "Recorded activity" row, and the chart share one request per window.
 *
 * The captured workspace has no recorded runs, so the SSR output (0) matches
 * the scraped snapshot; after hydration the value follows the endpoint.
 */

export interface Executions24h {
  total: number;
  devices: number;
}

const TTL_MS = 30_000;

let cache: { at: number; value: Executions24h } | null = null;
let inflight: Promise<Executions24h> | null = null;

function readValue(): Promise<Executions24h> {
  if (cache && Date.now() - cache.at < TTL_MS) return Promise.resolve(cache.value);
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const response = await fetch("/api/v1/public/activity?range=24h");
      if (!response.ok) throw new Error("failed");
      const data = (await response.json()) as {
        total?: unknown;
        executions_24h?: unknown;
        unique_devices_24h?: unknown;
      };
      const total =
        typeof data.executions_24h === "number" && Number.isSafeInteger(data.executions_24h) && data.executions_24h >= 0
          ? data.executions_24h
          : 0;
      const devices =
        typeof data.unique_devices_24h === "number" &&
        Number.isSafeInteger(data.unique_devices_24h) &&
        data.unique_devices_24h >= 0
          ? data.unique_devices_24h
          : 0;
      const value = { total, devices };
      cache = { at: Date.now(), value };
      return value;
    } catch {
      const value = { total: 0, devices: 0 };
      cache = { at: Date.now(), value };
      return value;
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}

export function useExecutions24h(): Executions24h {
  const [value, setValue] = useState<Executions24h>({ total: 0, devices: 0 });

  useEffect(() => {
    // Initial read deferred to a rAF (codebase pattern — avoids the
    // synchronous setState-in-effect cascade).
    let cancelled = false;
    const frame = requestAnimationFrame(() => {
      readValue().then((next) => {
        if (!cancelled) setValue(next);
      });
    });
    return () => {
      cancelled = true;
      cancelAnimationFrame(frame);
    };
  }, []);

  return value;
}
