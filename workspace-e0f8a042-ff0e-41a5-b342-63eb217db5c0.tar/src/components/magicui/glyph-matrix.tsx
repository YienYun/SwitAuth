"use client"

/**
 * GlyphMatrix — canvas field of living glyphs (the set "0 1 · • + * / < > =").
 * Ported to the Switzauth design system from the MagicUI registry API:
 * glyphs / color / cellSize / mutationRate / interval / fadeBottom.
 * Every tick, a slice of cells mutates to a new glyph and re-ignites, while
 * the rest gently decay — the bottom `fadeBottom` fraction of the surface
 * fades out. Respects prefers-reduced-motion (static field, no mutation).
 */

import { useEffect, useRef } from "react"

export interface GlyphMatrixProps {
  glyphs?: string
  color?: string
  cellSize?: number
  mutationRate?: number
  interval?: number
  fadeBottom?: number
  className?: string
}

export function GlyphMatrix({
  glyphs = "01·•+*/\\<>=",
  color = "#000000",
  cellSize = 14,
  mutationRate = 0.04,
  interval = 90,
  fadeBottom = 0.6,
  className,
}: GlyphMatrixProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const reduced =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches

    let cols = 1
    let rows = 1
    let width = 0
    let height = 0
    type Cell = { ch: string; a: number }
    let cells: Cell[] = []
    let raf = 0
    let last = 0
    let disposed = false

    const randGlyph = () => glyphs.charAt(Math.floor(Math.random() * glyphs.length))

    const draw = () => {
      ctx.clearRect(0, 0, width, height)
      ctx.font = `${Math.max(9, Math.round(cellSize * 0.62))}px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace`
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillStyle = color
      const fadeStart = height * (1 - fadeBottom)
      const fadeSpan = Math.max(1, height - fadeStart)
      for (let r = 0; r < rows; r++) {
        const y = r * cellSize + cellSize / 2
        for (let c = 0; c < cols; c++) {
          const cell = cells[r * cols + c]
          let alpha = cell.a
          if (y > fadeStart) alpha *= Math.max(0, 1 - (y - fadeStart) / fadeSpan)
          if (alpha <= 0.02) continue
          ctx.globalAlpha = alpha
          ctx.fillText(cell.ch, c * cellSize + cellSize / 2, y)
        }
      }
      ctx.globalAlpha = 1
    }

    const resize = () => {
      const rect = canvas.getBoundingClientRect()
      width = Math.max(cellSize, rect.width)
      height = Math.max(cellSize, rect.height)
      const dpr = window.devicePixelRatio || 1
      canvas.width = Math.round(width * dpr)
      canvas.height = Math.round(height * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      cols = Math.max(1, Math.floor(width / cellSize))
      rows = Math.max(1, Math.floor(height / cellSize))
      cells = Array.from({ length: cols * rows }, () => ({
        ch: randGlyph(),
        a: 0.08 + Math.random() * 0.72,
      }))
      draw()
    }

    const tick = (now: number) => {
      if (disposed) return
      if (now - last >= interval) {
        last = now
        for (let i = 0; i < cells.length; i++) {
          if (Math.random() < mutationRate) {
            cells[i].ch = randGlyph()
            cells[i].a = 0.2 + Math.random() * 0.8
          } else {
            cells[i].a *= 0.974
          }
        }
        draw()
      }
      raf = requestAnimationFrame(tick)
    }

    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(canvas)
    if (reduced) draw()
    else raf = requestAnimationFrame(tick)

    return () => {
      disposed = true
      cancelAnimationFrame(raf)
      ro.disconnect()
    }
  }, [glyphs, color, cellSize, mutationRate, interval, fadeBottom])

  return <canvas ref={canvasRef} className={className} aria-hidden="true" />
}

export default GlyphMatrix
