import { NextResponse } from "next/server";

/**
 * Public executions counter endpoint (mirrors /v1/public/executions of the
 * original platform). The counter ticks up slowly over time so the landing
 * page's 10s polling (same cadence as the original PublicHome component)
 * sees a live, monotonic value.
 */
const BASE_RUNS = 48_312_946;
// Deterministic epoch so serverless re-invocations stay monotonic.
const EPOCH = 1_782_000_000; // fixed reference timestamp (seconds)
// One additional execution roughly every 40 seconds.
const PER_SECOND = 1 / 40;

export async function GET() {
  const now = Math.floor(Date.now() / 1000);
  const drift = Math.max(0, Math.floor((now - EPOCH) * PER_SECOND));
  return NextResponse.json(
    {
      runs_all_time: BASE_RUNS + drift,
      updated_at: now,
    },
    { headers: { "cache-control": "no-store" } }
  );
}
