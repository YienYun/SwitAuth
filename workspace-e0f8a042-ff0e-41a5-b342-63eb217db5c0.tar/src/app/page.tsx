"use client";

import { useCallback, useEffect, useState } from "react";
import Landing from "@/components/clone/Landing";
import WorkspaceViewShell, { type WorkspaceView } from "@/components/clone/WorkspaceView";

type AppState = "landing" | WorkspaceView;

const TITLES: Record<AppState, string> = {
  landing: "Switzauth - Lua/Luau Source Protection and Key Licensing",
  dashboard: "Switzauth / Dashboard",
  projects: "Switzauth / Projects",
  rewards: "Switzauth / Rewards",
  obfuscator: "Switzauth / Obfuscator",
  api: "Switzauth / API",
  mcp: "Switzauth / MCP Server",
  changelog: "Switzauth / Changelog",
  profile: "Switzauth / Profile",
  docs: "Switzauth / Docs",
  keys: "Switzauth / Keys",
  decompiler: "Switzauth / Decompiler",
};

const SESSION_KEY = "switzauth-view-v1";

// Persistent auth marker: entering the workspace ("logging in") flips the
// landing CTAs from "Start free" to "Open Dashboard"; logging out clears it.
const AUTH_KEY = "switzauth-auth-v1";

function markAuthed() {
  try {
    window.localStorage.setItem(AUTH_KEY, "1");
  } catch {
    /* storage unavailable */
  }
}

function clearAuthed() {
  try {
    window.localStorage.removeItem(AUTH_KEY);
  } catch {
    /* storage unavailable */
  }
}

function initialAppState(): AppState {
  if (typeof window === "undefined") return "landing";
  try {
    const saved = window.sessionStorage.getItem(SESSION_KEY) as AppState | null;
    if (saved && saved in TITLES) return saved;
  } catch {
    /* storage unavailable */
  }
  return "landing";
}

export default function Home() {
  const [state, setState] = useState<AppState>("landing");

  // Restore the active section across reloads (the original used real routes,
  // so a browser refresh kept the workspace view — session persistence gives
  // the clone the same behaviour without touching the URL). The restore runs
  // in a rAF callback (subscribe-then-update, never a cascading sync render).
  useEffect(() => {
    const saved = initialAppState();
    if (saved === "landing") return;
    const raf = requestAnimationFrame(() => setState(saved));
    return () => cancelAnimationFrame(raf);
  }, []);

  const enterApp = useCallback(() => {
    markAuthed();
    setState("dashboard");
  }, []);
  // Sidebar brand click: go to the marketing page but keep the session —
  // the landing CTAs keep offering "Open Dashboard".
  const exitToLanding = useCallback(() => {
    setState("landing");
    try {
      window.sessionStorage.setItem(SESSION_KEY, "landing");
    } catch {
      /* storage unavailable */
    }
    window.scrollTo({ top: 0, behavior: "auto" });
  }, []);
  // Real log out (sidebar / account menu / mobile drawer): clears the auth
  // marker so the landing shows the logged-out "Start for free" CTAs again.
  const logoutToLanding = useCallback(() => {
    clearAuthed();
    exitToLanding();
  }, [exitToLanding]);
  const navigate = useCallback((next: WorkspaceView) => {
    markAuthed();
    setState(next);
    try {
      window.sessionStorage.setItem(SESSION_KEY, next);
    } catch {
      /* storage unavailable */
    }
    window.scrollTo({ top: 0, behavior: "auto" });
  }, []);

  // Keep browser URL hash-free; mirror the app section in the document title.
  useEffect(() => {
    document.title = TITLES[state];
  }, [state]);

  if (state === "landing") {
    return <Landing onEnterApp={enterApp} onDocs={() => navigate("docs")} />;
  }

  return (
    <WorkspaceViewShell
      view={state}
      onNavigate={navigate}
      onExitToLanding={exitToLanding}
      onLogout={logoutToLanding}
    />
  );
}
