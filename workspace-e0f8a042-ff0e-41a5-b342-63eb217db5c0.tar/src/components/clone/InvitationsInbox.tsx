"use client";

import { useEffect } from "react";

/**
 * "Project invitations" inbox — ported 1:1 from the decompiled inbox dialog
 * (chunk 3k6a5lhrkscp5.js, component aX + wrapper aJ). Uses the extracted
 * `project-collaborators-module__FbxJEW__*` styles from dash-b.css directly:
 * blurred overlay with fade-in, centered 600px dialog with dialog-in motion,
 * eyebrow "Project sharing" header and the "You're all caught up" empty state
 * with the check-check glyph.
 */

export default function InvitationsInbox({ onClose }: { onClose: () => void }) {
  // Escape closes the dialog (capture phase so the workspace-wide Escape
  // handler for the palette/modals does not also fire).
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      event.stopPropagation();
      event.preventDefault();
      onClose();
    };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [onClose]);

  return (
    <>
      <div
        className="project-collaborators-module__FbxJEW__overlay"
        data-state="open"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="project-collaborators-module__FbxJEW__dialog"
        data-state="open"
        role="dialog"
        aria-modal="true"
        aria-labelledby="inbox-dialog-title"
        aria-describedby="inbox-dialog-description"
      >
        <header className="project-collaborators-module__FbxJEW__header">
          <div className="project-collaborators-module__FbxJEW__heading">
            <span className="project-collaborators-module__FbxJEW__eyebrow">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                <path d="M16 3.128a4 4 0 0 1 0 7.744" />
                <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                <circle cx="9" cy="7" r="4" />
              </svg>{" "}
              Project sharing
            </span>
            <h2 id="inbox-dialog-title" className="project-collaborators-module__FbxJEW__title">
              Project invitations
            </h2>
            <p id="inbox-dialog-description" className="project-collaborators-module__FbxJEW__description">
              Choose which projects you want to join.
            </p>
          </div>
          <button
            type="button"
            className="project-collaborators-module__FbxJEW__close"
            aria-label="Close"
            onClick={onClose}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 6 6 18M6 6l12 12" />
            </svg>
          </button>
        </header>
        <div className="project-collaborators-module__FbxJEW__body">
          <div className="project-collaborators-module__FbxJEW__empty">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 6 7 17l-5-5" />
              <path d="m22 10-7.5 7.5L13 16" />
            </svg>
            <h3>You&rsquo;re all caught up</h3>
            <p>New project invitations will appear here.</p>
          </div>
        </div>
      </div>
    </>
  );
}
