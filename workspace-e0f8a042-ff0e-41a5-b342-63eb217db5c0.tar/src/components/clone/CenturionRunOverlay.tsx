"use client"

/**
 * CenturionRunOverlay — the Obfuscator's full-card "protection run" show.
 *
 * Rendered through a React portal directly into the output `.editorCard`, so
 * during the run the WHOLE card becomes the visualization (user request: the
 * animation must fill the card, not half of it) — and ONLY during the run:
 * when `onFinish` fires the portal unmounts and the real output is revealed.
 *
 * Visual system (user-directed): a living GlyphMatrix field as the backdrop,
 * and a Centurion node-network on top — Source file, Anti-Tamper, VM
 * Generation, VM Compression and the Integrity Seal feed their beams into the
 * Centurion hub, which streams the protected payload out to obfuscated.lua.
 * Stage names and the pipeline passes (AST Obfuscation / Intense VM
 * Generation / VM Compression / loadstring delivery) come from the decompiled
 * FlowAuth sources. All node telemetry is derived deterministically from the
 * source text.
 *
 * NOTE: this project's Tailwind utilities ship as a precompiled, static
 * stylesheet scoped to `.dashboard-layout` — new utility classes would never
 * be generated — so this component is styled entirely with dedicated CSS in
 * `src/app/styles/obfuscator.css` (centurion-* classes). No Tailwind here.
 */

import { useEffect, useMemo, useRef, useState, type Ref } from "react"
import {
  Braces,
  Cpu,
  Fingerprint,
  FileCode2,
  Gauge,
  Lock,
  ShieldCheck,
  type LucideIcon,
} from "lucide-react"
import { GlyphMatrix } from "@/components/magicui/glyph-matrix"
import { AnimatedBeam } from "@/components/magicui/animated-beam"

type Stage = "parsing" | "obfuscating" | "finished"

export interface CenturionRunOverlayProps {
  fileName: string
  bytes: number
  lines: number
  seed: string
  onFinish: () => void
  onAbort: () => void
}

interface Step {
  at: number // fraction [0..1] of the run duration
  stage?: Stage
  pct?: number
}

function hashSeed(seed: string): number {
  let h = 2166136261
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

function fmtBytes(n: number): string {
  if (n >= 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`
  if (n >= 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${n} B`
}

/** Node activation windows over the run progress [start, done]. */
const NODE_WINDOWS: Record<string, [number, number]> = {
  source: [0.04, 0.2],
  tamper: [0.2, 0.36],
  vmgen: [0.36, 0.52],
  compress: [0.52, 0.68],
  seal: [0.68, 0.84],
  output: [0.84, 0.97],
}

function nodeState(key: string, progress: number, stage: Stage): "idle" | "active" | "done" {
  if (stage === "finished") return "done"
  const [start, done] = NODE_WINDOWS[key]
  if (progress >= done) return "done"
  if (progress >= start) return "active"
  return "idle"
}

export default function CenturionRunOverlay({
  fileName,
  bytes,
  lines,
  seed,
  onFinish,
  onAbort,
}: CenturionRunOverlayProps) {
  const [stage, setStage] = useState<Stage>("parsing")
  const [progress, setProgress] = useState(0)
  const targetRef = useRef(0)
  const finishedRef = useRef(false)

  // Theme-aware glyph ink (the app themes via html[data-theme]). The overlay
  // only ever mounts on a user click (client-only portal), so reading the live
  // theme in the lazy initializer is hydration-safe.
  const [ink, setInk] = useState(() => {
    const dark =
      typeof document !== "undefined" && document.documentElement.dataset.theme === "dark"
    return { color: dark ? "#cfc9e6" : "#241d3a", dark }
  })
  useEffect(() => {
    const el = document.documentElement
    const mo = new MutationObserver(() => {
      const dark = el.dataset.theme === "dark"
      setInk({ color: dark ? "#cfc9e6" : "#241d3a", dark })
    })
    mo.observe(el, { attributes: true, attributeFilter: ["data-theme"] })
    return () => mo.disconnect()
  }, [])

  const dur = useMemo(() => {
    const reduced =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    const base = 3800
    return reduced
      ? 1400
      : Math.min(4800, Math.round(base * (1 + Math.min(0.26, bytes / (256 * 1024)))))
  }, [bytes])

  // Deterministic telemetry for the node sublabels — same input, same run.
  const telemetry = useMemo(() => {
    const h = hashSeed(seed)
    return {
      nodes: Math.max(12, lines * 7 + (h % 41)),
      superops: 12 + ((h >> 3) % 29),
      compaction: 41 + ((h >> 6) % 38),
      fingerprint: Array.from({ length: 6 }, (_, i) => "0123456789abcdef"[(h >> (i * 4)) & 15]).join(""),
    }
  }, [seed, lines])

  // ── Schedule: the decompiled stage machine + eased progress ──
  useEffect(() => {
    const steps: Step[] = [
      { at: 0.0, stage: "parsing", pct: 0.06 },
      { at: 0.24, pct: 0.26 },
      { at: 0.36, stage: "obfuscating", pct: 0.4 },
      { at: 0.5, pct: 0.56 },
      { at: 0.62, pct: 0.68 },
      { at: 0.74, pct: 0.8 },
      { at: 0.86, pct: 0.9 },
      { at: 0.945, pct: 0.97 },
      { at: 0.95, stage: "finished" },
    ]
    const timers = steps.map((s) =>
      setTimeout(() => {
        if (s.stage) setStage(s.stage)
        if (typeof s.pct === "number") targetRef.current = s.pct
      }, Math.round(s.at * dur)),
    )

    const reduced =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches

    const snap = reduced
      ? setTimeout(() => {
          targetRef.current = 1
          setProgress(1)
        }, 0)
      : null

    let raf = 0
    let cur = 0
    if (!reduced) {
      const tick = () => {
        cur += (targetRef.current - cur) * 0.075
        if (Math.abs(targetRef.current - cur) < 0.0008) cur = targetRef.current
        setProgress((prev) => (Math.abs(prev - cur) > 0.0015 ? cur : prev))
        raf = requestAnimationFrame(tick)
      }
      raf = requestAnimationFrame(tick)
    }

    const done = setTimeout(() => {
      if (finishedRef.current) return
      finishedRef.current = true
      targetRef.current = 1
      setProgress(1)
      setStage("finished")
      // The captured ~200 ms beat before the output lands.
      setTimeout(onFinish, reduced ? 120 : 220)
    }, dur)

    return () => {
      timers.forEach(clearTimeout)
      cancelAnimationFrame(raf)
      clearTimeout(done)
      if (snap) clearTimeout(snap)
      // Navigating away mid-run aborts the show — let the host reset the UI.
      if (!finishedRef.current) {
        finishedRef.current = true
        onAbort()
      }
    }
  }, [dur, onFinish, onAbort])

  // ── Refs for the node graph ──
  const graphRef = useRef<HTMLDivElement | null>(null)
  const sourceRef = useRef<HTMLDivElement | null>(null)
  const tamperRef = useRef<HTMLDivElement | null>(null)
  const vmgenRef = useRef<HTMLDivElement | null>(null)
  const hubRef = useRef<HTMLDivElement | null>(null)
  const compressRef = useRef<HTMLDivElement | null>(null)
  const sealRef = useRef<HTMLDivElement | null>(null)
  const outputRef = useRef<HTMLDivElement | null>(null)

  const pct = Math.round(progress * 100)
  const stageLabel = stage === "parsing" ? "Parsing" : stage === "obfuscating" ? "Obfuscating" : "Finished"

  return (
    <div
      className="centurionOverlay"
      role="status"
      aria-live="polite"
      aria-busy="true"
      data-stage={stage}
    >
      {/* Living glyph field backdrop */}
      <GlyphMatrix
        glyphs="01·•+*/\\<>="
        color={ink.color}
        cellSize={14}
        mutationRate={0.045}
        interval={85}
        fadeBottom={0.5}
        className="centurionGlyphField"
      />
      {/* soft center glow so the graph pops off the field */}
      <div className="centurionCenterGlow" data-dark={ink.dark ? "true" : undefined} />

      {/* Header: captured copy + live chip */}
      <div className="centurionHeader">
        <div className="centurionHeaderLeft">
          <span className="obfuscation-progress-module__BveNEG__spinner" aria-hidden="true" />
          <div>
            <h3 className="centurionTitle">Protecting your script</h3>
            <p className="centurionSub">
              Centurion is processing <strong>{fileName || "your script"}</strong>.
            </p>
          </div>
        </div>
        <span className="centurionChip" data-stage={stage}>
          <i />
          {stageLabel}
          {stage === "finished" ? "" : ` · ${pct}%`}
        </span>
      </div>

      {/* Node network — beams feed the Centurion hub */}
      <div className="centurionGraphWrap">
        <div ref={graphRef} className="centurionGraph">
          <div className="centurionRow">
            <Node ref={sourceRef} icon={FileCode2} label="Source" sub={fmtBytes(bytes)} state={nodeState("source", progress, stage)} />
            <Node ref={tamperRef} icon={Fingerprint} label="Anti-Tamper" sub={`sig ${telemetry.fingerprint}`} state={nodeState("tamper", progress, stage)} />
          </div>
          <div className="centurionRow">
            <Node ref={vmgenRef} icon={Cpu} label="VM Generation" sub={`${telemetry.nodes} nodes`} state={nodeState("vmgen", progress, stage)} />
            <Node ref={hubRef} icon={ShieldCheck} label="Centurion" hub state={stage === "finished" ? "done" : "active"} />
            <Node ref={compressRef} icon={Gauge} label="Compression" sub={`${telemetry.compaction}% smaller`} state={nodeState("compress", progress, stage)} />
          </div>
          <div className="centurionRow">
            <Node ref={sealRef} icon={Lock} label="Integrity Seal" sub={`${lines} lines`} state={nodeState("seal", progress, stage)} />
            <Node ref={outputRef} icon={Braces} label="obfuscated.lua" sub="loadstring-ready" state={nodeState("output", progress, stage)} />
          </div>

          <AnimatedBeam containerRef={graphRef} fromRef={sourceRef} toRef={hubRef} curvature={-58} endYOffset={-8} delay={0} duration={2.3} />
          <AnimatedBeam containerRef={graphRef} fromRef={tamperRef} toRef={hubRef} curvature={-58} endYOffset={8} delay={1.1} duration={2.3} />
          <AnimatedBeam containerRef={graphRef} fromRef={vmgenRef} toRef={hubRef} delay={2} duration={2.3} />
          <AnimatedBeam containerRef={graphRef} fromRef={compressRef} toRef={hubRef} delay={0.5} duration={2.3} />
          <AnimatedBeam containerRef={graphRef} fromRef={sealRef} toRef={hubRef} curvature={58} endYOffset={10} delay={1.6} duration={2.3} />
          <AnimatedBeam containerRef={graphRef} fromRef={hubRef} toRef={outputRef} curvature={58} endYOffset={-10} delay={0.8} duration={2.3} />
        </div>
      </div>

      {/* Footer: transfer meter + meta + captured hint */}
      <div className="centurionFooter">
        <div className="centurionMeter" aria-hidden="true">
          <i style={{ width: `${pct}%` }} data-full={progress >= 0.999 ? "true" : undefined} />
        </div>
        <div className="centurionMetaRow">
          <span>{stageLabel}</span>
          <span>{fmtBytes(Math.round(bytes * progress))} / {fmtBytes(bytes)}</span>
          <span>{pct}%</span>
        </div>
        <p className="centurionHint">Your output will appear here when it’s ready.</p>
      </div>
    </div>
  )
}

interface NodeProps {
  icon: LucideIcon
  label: string
  sub?: string
  state: "idle" | "active" | "done"
  hub?: boolean
  ref?: Ref<HTMLDivElement>
}

function Node({ icon: Icon, label, sub, state, hub = false, ref }: NodeProps) {
  return (
    <div className="centurionNodeCol">
      <div ref={ref} className="centurionNode" data-state={hub ? (state === "idle" ? "active" : state) : state} data-size={hub ? "hub" : "md"}>
        <Icon size={hub ? 26 : 20} strokeWidth={1.7} aria-hidden="true" />
      </div>
      <div className="centurionNodeText">
        <div className="centurionNodeLabel" data-state={state}>{label}</div>
        {sub ? <div className="centurionNodeSub">{sub}</div> : null}
      </div>
    </div>
  )
}
