"use client";

import { useKeyCounts } from "./useKeyCounts";

/**
 * The "Active keys" overview stat, hydrated from the persisted key records.
 * The captured account had exactly one active key, so the SSR output
 * (1) is identical to the scraped snapshot; after hydration the number
 * reflects the real records and updates live when KeysBody writes them.
 */
export default function LiveKeysStat() {
  const { active } = useKeyCounts();
  return <span className="fa-stat-number">{active}</span>;
}
