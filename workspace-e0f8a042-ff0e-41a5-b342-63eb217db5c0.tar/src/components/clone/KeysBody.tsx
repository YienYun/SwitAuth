"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Check,
  Clock,
  Play,
  Plus,
  RefreshCw,
  Search,
  Trash2,
  UploadCloud,
} from "lucide-react";
import CreateKeysModal from "./CreateKeysModal";
import ImportUsersModal from "./ImportUsersModal";
import KeyDurationModal, { type DurationRecord } from "./KeyDurationModal";
import FaSelect from "./FaSelect";
import WorkspaceShell from "./WorkspaceShell";
import { mintKeyValue } from "./keysMint";

/**
 * "Users & access keys" page — the sidebar section the archive captured only
 * as a rendered screenshot (user key 2.png) plus the decompiled JSX in chunk
 * 3k6a5lhrkscp5.js (`lE && "keys" === et` branch). Class names are the plain
 * global ones (`keysWorkspace`, `keyRecord`, …) that ship inside the ported
 * theme.css design system, and the summary rail is the decompiled
 * key-health-module__ijECoq__* component (ef).
 *
 * The clone is single-tenant: records are held in localStorage
 * ("switzauth-keys-v1") seeded with the captured demo key.
 */

type KeyStatus = "active" | "paused" | "expired" | "revoked" | "blacklisted";

export interface KeyRecord {
  id: string;
  value: string;
  note: string;
  tier: "premium" | "free";
  status: KeyStatus;
  createdLabel: string;
  hwid: string | null;
  /** null = lifetime */
  expiresLabel: string | null;
  /**
   * Duration metadata driving the decompiled key-duration dialog (ey).
   * Optional so records persisted by earlier rounds still load; they read as
   * lifetime keys. `expiresAfterMs` = TTL from first use (expires_after_ms),
   * the paused pair freezes remaining time while the key is paused.
   */
  numericId?: number;
  expiresAtMs?: number | null;
  claimedAtMs?: number | null;
  expiresAfterMs?: number | null;
  pausedAtMs?: number | null;
  pausedRemainingMs?: number | null;
}

const STORAGE_KEY = "switzauth-keys-v1";
const PROJECT_NAME = "jh9iu";

/** The key visible in the captured screenshot of the original workspace. */
const SEED_RECORDS: KeyRecord[] = [
  {
    id: "k-1",
    value: "vVMw23JJS0uhTqpksfwDKl1ihjlz",
    note: "",
    tier: "premium",
    status: "active",
    createdLabel: "27 Sep 2026 20:01",
    hwid: null,
    expiresLabel: null,
    numericId: 1,
    expiresAtMs: null,
    claimedAtMs: null,
    expiresAfterMs: null,
    pausedAtMs: null,
    pausedRemainingMs: null,
  },
];

function loadRecords(): KeyRecord[] {
  if (typeof window === "undefined") return SEED_RECORDS;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return Array.isArray(parsed?.records) && parsed.records.length
      ? (parsed.records as KeyRecord[])
      : SEED_RECORDS;
  } catch {
    return SEED_RECORDS;
  }
}

function saveRecords(records: KeyRecord[]) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ records }));
    // Live metrics (dashboard stat, users-chart total, usage gauge) listen
    // for this so same-tab updates re-render without a remount.
    window.dispatchEvent(new Event("switzauth-keys-changed"));
  } catch {
    /* storage unavailable */
  }
}

const STATUS_OPTIONS = [
  { value: "all", label: "All statuses" },
  { value: "active", label: "Active" },
  { value: "blacklisted", label: "Blacklisted" },
  { value: "paused", label: "Paused" },
  { value: "revoked", label: "Revoked" },
  { value: "expired", label: "Expired" },
];

/** Decompiled status → badge text + badge modifier class. */
function badgeFor(record: KeyRecord): { label: string; cls: string } {
  switch (record.status) {
    case "blacklisted":
      return { label: "Blocked", cls: "blacklisted" };
    case "paused":
      return { label: "Paused", cls: "paused" };
    case "expired":
      return { label: "Expired", cls: "expired" };
    case "revoked":
      return { label: "Revoked", cls: "revoked" };
    default:
      return { label: "Active", cls: "active" };
  }
}

function nowLabel(): string {
  return new Date().toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

const SEGMENTS = [
  { key: "active", cls: "segActive", tone: "toneActive", label: "Active" },
  { key: "paused", cls: "segPaused", tone: "tonePaused", label: "Paused" },
  { key: "expired", cls: "segExpired", tone: "toneExpired", label: "Expired" },
  { key: "blocked", cls: "segBlocked", tone: "toneBlocked", label: "Blocked" },
] as const;

export type ToastFn = (kind: "success" | "warning" | "error" | "info", title: string, desc?: string) => void;

export default function KeysBody({ onToast }: { onToast: ToastFn }) {
  // Lazy initializer reads the persisted records (hydration-safe: the keys
  // view only mounts client-side after in-app navigation).
  const [records, setRecords] = useState<KeyRecord[]>(() => loadRecords());
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [selected, setSelected] = useState<string[]>([]);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const [createOpen, setCreateOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [durationRecord, setDurationRecord] = useState<KeyRecord | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [barInView, setBarInView] = useState(false);
  const railRef = useRef<HTMLDivElement | null>(null);
  const searchRef = useRef<HTMLInputElement | null>(null);

  // Decompiled ef component animates the split bar when 25% visible.
  useEffect(() => {
    const rail = railRef.current;
    if (!rail || typeof IntersectionObserver === "undefined") {
      const raf = requestAnimationFrame(() => setBarInView(true));
      return () => cancelAnimationFrame(raf);
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setBarInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.25 },
    );
    observer.observe(rail);
    return () => observer.disconnect();
  }, []);

  const update = (next: KeyRecord[]) => {
    setRecords(next);
    saveRecords(next);
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return records.filter((record) => {
      if (status !== "all" && record.status !== status) return false;
      if (!q) return true;
      return (
        record.value.toLowerCase().includes(q) ||
        record.note.toLowerCase().includes(q) ||
        (record.hwid || "").toLowerCase().includes(q)
      );
    });
  }, [records, query, status]);

  const counts = useMemo(() => {
    const c = { active: 0, paused: 0, expired: 0, blocked: 0, created24h: 0, linked: 0 };
    for (const record of records) {
      if (record.status === "active") c.active += 1;
      else if (record.status === "paused") c.paused += 1;
      else if (record.status === "expired" || record.status === "revoked") c.expired += 1;
      else if (record.status === "blacklisted") c.blocked += 1;
      if (record.hwid) c.linked += 1;
    }
    return c;
  }, [records]);

  const total = records.length;
  const attention = counts.paused + counts.expired + counts.blocked;
  const allVisibleSelected =
    filtered.length > 0 && filtered.every((record) => selected.includes(record.id));

  const toggleRecord = (id: string) => {
    setSelected((list) =>
      list.includes(id) ? list.filter((item) => item !== id) : [...list, id],
    );
  };

  const toggleAll = () => {
    setSelected((list) => {
      if (filtered.length > 0 && filtered.every((record) => list.includes(record.id))) {
        return list.filter((id) => !filtered.some((record) => record.id === id));
      }
      return [...new Set([...list, ...filtered.map((record) => record.id)])];
    });
  };

  const copyKey = async (record: KeyRecord) => {
    try {
      await navigator.clipboard.writeText(record.value);
      setRevealed((state) => ({ ...state, [record.id]: true }));
      onToast("success", "Key copied", `${record.value.slice(0, 10)}… is on your clipboard.`);
      setTimeout(() => {
        setRevealed((state) => ({ ...state, [record.id]: false }));
      }, 1800);
    } catch {
      onToast("error", "Copy failed", "Your browser blocked clipboard access.");
    }
  };

  const resetHwid = (record: KeyRecord) => {
    update(records.map((r) => (r.id === record.id ? { ...r, hwid: null } : r)));
    onToast("success", "HWID reset", `${record.value.slice(0, 10)}… can bind a new device.`);
  };

  const pauseKey = (record: KeyRecord) => {
    const now = Date.now();
    const next = records.map((r) => {
      if (r.id !== record.id) return r;
      if (r.status !== "paused") {
        // Pause: freeze the remaining time for the duration dialog (the
        // original paused_remaining_ms contract).
        const expiresAtMs = r.expiresAtMs ?? null;
        return {
          ...r,
          status: "paused" as KeyStatus,
          pausedAtMs: expiresAtMs !== null ? now : (r.pausedAtMs ?? null),
          pausedRemainingMs: expiresAtMs !== null ? Math.max(0, expiresAtMs - now) : (r.pausedRemainingMs ?? null),
        };
      }
      // Resume: paused time starts counting again from now.
      if (r.pausedAtMs != null) {
        return {
          ...r,
          status: "active" as KeyStatus,
          expiresAtMs: now + (r.pausedRemainingMs ?? 0),
          pausedAtMs: null,
          pausedRemainingMs: null,
          expiresLabel: new Date(now + (r.pausedRemainingMs ?? 0)).toLocaleString("en-GB", {
            day: "numeric",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
          }),
        };
      }
      return { ...r, status: "active" as KeyStatus };
    });
    update(next);
    onToast(
      record.status === "paused" ? "success" : "warning",
      record.status === "paused" ? "Key resumed" : "Key paused",
      record.status === "paused"
        ? `${record.value.slice(0, 10)}… authenticates again.`
        : `${record.value.slice(0, 10)}… stops authenticating until resumed.`,
    );
  };

  /** Duration metadata handed to the decompiled key-duration dialog. */
  const toDurationRecord = (record: KeyRecord): DurationRecord => ({
    numericId: record.numericId ?? records.indexOf(record) + 1,
    expiresAtMs: record.expiresAtMs ?? null,
    claimedAtMs: record.claimedAtMs ?? null,
    expiresAfterMs: record.expiresAfterMs ?? null,
    pausedAtMs: record.pausedAtMs ?? null,
    pausedRemainingMs: record.pausedRemainingMs ?? null,
  });

  /** Decompiled parent onSave — POST /v1/keys/{id}/duration {mode,days} then
   * refresh; the clone applies the same semantics locally:
   * add → max(remaining,0) + days (an expired key starts from now);
   * set → days replaces the remaining time (or the unused key's first-use
   * TTL, which still starts on first use). */
  const applyDuration = (record: KeyRecord, mode: "add" | "set", days: number) => {
    const now = Date.now();
    const dayMs = 864e5;
    const paused = record.pausedAtMs != null;
    const unused = !record.claimedAtMs && record.expiresAtMs == null && !paused;
    const remaining = paused
      ? (record.pausedRemainingMs ?? 0)
      : unused
        ? (record.expiresAfterMs ?? 0)
        : record.expiresAtMs == null
          ? null
          : Math.max(0, record.expiresAtMs - now);
    const totalMs = (mode === "add" ? Math.max(remaining ?? 0, 0) : 0) + dayMs * days;
    const expiry = now + totalMs;
    const label = new Date(expiry).toLocaleString("en-GB", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
    update(
      records.map((r) => {
        if (r.id !== record.id) return r;
        if (unused) {
          // Unused keys carry a first-use TTL instead of an absolute date.
          const after = (mode === "add" ? (r.expiresAfterMs ?? 0) : 0) + dayMs * days;
          return {
            ...r,
            expiresAfterMs: after,
            expiresLabel: `${Math.round((after / dayMs) * 100) / 100} days on first use`,
          };
        }
        return {
          ...r,
          expiresAtMs: expiry,
          expiresLabel: label,
          pausedAtMs: null,
          pausedRemainingMs: null,
        };
      }),
    );
  };

  const deleteKeys = (ids: string[]) => {
    const next = records.filter((record) => !ids.includes(record.id));
    update(next);
    setSelected([]);
    onToast(
      "warning",
      ids.length > 1 ? "Keys deleted" : "Key deleted",
      `${ids.length} record${ids.length === 1 ? "" : "s"} revoked.`,
    );
  };

  const addRecords = (created: KeyRecord[]) => {
    update([...records, ...created]);
  };

  const refresh = () => {
    setRefreshing(true);
    setTimeout(() => {
      setRefreshing(false);
      onToast("info", "Records refreshed", "Access records are up to date.");
    }, 650);
  };

  const pct = (part: number) => (total > 0 ? (part / total) * 100 : 0);

  return (
    <WorkspaceShell active="Users / Keys" crumb="Keys" tab="keys">
      <div className="projects-container keysWorkspace">
      <div className="keysWorkspaceHeader">
        <div className="keysWorkspaceHeading">
          <h1>Users &amp; access keys</h1>
          <p>Control who can run this project&apos;s protected scripts.</p>
        </div>
        <div className="keysWorkspaceHeaderControls">
          <div className="keysProjectControl">
            <span>Project</span>
            <div className="fa-select keysProjectSelect">
              <span className="fa-select-toplabel" hidden>
                Project
              </span>
              <button
                type="button"
                className="fa-select-trigger"
                aria-haspopup="listbox"
                aria-expanded="false"
                aria-label={`Target project, ${PROJECT_NAME}`}
              >
                <span className="fa-select-value">{PROJECT_NAME}</span>
                <span className="fa-select-chevron">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </span>
              </button>
            </div>
          </div>
          <div className="keysWorkspaceActions">
            <button
              type="button"
              className="flow-btn flow-btn-primary flow-btn-md keysPrimaryAction"
              onClick={() => setCreateOpen(true)}
            >
              <span className="flow-btn-sweep" aria-hidden="true" />
              <span className="flow-btn-content">
                <Plus size={15} aria-hidden="true" />
                <span className="flow-btn-label">Add user</span>
              </span>
            </button>
            <button
              type="button"
              className="flow-btn flow-btn-secondary flow-btn-md keysSecondaryAction"
              onClick={() => setImportOpen(true)}
            >
              <span className="flow-btn-sweep" aria-hidden="true" />
              <span className="flow-btn-content">
                <UploadCloud size={14} aria-hidden="true" />
                <span className="flow-btn-label">Import</span>
              </span>
            </button>
            <button
              type="button"
              className="flow-btn flow-btn-secondary flow-btn-md keysRefreshAction"
              onClick={refresh}
              disabled={refreshing}
            >
              <span className="flow-btn-sweep" aria-hidden="true" />
              <span className="flow-btn-content">
                <RefreshCw size={14} aria-hidden="true" className={refreshing ? "spin" : undefined} />
                <span className="flow-btn-label">Refresh</span>
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Summary rail — decompiled key-health-module__ijECoq__ component */}
      <div ref={railRef} className="key-health-module__ijECoq__rail" aria-label="Access key summary">
        <div>
          <div className="key-health-module__ijECoq__lead">
            <span className="key-health-module__ijECoq__figure">{counts.active.toLocaleString()}</span>
            <span className="key-health-module__ijECoq__leadLabel">
              active of {total.toLocaleString()} {total === 1 ? "key" : "keys"}
            </span>
          </div>
          <div className="key-health-module__ijECoq__bar" role="img" aria-label="Key status split">
            {SEGMENTS.map((segment) => {
              const value = segment.key === "blocked" ? counts.blocked : counts[segment.key];
              return (
                <span
                  key={segment.key}
                  className={`key-health-module__ijECoq__seg key-health-module__ijECoq__${segment.cls}`}
                  style={{ width: barInView ? `${pct(value)}%` : "0%" }}
                />
              );
            })}
          </div>
          <div className="key-health-module__ijECoq__legend">
            {SEGMENTS.map((segment) => {
              const value = segment.key === "blocked" ? counts.blocked : counts[segment.key];
              return (
                <span key={segment.key} className="key-health-module__ijECoq__legendItem">
                  <span className={`key-health-module__ijECoq__legendName key-health-module__ijECoq__${segment.tone}`}>
                    {segment.label}
                  </span>
                  <span className="key-health-module__ijECoq__legendCount">{value.toLocaleString()}</span>
                </span>
              );
            })}
          </div>
        </div>
        <div className="key-health-module__ijECoq__figures">
          <div className="key-health-module__ijECoq__row">
            <span className="key-health-module__ijECoq__rowLabel">
              <span className="key-health-module__ijECoq__rowName">Created today</span>
              <span className="key-health-module__ijECoq__rowNote">Last 24 hours</span>
            </span>
            <span className="key-health-module__ijECoq__rowValue">{counts.created24h}</span>
          </div>
          <div className="key-health-module__ijECoq__row">
            <span className="key-health-module__ijECoq__rowLabel">
              <span className="key-health-module__ijECoq__rowName">Device linked</span>
              <span className="key-health-module__ijECoq__rowNote">HWID protected</span>
            </span>
            <span className="key-health-module__ijECoq__rowValue">{counts.linked}</span>
          </div>
          <div
            className={`key-health-module__ijECoq__row${attention > 0 ? " key-health-module__ijECoq__rowAlert" : ""}`}
          >
            <span className="key-health-module__ijECoq__rowLabel">
              <span className="key-health-module__ijECoq__rowName">Needs attention</span>
              <span className="key-health-module__ijECoq__rowNote">Paused, expired, blocked</span>
            </span>
            <span className="key-health-module__ijECoq__rowValue">{attention}</span>
          </div>
        </div>
      </div>

      <div className="keysCommandBar">
        <div className="keysCommandSearch">
          <div className="fa-field fa-field-unlabeled fa-field-iconed keysSearchField">
            <div className="fa-field-frame">
              <span className="fa-field-icon">
                <Search size={15} aria-hidden="true" />
              </span>
              <input
                ref={searchRef}
                type="search"
                className="fa-field-input"
                placeholder="Search key, note, or HWID"
                aria-label="Search key, note, or HWID"
                value={query}
                onChange={(event) => setQuery(event.target.value)}
              />
              <span className="fa-field-charge" aria-hidden="true" />
            </div>
          </div>
          <div className="fa-select keysStatusFilter">
            {/* Decompiled real select (module 52909) — functional dropdown. */}
            <FaSelect
              ariaLabel="Filter by status"
              value={status}
              onChange={setStatus}
              options={STATUS_OPTIONS}
            />
          </div>
        </div>
        <div className="keysCommandMeta">
          {selected.length > 0 ? (
            <button
              type="button"
              className="flow-btn flow-btn-danger flow-btn-md keysBulkDelete"
              onClick={() => deleteKeys(selected)}
            >
              <span className="flow-btn-sweep" aria-hidden="true" />
              <span className="flow-btn-content">
                <Trash2 size={14} aria-hidden="true" />
                <span className="flow-btn-label">{`Delete selected (${selected.length})`}</span>
              </span>
            </button>
          ) : null}
          <div className="keysResultCount">
            <strong>{filtered.length}</strong> shown of {total} total
          </div>
        </div>
      </div>

      <section className="keysRecordCollection" aria-label="Access key records">
        <div className="keysRecordHeader">
          <div className="keysRecordHeaderLead">
            <label className={`fa-check tableCheckboxControl${filtered.length === 0 ? " fa-check-disabled" : ""}`}>
              <input
                type="checkbox"
                className="fa-check-input"
                checked={allVisibleSelected}
                disabled={filtered.length === 0}
                onChange={toggleAll}
                aria-label="Select all visible keys"
              />
              <span className="fa-check-box" aria-hidden="true">
                <span className="fa-check-burst" />
                <svg viewBox="0 0 24 24" className="fa-check-mark" fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m5 12.8 4.6 4.6L19 7" />
                </svg>
              </span>
            </label>
            <div>
              <strong>Access records</strong>
              <span>
                {filtered.length} {filtered.length === 1 ? "key on this page" : "keys on this page"}
              </span>
            </div>
          </div>
          <span className="keysRecordHeaderHint">Select records for bulk actions</span>
        </div>
        <div className="keysRecordList">
          {filtered.length === 0 ? (
            <div className="keysEmptyResult">
              <Search size={20} aria-hidden="true" />
              <strong>No matching keys</strong>
              <span>Try a different key, note, HWID, or status.</span>
            </div>
          ) : (
            filtered.map((record) => {
              const badge = badgeFor(record);
              const isPaused = record.status === "paused";
              return (
                <article
                  key={record.id}
                  className={`keyRecord${selected.includes(record.id) ? " selected" : ""}`}
                >
                  <div className="keyRecordSelect">
                    <label className="fa-check tableCheckboxControl">
                      <input
                        type="checkbox"
                        className="fa-check-input"
                        checked={selected.includes(record.id)}
                        onChange={() => toggleRecord(record.id)}
                        aria-label={`Select key record ${record.id}`}
                      />
                      <span className="fa-check-box" aria-hidden="true">
                        <span className="fa-check-burst" />
                        <svg viewBox="0 0 24 24" className="fa-check-mark" fill="none" stroke="currentColor" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="m5 12.8 4.6 4.6L19 7" />
                        </svg>
                      </span>
                    </label>
                  </div>
                  <div className="keyRecordIdentity">
                    <div className="keyRecordIdentityInner">
                      { }
                      <img className="keyRecordIcon" src="/brand/key-icons/access.webp" alt="" aria-hidden="true" />
                      <div className="keyRecordPrimary">
                        <code title={record.value}>{record.value}</code>
                        <span className="keyRecordTimeSummary">{record.expiresLabel ?? "Lifetime"}</span>
                        <div className="keyRecordMeta">
                          <span>Created {record.createdLabel}</span>
                          <span className="keyRecordNote" title={record.note || ""}>
                            {record.note || "No note added"}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="keyRecordAccess">
                    <span className={`badge ${badge.cls}`}>{badge.label}</span>
                    <span className={`badge tier-badge tier-${record.tier}`}>
                      {record.tier.charAt(0).toUpperCase() + record.tier.slice(1)}
                    </span>
                  </div>
                  <div className="keyRecordDetail keyRecordDevice">
                    { }
                    <img src="/brand/key-icons/device-reset.webp" alt="" aria-hidden="true" />
                    <div>
                      <small>Device</small>
                      <span className={record.hwid ? "linked" : undefined} title={record.hwid || ""}>
                        {record.hwid ? `${record.hwid.slice(0, 12)}...` : "Not linked"}
                      </span>
                    </div>
                  </div>
                  <div className="keyRecordDetail keyRecordExpiry">
                    <Clock size={16} aria-hidden="true" />
                    <div>
                      <small>Expiry</small>
                      <span className={`keyExpiry${record.expiresLabel ? "" : " muted"}`}>
                        {record.expiresLabel ?? "Lifetime"}
                      </span>
                    </div>
                  </div>
                  <div className="keyRecordActions">
                    <div className="keyRecordActionGroup">
                      <button
                        type="button"
                        className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm keyRecordAction"
                        title={revealed[record.id] ? "Copied" : "Copy key"}
                        aria-label={revealed[record.id] ? "Copied" : "Copy key"}
                        onClick={() => void copyKey(record)}
                      >
                        <span className="flow-icon-btn-inner">
                          {revealed[record.id] ? (
                            <Check size={16} aria-hidden="true" />
                          ) : (
                             
                            <img src="/brand/key-icons/copy.webp" alt="" aria-hidden="true" />
                          )}
                        </span>
                      </button>
                      <button
                        type="button"
                        className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm keyRecordAction"
                        title="Reset HWID"
                        aria-label="Reset HWID"
                        onClick={() => resetHwid(record)}
                      >
                        <span className="flow-icon-btn-inner">
                          { }
                          <img src="/brand/key-icons/device-reset.webp" alt="" aria-hidden="true" />
                        </span>
                      </button>
                      <button
                        type="button"
                        className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm keyRecordAction"
                        title="Set or add days"
                        aria-label="Set or add days"
                        disabled={record.status !== "active"}
                        onClick={() => setDurationRecord(record)}
                      >
                        <span className="flow-icon-btn-inner">
                          <Clock size={16} aria-hidden="true" />
                        </span>
                      </button>
                      {isPaused ? (
                        <button
                          type="button"
                          className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm keyRecordAction"
                          title="Resume key"
                          aria-label="Resume key"
                          onClick={() => pauseKey(record)}
                        >
                          <span className="flow-icon-btn-inner">
                            <Play size={16} aria-hidden="true" />
                          </span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm keyRecordAction"
                          title="Pause key"
                          aria-label="Pause key"
                          onClick={() => pauseKey(record)}
                        >
                          <span className="flow-icon-btn-inner">
                            { }
                            <img src="/brand/key-icons/pause.webp" alt="" aria-hidden="true" />
                          </span>
                        </button>
                      )}
                      <button
                        type="button"
                        className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm keyRecordAction danger"
                        title="Delete key"
                        aria-label="Delete key"
                        onClick={() => deleteKeys([record.id])}
                      >
                        <span className="flow-icon-btn-inner">
                          { }
                          <img src="/brand/key-icons/revoke.webp" alt="" aria-hidden="true" />
                        </span>
                      </button>
                    </div>
                  </div>
                </article>
              );
            })
          )}
        </div>
      </section>

      <div className="keysPagination">
        <button type="button" className="flow-btn flow-btn-secondary flow-btn-sm" disabled>
          <span className="flow-btn-sweep" aria-hidden="true" />
          <span className="flow-btn-content"><span className="flow-btn-label">Previous</span></span>
        </button>
        <span>
          {total > 0 ? `1–${total}` : "0–0"} of {total} · Page 1 / 1
        </span>
        <button type="button" className="flow-btn flow-btn-secondary flow-btn-sm" disabled>
          <span className="flow-btn-sweep" aria-hidden="true" />
          <span className="flow-btn-content"><span className="flow-btn-label">Next</span></span>
        </button>
      </div>

      {createOpen ? (
        <CreateKeysModal
          onClose={() => setCreateOpen(false)}
          onToast={onToast}
          onCreate={(created) => {
            setCreateOpen(false);
            addRecords(created);
          }}
        />
      ) : null}
      {importOpen ? (
        <ImportUsersModal
          onClose={() => setImportOpen(false)}
          onToast={onToast}
          onImport={(created) => {
            setImportOpen(false);
            addRecords(created);
          }}
        />
      ) : null}
      {durationRecord ? (
        <KeyDurationModal
          record={toDurationRecord(durationRecord)}
          onClose={() => setDurationRecord(null)}
          onSave={(mode, days) => applyDuration(durationRecord, mode, days)}
        />
      ) : null}
      </div>
    </WorkspaceShell>
  );
}
