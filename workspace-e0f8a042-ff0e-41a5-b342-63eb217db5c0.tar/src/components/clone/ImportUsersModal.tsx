"use client";

import { useRef, useState } from "react";
import { UploadCloud, X } from "lucide-react";
import type { KeyRecord, ToastFn } from "./KeysBody";
import { mintKeyValue, nowLabel } from "./keysMint";

/**
 * "Import Users" dialog — port of the decompiled import modal in chunk
 * 3k6a5lhrkscp5.js (keys page "Import" button; visual reference:
 * import user.png). Decompiled contract: upload a TXT/CSV export or paste
 * migrated user keys — one key per line, or CSV columns
 * `key_value,note,expires_at`. Confirm stays disabled until keys exist.
 */

function parseExpiry(raw: string): { label: string | null; atMs: number | null } {
  const value = raw.trim();
  if (!value) return { label: null, atMs: null };
  const numeric = Number(value);
  let date: Date | null = null;
  if (Number.isFinite(numeric) && /^\d+$/.test(value)) {
    const parsed = new Date(numeric);
    if (!Number.isNaN(parsed.getTime())) date = parsed;
  }
  if (!date) {
    const parsed = new Date(value);
    if (!Number.isNaN(parsed.getTime())) date = parsed;
  }
  return date ? { label: formatExpiry(date), atMs: date.getTime() } : { label: null, atMs: null };
}

function formatExpiry(date: Date): string {
  return date.toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export default function ImportUsersModal({
  onClose,
  onToast,
  onImport,
}: {
  onClose: () => void;
  onToast: ToastFn;
  onImport: (created: KeyRecord[]) => void;
}) {
  const [fileName, setFileName] = useState("");
  const [keysText, setKeysText] = useState("");
  const [defaultNote, setDefaultNote] = useState("");
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const lines = keysText
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean);
  const confirmDisabled = busy || lines.length === 0;

  const readFile = (file: File) => {
    if (file.size > 512 * 1024) {
      onToast("warning", "File is too large", "Import files are limited to 512 KB.");
      return;
    }
    void file.text().then((text) => {
      setFileName(file.name);
      setKeysText((current) => (current.trim() ? current : text));
      onToast("info", "File loaded", `${file.name} is ready to import.`);
    });
  };

  const confirm = () => {
    if (confirmDisabled) return;
    setBusy(true);
    setTimeout(() => {
      const created: KeyRecord[] = [];
      // Server-style sequential ids for the "Access key #N" eyebrow.
      let maxNumeric = 0;
      try {
        const raw = window.localStorage.getItem("switzauth-keys-v1");
        const records = raw ? (JSON.parse(raw)?.records as Array<{ numericId?: number }> | undefined) : undefined;
        maxNumeric = (records ?? []).reduce((max, r) => Math.max(max, r.numericId ?? 0), 0);
      } catch {
        /* storage unavailable */
      }
      let sequence = 0;
      lines.forEach((line, i) => {
        const columns = line.split(",").map((column) => column.trim());
        // CSV header row (key_value,note,expires_at) is skipped.
        if (/^key[_-]?value$/i.test(columns[0] ?? "")) return;
        const [keyValue, note, expiresAt] = columns;
        const expiry = parseExpiry(expiresAt ?? "");
        sequence += 1;
        created.push({
          id: `k-${Date.now().toString(36)}-imp-${i}`,
          // The original imported the pasted key when plausible; the clone
          // keeps paste-fidelity but never accepts 8-char garbage.
          value:
            keyValue && keyValue.length >= 12 && keyValue.length <= 64
              ? keyValue
              : mintKeyValue(24),
          note: note || defaultNote,
          tier: "premium",
          status: "active",
          createdLabel: nowLabel(),
          hwid: null,
          expiresLabel: expiry.label,
          numericId: maxNumeric + sequence,
          expiresAtMs: expiry.atMs,
          claimedAtMs: expiry.atMs ? Date.now() : null,
          expiresAfterMs: null,
          pausedAtMs: null,
          pausedRemainingMs: null,
        });
      });
      const imported = created;
      setBusy(false);
      if (imported.length === 0) {
        onToast("warning", "Nothing imported", "No usable key rows were found.");
        return;
      }
      onImport(imported);
      onToast(
        "success",
        "Users imported",
        `${imported.length} access ${imported.length === 1 ? "key" : "keys"} added to jh9iu.`,
      );
    }, 550);
  };

  return (
    <div className="modal-overlay" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div
        className="glass-card modal-content workspaceFormModal"
        style={{ "--modal-w": "640px" } as React.CSSProperties}
        role="dialog"
        aria-modal="true"
        aria-label="Import Users"
      >
        <div className="modal-header">
          <h2>Import Users</h2>
          <button
            type="button"
            className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm modal-close"
            aria-label="Close import users"
            onClick={onClose}
            disabled={busy}
          >
            <span className="flow-icon-btn-inner">
              <X size={18} aria-hidden="true" />
            </span>
          </button>
        </div>
        <form
          className="project-edit-grid"
          onSubmit={(event) => {
            event.preventDefault();
            confirm();
          }}
        >
          <p style={{ color: "var(--text-secondary)", fontSize: "13px", lineHeight: 1.6, margin: 0 }}>
            Upload a TXT/CSV export or paste migrated user keys. Use one key per line, or CSV
            columns <code>key_value,note,expires_at</code>.
          </p>
          <div className="form-group">
            <label htmlFor="import-users-project">Target project</label>
            <div className="fa-select">
              <button
                id="import-users-project"
                type="button"
                className="fa-select-trigger"
                aria-haspopup="listbox"
                aria-expanded="false"
                aria-label="Target project, jh9iu"
              >
                <span className="fa-select-value">jh9iu</span>
                <span className="fa-select-chevron">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="m6 9 6 6 6-6" />
                  </svg>
                </span>
              </button>
            </div>
          </div>
          <div style={{ display: "flex", gap: "10px", alignItems: "center", flexWrap: "wrap" }}>
            <input
              ref={fileRef}
              type="file"
              accept=".txt,.csv,text/plain,text/csv"
              hidden
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) readFile(file);
                event.target.value = "";
              }}
            />
            <button
              type="button"
              className="flow-btn flow-btn-secondary flow-btn-md"
              onClick={() => fileRef.current?.click()}
            >
              <span className="flow-btn-sweep" aria-hidden="true" />
              <span className="flow-btn-content">
                <UploadCloud size={14} aria-hidden="true" />
                <span className="flow-btn-label">Upload file</span>
              </span>
            </button>
            <span style={{ color: "var(--text-secondary)", fontSize: "13px" }}>
              {fileName || "No file selected"}
            </span>
          </div>
          <div className="form-group">
            <label htmlFor="import-users-keys">Keys</label>
            <textarea
              id="import-users-keys"
              className="fa-field-input fa-mono"
              rows={6}
              spellCheck={false}
              value={keysText}
              placeholder={"key_value,note,expires_at\njNU5thaUqsVt80in4JTSCezA,Flux migration,2026-12-31"}
              onChange={(event) => setKeysText(event.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="import-users-note">Default Note</label>
            <input
              id="import-users-note"
              className="fa-field-input"
              type="text"
              value={defaultNote}
              placeholder="e.g. Imported from Flux"
              maxLength={120}
              onChange={(event) => setDefaultNote(event.target.value)}
            />
          </div>
        </form>
        <div className="modal-footer">
          <button
            type="button"
            className="flow-btn flow-btn-secondary flow-btn-md"
            onClick={onClose}
            disabled={busy}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content"><span className="flow-btn-label">Cancel</span></span>
          </button>
          <button
            type="button"
            className="flow-btn flow-btn-primary flow-btn-md"
            onClick={confirm}
            disabled={confirmDisabled}
          >
            <span className="flow-btn-sweep" aria-hidden="true" />
            <span className="flow-btn-content">
              <span className="flow-btn-label">{busy ? "Importing…" : "Confirm"}</span>
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
