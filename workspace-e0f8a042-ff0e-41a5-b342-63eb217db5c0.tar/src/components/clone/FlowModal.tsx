"use client";

import { useEffect, useRef } from "react";

/**
 * Port of the original ui_lib Modal (compiled chunk 0uywnoa6t3qjm.js, module
 * 74776). DOM contract is identical so the ported `fa-modal-*` styles in
 * theme.css render untouched: blurred backdrop, dialog with topline accent,
 * head (eyebrow + title + icon close), body and foot. Escape closes, body
 * scroll is locked while rendered, initial focus lands inside the dialog.
 * Mount/unmount is controlled by the parent (same pattern as the other
 * ported modals), so the entry animation plays from the original CSS.
 */

export default function FlowModal({
  onClose,
  title,
  eyebrow,
  children,
  footer,
  size = "md",
  tone = "default",
  labelledBy,
}: {
  onClose: () => void;
  title?: string;
  eyebrow?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: "sm" | "md" | "lg";
  tone?: "default" | "danger";
  labelledBy?: string;
}) {
  const dialogRef = useRef<HTMLDivElement | null>(null);

  // Escape closes; body scroll locks while rendered (useEscape/useScrollLock).
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      event.stopPropagation();
      event.preventDefault();
      onClose();
    };
    window.addEventListener("keydown", onKey, true);
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey, true);
      document.body.style.overflow = previousOverflow;
    };
  }, [onClose]);

  // Initial focus inside the dialog (data-autofocus aware), restored on close.
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const raf = window.requestAnimationFrame(() => {
      if (dialog.contains(document.activeElement)) return;
      const target =
        dialog.querySelector<HTMLElement>("[data-autofocus]") ?? dialog;
      target.focus({ preventScroll: true });
    });
    return () => {
      window.cancelAnimationFrame(raf);
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    };
  }, []);

  // Basic Tab focus loop (parity with the original focus trap).
  const onKeyDown = (event: React.KeyboardEvent) => {
    if (event.key !== "Tab" || !dialogRef.current) return;
    const dialog = dialogRef.current;
    const focusables = Array.from(
      dialog.querySelectorAll<HTMLElement>(
        "a[href],button:not([disabled]),input:not([disabled]):not([type='hidden']),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex='-1'])",
      ),
    ).filter(
      (el) =>
        !el.closest("[aria-hidden='true'], [inert]") && el.getClientRects().length > 0,
    );
    if (!focusables.length) return;
    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };

  const dialogClasses = [
    "fa-modal",
    `fa-modal-${size}`,
    tone === "danger" ? "fa-modal-danger" : "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div
      className="fa-modal-backdrop"
      onPointerDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy ?? (title ? "fa-modal-title" : undefined)}
        aria-label={title ? undefined : eyebrow || "Dialog"}
        tabIndex={-1}
        className={dialogClasses}
        onKeyDown={onKeyDown}
      >
        <span className="fa-modal-topline" aria-hidden="true" />
        <header className="fa-modal-head">
          <div>
            {eyebrow ? <span className="fa-modal-eyebrow">{eyebrow}</span> : null}
            {title ? (
              <h3 id="fa-modal-title" className="fa-modal-title">
                {title}
              </h3>
            ) : null}
          </div>
          <button type="button" className="flow-icon-btn flow-icon-btn-sm" aria-label="Close dialog" onClick={onClose}>
            <span className="flow-icon-btn-inner">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
                <path d="M18 6 6 18M6 6l12 12" />
              </svg>
            </span>
          </button>
        </header>
        <div className="fa-modal-body">{children}</div>
        {footer ? <footer className="fa-modal-foot">{footer}</footer> : null}
      </div>
    </div>
  );
}
