"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import DashboardBody from "./DashboardBody.component";
import ProjectsBody from "./ProjectsBody.component";
import RewardsBody from "./RewardsBody.component";
import ObfuscatorBody from "./ObfuscatorBody.component";
import ApiBody from "./ApiBody.component";
import McpBody from "./McpBody.component";
import ChangelogBody from "./ChangelogBody.component";
import ProfileBody from "./ProfileBody.component";
import DocsBody from "./DocsBody.component";
import KeysBody, { type ToastFn } from "./KeysBody";
import DecompilerBody from "./DecompilerBody";
import { OBF_RUNS_CHANGED_EVENT, recordObfuscationRun, readObfuscationCount } from "./UsageGauges";
import CenturionRunOverlay from "./CenturionRunOverlay";
import CommandPalette from "./CommandPalette";
import PublishScriptModal from "./PublishScriptModal";
import NewProjectModal from "./NewProjectModal";
import AddProviderModal from "./AddProviderModal";
import AccountMenu from "./AccountMenu";
import InvitationsInbox from "./InvitationsInbox";
import CollaboratorsModal from "./CollaboratorsModal";
import RenameLoaderModal from "./RenameLoaderModal";
import ConfigureProjectModal from "./ConfigureProjectModal";
import ScriptHistoryModal from "./ScriptHistoryModal";
import { useFlowPopup } from "./FlowPopup";
import MobileDrawer, { buildDrawerNavItems } from "./MobileDrawer";
import { Toaster, useToasts } from "./Toaster";

export type WorkspaceView =
  | "dashboard"
  | "projects"
  | "rewards"
  | "obfuscator"
  | "api"
  | "mcp"
  | "changelog"
  | "profile"
  | "docs"
  | "keys"
  | "decompiler";

const NAV_MAP: Record<string, WorkspaceView> = {
  Dashboard: "dashboard",
  Projects: "projects",
  Rewards: "rewards",
  // "Discord" view omitted: its CSS module was not part of the extracted
  // archive (only a rendered screenshot exists), so the section stays
  // non-navigational like the original capture.
  Obfuscator: "obfuscator",
  Docs: "docs",
  API: "api",
  "MCP Server": "mcp",
  Changelog: "changelog",
  Profile: "profile",
  // Recovered from chunk 3k6a5lhrkscp5.js + reference screenshots
  // (user key 2.png / Decompiler.png) in round 7.
  "Users / Keys": "keys",
  Decompiler: "decompiler",
};

/** Sections whose pages were never captured in the source archive. */
const DISABLED_SECTIONS = ["Discord"];

/**
 * Persistent workspace state (localStorage). The ported SPA keeps its
 * interactive state in the DOM, so we mirror the mutable parts here to
 * survive a reload: regenerated API key, starred/disabled scripts, and the
 * reward-option steps created through the "Add provider option" modal.
 */
interface WorkspaceState {
  apiKey?: string;
  pinned: string[];
  disabled: string[];
  steps: { name: string; provider: string }[];
  loaderName?: string;
}

const WORKSPACE_KEY = "switzauth-workspace-v1";

function loadWorkspaceState(): WorkspaceState {
  if (typeof window === "undefined") return { pinned: [], disabled: [], steps: [] };
  try {
    const raw = window.localStorage.getItem(WORKSPACE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return {
      apiKey: typeof parsed?.apiKey === "string" ? parsed.apiKey : undefined,
      pinned: Array.isArray(parsed?.pinned) ? parsed.pinned : [],
      disabled: Array.isArray(parsed?.disabled) ? parsed.disabled : [],
      steps: Array.isArray(parsed?.steps) ? parsed.steps : [],
      loaderName: typeof parsed?.loaderName === "string" ? parsed.loaderName : undefined,
    };
  } catch {
    return { pinned: [], disabled: [], steps: [] };
  }
}

function mutateWorkspaceState(mutate: (state: WorkspaceState) => void) {
  if (typeof window === "undefined") return;
  const state = loadWorkspaceState();
  mutate(state);
  try {
    window.localStorage.setItem(WORKSPACE_KEY, JSON.stringify(state));
  } catch {
    /* storage unavailable */
  }
}

type StaticBodyView = Exclude<WorkspaceView, "keys" | "decompiler" | "rewards">;

const BODY_BY_VIEW: Record<StaticBodyView, () => React.JSX.Element> = {
  dashboard: DashboardBody,
  projects: ProjectsBody,
  obfuscator: ObfuscatorBody,
  api: ApiBody,
  mcp: McpBody,
  changelog: ChangelogBody,
  profile: ProfileBody,
  docs: DocsBody,
};

export default function WorkspaceView({
  view,
  onNavigate,
  onExitToLanding,
  onLogout,
}: {
  view: WorkspaceView;
  onNavigate: (view: WorkspaceView) => void;
  onExitToLanding: () => void;
  onLogout: () => void;
}) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  const [newProjectOpen, setNewProjectOpen] = useState(false);
  const [providerOpen, setProviderOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [inboxOpen, setInboxOpen] = useState(false);
  const [collabOpen, setCollabOpen] = useState(false);
  const [renameOpen, setRenameOpen] = useState(false);
  const [configOpen, setConfigOpen] = useState(false);
  const [historyScript, setHistoryScript] = useState<string | null>(null);
  const [obfMode, setObfMode] = useState<"upload" | "paste">("upload");
  const [obfSource, setObfSource] = useState("");
  const [obfFileName, setObfFileName] = useState("");
  const [obfBusy, setObfBusy] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [accountAnchor, setAccountAnchor] = useState<HTMLElement | null>(null);
  const { toasts, push, dismiss } = useToasts();
  const { popupNode, showNotice, askConfirm } = useFlowPopup();

  const Body = BODY_BY_VIEW[view as StaticBodyView];

  useEffect(() => {
    document.body.dataset.view = "app";
    return () => {
      delete document.body.dataset.view;
    };
  }, []);

  const openPalette = useCallback(() => setPaletteOpen(true), []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setPaletteOpen((open) => !open);
      }
      if (event.key === "Escape") {
        setPaletteOpen(false);
        setPublishOpen(false);
        setNewProjectOpen(false);
        setProviderOpen(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // "g"-chord section jumps (g d Dashboard, g p Projects, g k Keys, …) — an
  // additive power-user layer that mirrors the sidebar order. It is fully
  // invisible chrome: guarded against editable targets, open dialogs/popups
  // (any .ui-dialog-overlay), and modifier combos, and it times out after
  // 1200ms like standard chord implementations.
  const chordRef = useRef<{ timer: ReturnType<typeof setTimeout> | null }>({ timer: null });
  useEffect(() => {
    const CHORDS: Record<string, WorkspaceView> = {
      d: "dashboard",
      p: "projects",
      k: "keys",
      r: "rewards",
      o: "obfuscator",
      x: "decompiler",
      h: "docs",
      a: "api",
      m: "mcp",
      c: "changelog",
      f: "profile",
    };
    const isEditable = (el: EventTarget | null) => {
      if (!(el instanceof HTMLElement)) return false;
      return (
        el.isContentEditable ||
        el.tagName === "INPUT" ||
        el.tagName === "TEXTAREA" ||
        el.tagName === "SELECT"
      );
    };
    const clearChord = () => {
      if (chordRef.current.timer) {
        clearTimeout(chordRef.current.timer);
        chordRef.current.timer = null;
      }
    };
    const onChordKey = (event: KeyboardEvent) => {
      if (event.ctrlKey || event.metaKey || event.altKey) return;
      if (isEditable(event.target)) return;
      if (document.querySelector(".ui-dialog-overlay")) return; // palette/modal/popup open
      if (event.key === "g" || event.key === "G") {
        if (event.repeat) return;
        clearChord();
        chordRef.current.timer = setTimeout(clearChord, 1200);
        return;
      }
      if (!chordRef.current.timer) return;
      clearChord();
      const next = CHORDS[event.key.toLowerCase()];
      if (next) onNavigate(next);
    };
    window.addEventListener("keydown", onChordKey);
    return () => {
      window.removeEventListener("keydown", onChordKey);
      clearChord();
    };
  }, [onNavigate]);

  const copyTimers = useRef<ReturnType<typeof setTimeout>[]>([]);
  useEffect(
    () => () => {
      copyTimers.current.forEach(clearTimeout);
    },
    []
  );

  // Copy-to-clipboard for the ported "Copy …" buttons, with the site's own
  // toast feedback. Payload is resolved by proximity (the element shown in
  // the same card as the button), exactly like the original app did.
  const copyFromButton = useCallback(
    (button: HTMLElement): boolean => {
      const label =
        button.getAttribute("aria-label") || button.textContent || "";
      if (!/^copy/i.test(label.trim())) return false;

      let payload: string | null = null;
      // 1. Loader command shown in the projects header
      if (/loader/i.test(label)) {
        const codes = wrapRef.current
          ? Array.from(wrapRef.current.querySelectorAll<HTMLElement>("code"))
          : [];
        const code = codes.find((el) =>
          (el.textContent || "").includes("loadstring(game:HttpGet("));
        payload = code?.textContent?.trim() || null;
      }
      // 2. API key / project ID fields: scope strictly to the sibling
      //    .apiKeyField so the resolver never bleeds into a neighboring card
      //    (the API-key card holds a plain div, so the generic code/pre/input
      //    walk used to grab the project ID `2629` instead).
      if (payload === null && /(api key|project id)/i.test(label)) {
        const field = button.closest<HTMLElement>(".apiKeyField");
        const out = field?.querySelector<HTMLElement>(".keyOutput");
        const text = out?.textContent?.trim() || "";
        if (/hidden until reset/i.test(text)) {
          push(
            "warning",
            "No API key yet",
            "Use Regenerate API Key to create one, then copy it here.",
          );
          return true;
        }
        payload = text || null;
      }
      // 3. Generic: nearest code/pre/input/textarea within the same card/section
      if (payload === null) {
        let scope: HTMLElement | null = button;
        for (let hop = 0; hop < 6 && scope && payload === null; hop += 1) {
          scope = scope.parentElement;
          if (!scope) break;
          const candidates = Array.from(
            scope.querySelectorAll<HTMLElement>("code, pre, input, textarea")
          );
          for (const el of candidates) {
            const value =
              el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement
                ? el.value
                : el.textContent || "";
            const clean = value.trim();
            if (clean.length >= 3 && !/^copy/i.test(clean)) {
              payload = clean;
              break;
            }
          }
        }
      }
      if (!payload) return false;

      const write =
        typeof navigator !== "undefined" && navigator.clipboard
          ? navigator.clipboard.writeText(payload)
          : Promise.reject(new Error("clipboard unavailable"));
      write
        .then(() => {
          push("success", "Copied to clipboard", label.trim().replace(/^copy\s*/i, ""));
        })
        .catch(() => {
          push("error", "Copy failed", "Your browser blocked clipboard access.");
        });

      // Brief inline label flip for buttons with a visible text label
      const labelSpan =
        button.querySelector<HTMLElement>(".flow-btn-label, .mcp-workspace-module__HpTAFW__button span:last-child") ||
        (button.textContent && /^copy/i.test(button.textContent.trim()) ? button : null);
      if (labelSpan) {
        const original = labelSpan.textContent;
        if (original && /^copy/i.test(original.trim())) {
          labelSpan.textContent = "Copied";
          const t = setTimeout(() => {
            labelSpan.textContent = original;
          }, 1600);
          copyTimers.current.push(t);
        }
      }
      return true;
    },
    [push]
  );

  const OBFUSCATE_LIMIT = 2048 * 1024; // "2048.0 KB max" in the captured header

  /** Full-card Centurion show: portal host + run identity (remounts per run). */
  const [obfShow, setObfShow] = useState<{
    host: HTMLElement;
    fileName: string;
    bytes: number;
    lines: number;
    seed: string;
  } | null>(null);
  const [obfShowKey, setObfShowKey] = useState(0);
  const finishRunRef = useRef<() => void>(() => {});

  /** Reset the run UI without counting a run (mid-run abort, e.g. view swap). */
  const handleShowAbort = useCallback(() => {
    setObfShow(null);
    setObfBusy(false);
    const root = wrapRef.current;
    const button = Array.from(root?.querySelectorAll<HTMLButtonElement>("button") ?? []).find(
      (b) => b.textContent?.includes("Obfuscating"),
    );
    if (button) {
      button.removeAttribute("disabled");
      const label = button.querySelector<HTMLElement>(".flow-btn-label");
      if (label) label.textContent = "Obfuscate script";
    }
    push("info", "Protection run interrupted", "Stay on the Obfuscator to finish the run.");
  }, [push]);

  const handleShowFinish = useCallback(() => {
    setObfShow(null);
    finishRunRef.current();
  }, []);

  // Leaving a view (or any view swap) while a protection run is playing
  // deterministically tears the show down — the portal host (.editorCard)
  // unmounts with the Obfuscator body, and a detached host would leave the
  // overlay's timers running in a detached tree.
  const obfShowRef = useRef(false);
  useEffect(() => {
    obfShowRef.current = Boolean(obfShow);
  }, [obfShow]);
  useEffect(() => {
    if (!obfShowRef.current) return;
    // Deferred a tick so the view swap commits before the teardown lands.
    const t = setTimeout(() => {
      setObfShow(null);
      setObfBusy(false);
    }, 0);
    return () => clearTimeout(t);
  }, [view]);

  /**
   * Obfuscator pipeline — decompiled ground truth (chunk 3k6a5lhrkscp5.js):
   * validate → stage machine (parsing → obfuscating → finished) with the
   * output panel wearing the `matrixWorking` class → simulated payload. The
   * full-card show (GlyphMatrix field + beam-fed node network) lives in
   * CenturionRunOverlay, portaled into the output .editorCard.
   */
  const runObfuscate = useCallback(() => {
    const root = wrapRef.current;
    if (!root || obfBusy) return;
    const source = obfSource;
    if (!source.trim()) {
      push("warning", "Nothing to protect", "Paste or upload Lua source before obfuscating.");
      return;
    }
    if (new Blob([source]).size > OBFUSCATE_LIMIT) {
      push("warning", "Source is too large", "Limit is 2048.0 KB.");
      return;
    }
    setObfBusy(true);
    const button = Array.from(root.querySelectorAll<HTMLButtonElement>("button")).find(
      (b) => b.textContent?.includes("Obfuscate script"),
    );
    const labelEl = button?.querySelector<HTMLElement>(".flow-btn-label");
    if (button) button.setAttribute("disabled", "");
    if (labelEl) labelEl.textContent = "Obfuscating...";

    const outPanel = root.querySelector<HTMLElement>(".obfuscatorOutputPanel");
    const editorBody = outPanel?.querySelector<HTMLElement>(".editorBody") ?? null;
    const hostCard = outPanel?.querySelector<HTMLElement>(".editorCard") ?? null;
    const segments = outPanel?.querySelectorAll<HTMLElement>(".editorFooter .footerSegment strong");
    const bytes = new TextEncoder().encode(source).length;

    /** Shared finish: payload → output editor → stats/usage/toasts. */
    const finishRun = () => {
      // Deterministic stand-in for the Centurion payload: hex-packed source
      // behind a small loader stub (copyable, plausible, never executed).
      const enc = new TextEncoder().encode(source);
      const capped = enc.length > 8192 ? enc.slice(0, 8192) : enc;
      let hex = "";
      capped.forEach((b) => {
        hex += b.toString(16).padStart(2, "0");
      });
      const ellipsis = enc.length > 8192 ? " -- truncated for preview" : "";
      const output =
        "--[[ Protected by Centurion · generated by Switzauth ]]\n" +
        "--[[ Do not modify. Distribution must go through your Switzauth loader. ]]\n" +
        `local PAYLOAD = "${hex}"${ellipsis}\n` +
        "return loadstring(PAYLOAD:gsub(\"..\", function(cc) return string.char(tonumber(cc, 16)) end))()\n";

      if (editorBody) {
        const textarea = editorBody.querySelector<HTMLTextAreaElement>("textarea");
        if (textarea) textarea.value = output;
        const lines = editorBody.querySelector<HTMLElement>(".lineNumberGutter");
        if (lines) {
          const count = output.split("\n").length;
          lines.innerHTML = Array.from({ length: count }, (_, i) => `<div class="lineNumber">${i + 1}</div>`).join("");
        }
        // One-shot reveal so the payload settles in with motion.
        editorBody.classList.add("centurionReveal");
        setTimeout(() => editorBody.classList.remove("centurionReveal"), 700);
      }
      if (segments && segments.length >= 2) {
        segments[0].textContent = String(output.split("\n").length);
        segments[1].textContent = String(output.length);
      }
      outPanel
        ?.querySelectorAll<HTMLButtonElement>(".editorActionBtn")
        .forEach((b) => b.removeAttribute("disabled"));
      if (button) button.removeAttribute("disabled");
      if (labelEl) labelEl.textContent = "Obfuscate script";
      setObfBusy(false);
      // Count the run so the dashboard "Obfuscations" gauge reflects this
      // browser's usage on top of the captured plan baseline, and keep the
      // obfuscator header counter ("N / 1000 used this month") in step.
      const usageCount = recordObfuscationRun();
      const usageLine = Array.from(root.querySelectorAll<HTMLElement>("p.muted")).find((p) =>
        p.textContent?.includes("used this month"),
      );
      if (usageLine) {
        usageLine.textContent = usageLine.textContent?.replace(
          /\d+ \/ 1000 used this month/,
          `${usageCount} / 1000 used this month`,
        );
      }
      push("success", "Obfuscation finished successfully.", "Copy or download the protected output.");
    };
    finishRunRef.current = finishRun;

    if (!hostCard) {
      // Defensive fallback: no output card found — skip the show entirely.
      setTimeout(finishRun, 700);
      return;
    }

    setObfShow({
      host: hostCard,
      fileName: obfFileName,
      bytes,
      lines: source.split("\n").length,
      seed: source.slice(0, 512),
    });
    setObfShowKey((k) => k + 1);
  }, [obfBusy, obfSource, obfFileName, push]);

  // Event-delegation wiring over the ported static markup (1:1 DOM, no rewrite).
  useEffect(() => {
    const root = wrapRef.current;
    if (!root) return;

    const handler = (event: MouseEvent) => {
      const target = (event.target as HTMLElement | null)?.closest<HTMLElement>(
        "button, a, [role='button'], summary"
      );
      if (!target || !root.contains(target)) return;

      const ariaLabel = target.getAttribute("aria-label") || "";
      const classes = target.className || "";
      const text = (target.textContent || "").trim();

      // Sidebar / mobile navigation
      if (
        typeof classes === "string" &&
        classes.includes("sidebar-module__9SB1EG__link")
      ) {
        if (ariaLabel === "Log out") {
          event.preventDefault();
          onLogout();
          return;
        }
        if (ariaLabel === "Zed") {
          event.preventDefault();
          onNavigate("profile");
          return;
        }
        const mapped = NAV_MAP[ariaLabel];
        if (mapped) {
          event.preventDefault();
          onNavigate(mapped);
          return;
        }
      }

      // Brand -> landing
      if (ariaLabel === "Switzauth home" || classes.includes("enhanced-sidebar-module__5H-W0q__brand")) {
        event.preventDefault();
        onExitToLanding();
        return;
      }

      // Command palette trigger
      if (classes.includes("enhancedCommandTrigger")) {
        event.preventDefault();
        setPaletteOpen(true);
        return;
      }

      // Mobile menu button -> drawer
      if (classes.includes("sidebar-module__9SB1EG__mobileMenuButton")) {
        event.preventDefault();
        setDrawerOpen(true);
        return;
      }

      // Project invitations inbox (bell) -> dialog
      if (classes.includes("project-collaborators-module__FbxJEW__inboxTrigger")) {
        event.preventDefault();
        setInboxOpen(true);
        return;
      }

      // Account dropdown menu (chevron rotates via [data-state=open] CSS)
      if (classes.includes("account-menu-module__u2BZwG__trigger")) {
        event.preventDefault();
        setAccountAnchor(target);
        setAccountMenuOpen((open) => !open);
        return;
      }

      // Project collaborators dialog
      if (classes.includes("project-collaborators-module__FbxJEW__trigger")) {
        event.preventDefault();
        setCollabOpen(true);
        return;
      }

      // Script pin (star): the original CSS styles [aria-pressed=true] with a
      // filled yellow star, and the hint says starred scripts "stay at the top".
      if (classes.includes("script-list-module__tJ-lpW__pinButton")) {
        event.preventDefault();
        const pressed = target.getAttribute("aria-pressed") === "true";
        target.setAttribute("aria-pressed", pressed ? "false" : "true");
        const card = target.closest<HTMLElement>(".script-list-module__tJ-lpW__card");
        card?.setAttribute("data-pinned", pressed ? "false" : "true");
        const name =
          target.getAttribute("aria-label")?.replace(/^Star script\s*/i, "").trim() ||
          card?.querySelector<HTMLElement>(".script-list-module__tJ-lpW__name")?.textContent?.trim() ||
          "script";
        const grid = card?.parentElement;
        if (grid) {
          const addCard = grid.querySelector<HTMLElement>(
            ":scope > .script-list-module__tJ-lpW__addCard",
          );
          const cards = Array.from(
            grid.querySelectorAll<HTMLElement>(":scope > .script-list-module__tJ-lpW__card"),
          );
          cards
            .sort(
              (a, b) =>
                (a.getAttribute("data-pinned") === "true" ? 0 : 1) -
                (b.getAttribute("data-pinned") === "true" ? 0 : 1),
            )
            .forEach((c) => grid.insertBefore(c, addCard));
        }
        mutateWorkspaceState((state) => {
          state.pinned = pressed
            ? state.pinned.filter((n) => n !== name)
            : [...new Set([...state.pinned, name])];
        });
        push(
          pressed ? "info" : "success",
          pressed ? "Star removed" : "Script starred",
          pressed ? `${name} is back to its normal spot.` : `${name} stays at the top.`,
        );
        return;
      }

      // "Add a script" tile in the scripts grid -> publish modal
      if (classes.includes("script-list-module__tJ-lpW__addCard")) {
        event.preventDefault();
        setPublishOpen(true);
        return;
      }

      // Regenerate API key: mint a fresh key, reveal it once in the field
      // (the original app did the same — "Hidden until reset" until you regenerate)
      if (classes.includes("apiRegenBtn")) {
        event.preventDefault();
        const field = target.closest<HTMLElement>(".apiCard")?.querySelector<HTMLElement>(".apiKeyField");
        const out = field?.querySelector<HTMLElement>(".keyOutput");
        if (out) {
          const bytes = new Uint8Array(18);
          if (typeof crypto !== "undefined" && crypto.getRandomValues) {
            crypto.getRandomValues(bytes);
          }
          const key = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
          out.textContent = `swz_live_${key}`;
          mutateWorkspaceState((state) => {
            state.apiKey = out.textContent;
          });
          push(
            "success",
            "API key regenerated",
            "Copy it now — it will stay hidden until the next reset.",
          );
        }
        return;
      }

      // Copy buttons (clipboard + toast feedback)
      if (copyFromButton(target)) {
        event.preventDefault();
        return;
      }

      // Projects: rename the main loader URL (recovered loader-name dialog)
      if (view === "projects" && text === "Rename main loader") {
        event.preventDefault();
        setRenameOpen(true);
        return;
      }

      // Projects: "Configure" opens the project settings dialog (recovered
      // from chunk 3k6a5lhrkscp5.js + configuration 1/2/3.png).
      if (view === "projects" && text === "Configure") {
        event.preventDefault();
        setConfigOpen(true);
        return;
      }

      // Projects: script row "Version history" button opens the recovered
      // script-history dialog (script history.png).
      if (view === "projects" && /^Version history for /.test(ariaLabel)) {
        event.preventDefault();
        setHistoryScript(ariaLabel.replace(/^Version history for /, "").trim() || "Script");
        return;
      }

      // Obfuscator: download the protected output (decompiled sE/sA logic —
      // filename becomes "<source-name>.obfuscated.lua").
      if (view === "obfuscator" && text === "Download") {
        event.preventDefault();
        const out = root.querySelector<HTMLTextAreaElement>(".obfuscatorOutputPanel textarea");
        const value = out?.value ?? "";
        if (!value) return;
        const base = (obfFileName || "obfuscated.lua").split(/[\\/]/).pop() || "obfuscated.lua";
        const dot = base.lastIndexOf(".");
        const stem = (dot > 0 ? base.slice(0, dot) : base) || "obfuscated";
        const blob = new Blob([value], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement("a");
        anchor.href = url;
        anchor.download = `${stem}.obfuscated.lua`;
        anchor.click();
        URL.revokeObjectURL(url);
        push("success", "Download started", `${stem}.obfuscated.lua`);
        return;
      }

      // Projects: delete the whole project (decompiled confirm copy)
      if (ariaLabel === "Delete project") {
        event.preventDefault();
        void (async () => {
          const ok = await askConfirm(
            "Are you absolutely sure you want to delete this project? This will revoke all its keys and logs!",
            { title: "Delete project", confirmLabel: "Delete" },
          );
          if (!ok) return;
          const card = target.closest<HTMLElement>("[class*='__card']");
          card?.remove();
          push("warning", "Project deleted", "jh9iu and all of its keys and logs were revoked.");
        })();
        return;
      }

      // Projects: delete a protected script (decompiled confirm copy)
      if (ariaLabel === "Delete script") {
        event.preventDefault();
        void (async () => {
          const card = target.closest<HTMLElement>(".script-list-module__tJ-lpW__card");
          const name =
            card?.querySelector<HTMLElement>(".script-list-module__tJ-lpW__name")?.textContent?.trim() ||
            "script";
          const ok = await askConfirm("Are you sure you want to delete this script?", {
            title: "Delete script",
            confirmLabel: "Delete",
          });
          if (!ok) return;
          card?.remove();
          mutateWorkspaceState((state) => {
            state.pinned = state.pinned.filter((n) => n !== name);
            state.disabled = state.disabled.filter((n) => n !== name);
          });
          push("warning", "Script deleted", `${name} was removed from this project.`);
        })();
        return;
      }

      // Profile: rotate the developer credential key (decompiled flow)
      if (view === "profile" && text === "Rotate key") {
        event.preventDefault();
        void (async () => {
          const ok = await askConfirm(
            "Rotate this API key? The current key will stop working immediately.",
            { title: "Rotate API key", confirmLabel: "Rotate key" },
          );
          if (!ok) return;
          const button = target;
          const labelEl = button.querySelector<HTMLElement>(".flow-btn-label") ?? button;
          const original = "Rotate key";
          button.setAttribute("disabled", "");
          labelEl.textContent = "Rotating key";
          setTimeout(() => {
            const bytes = new Uint8Array(8);
            if (typeof crypto !== "undefined" && crypto.getRandomValues) {
              crypto.getRandomValues(bytes);
            }
            const key = `swz_live_${Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("")}`;
            const code = root.querySelector<HTMLElement>(
              ".profile-workspace-module___Z1n5q__credential code",
            );
            if (code) code.textContent = key;
            mutateWorkspaceState((state) => {
              state.apiKey = key;
            });
            button.removeAttribute("disabled");
            labelEl.textContent = original;
            // accountNotice (aria-live) feedback, cleared after 1.8s like the original.
            const notice = root.querySelector<HTMLElement>(
              ".profile-workspace-module___Z1n5q__accountNotice",
            );
            if (notice) {
              notice.textContent = "New key ready";
              setTimeout(() => {
                notice.textContent = "";
              }, 1800);
            }
          }, 500);
        })();
        return;
      }

      // Obfuscator: run the protection pipeline (loading state, then output)
      if (view === "obfuscator" && text === "Obfuscate script") {
        event.preventDefault();
        runObfuscate();
        return;
      }

      // Obfuscator: pick a file through the hidden input
      if (view === "obfuscator" && classes.includes("uploadDropzone")) {
        event.preventDefault();
        root.querySelector<HTMLInputElement>(".hiddenFileInput")?.click();
        return;
      }

      // Obfuscator: Upload / Paste segmented switch (fa-seg indicator)
      if (
        view === "obfuscator" &&
        typeof classes === "string" &&
        classes.includes("fa-seg-item") &&
        target.closest(".inputModeSegmented")
      ) {
        event.preventDefault();
        const group = target.closest<HTMLElement>(".fa-seg");
        if (!group) return;
        const items = Array.from(group.querySelectorAll<HTMLElement>(".fa-seg-item"));
        const index = items.indexOf(target);
        if (index < 0) return;
        items.forEach((item, i) => {
          item.classList.toggle("fa-seg-active", i === index);
          item.setAttribute("aria-checked", i === index ? "true" : "false");
          item.tabIndex = i === index ? 0 : -1;
        });
        group.style.setProperty("--fa-seg-index", String(index));
        setObfMode(index === 0 ? "upload" : "paste");
        return;
      }

      // Rewards: save the access duration for earned keys — decompiled `lf`:
      // silently clamps Math.max(1, Math.min(8760, Number(v) || 24)) (no
      // warning), rounds, PUTs reward_key_ttl_ms and only surfaces a danger
      // popup ("Reward save failed") when the save itself fails.
      if (view === "rewards" && text === "Save duration") {
        event.preventDefault();
        const input = root.querySelector<HTMLInputElement>(
          'input[aria-label="Access duration in hours"]',
        );
        const hours = Math.max(1, Math.min(8760, Math.round(Number(input?.value) || 24)));
        try {
          window.localStorage.setItem("switzauth-reward-ttl-v1", JSON.stringify({ hours }));
          push(
            "success",
            "Access duration saved",
            `Earned keys now last ${hours} hour${hours === 1 ? "" : "s"}.`,
          );
        } catch (err) {
          void showNotice(
            `Failed to save reward key duration: ${err instanceof Error ? err.message : "storage unavailable"}`,
            { title: "Reward save failed", tone: "danger" },
          );
        }
        return;
      }

      // Rewards: open the "Add provider option" modal
      if (
        view === "rewards" &&
        (text === "Add step" || text === "Add provider option")
      ) {
        event.preventDefault();
        setProviderOpen(true);
        return;
      }

      // Profile: change profile picture (file picker -> avatar preview)
      if (classes.includes("profile-workspace-module___Z1n5q__avatarEdit")) {
        event.preventDefault();
        const picker = document.createElement("input");
        picker.type = "file";
        picker.accept = "image/*";
        picker.onchange = () => {
          const file = picker.files?.[0];
          if (!file) return;
          const avatar = root.querySelector<HTMLElement>(
            ".fa-avatar.profile-workspace-module___Z1n5q__avatar .fa-avatar-fallback",
          );
          if (!avatar) return;
          avatar.style.backgroundImage = `url(${URL.createObjectURL(file)})`;
          avatar.style.backgroundSize = "cover";
          avatar.style.backgroundPosition = "center";
          avatar.textContent = "";
          push("success", "Profile picture updated", file.name);
        };
        picker.click();
        return;
      }

      // Projects page actions
      if (classes.includes("projects-workspace-module__7vQ_pa__headerButton")) {
        if (text === "Add script") {
          event.preventDefault();
          setPublishOpen(true);
          return;
        }
        if (text === "New project") {
          event.preventDefault();
          setNewProjectOpen(true);
          return;
        }
      }
      if (text === "Publish" && classes.includes("flow-btn-primary") && view === "projects") {
        event.preventDefault();
        setPublishOpen(true);
        return;
      }

      // Internal links: keep SPA behaviour (never hard-navigate)
      if (target.tagName === "A") {
        const href = target.getAttribute("href") || "";
        if (href.startsWith("/") && !href.startsWith("//")) {
          event.preventDefault();
          if (href === "/") onExitToLanding();
          else if (href === "/docs") onNavigate("docs");
          return;
        }
      }
    };

    root.addEventListener("click", handler);

    // flow-btn ripple — the original FlowButton spawns a `.flow-btn-ripple`
    // span on pointerdown (decompiled module 25404, chunk 0uywnoa6t3qjm.js);
    // the ported design-system CSS animates and auto-removes it.
    const rippleHandler = (event: PointerEvent) => {
      if (event.defaultPrevented) return;
      const button = (event.target as HTMLElement | null)?.closest<HTMLElement>(".flow-btn");
      if (!button || !root.contains(button) || button.hasAttribute("disabled")) return;
      const rect = button.getBoundingClientRect();
      const size = 0.65 * Math.max(rect.width, rect.height);
      const ripple = document.createElement("span");
      ripple.className = "flow-btn-ripple";
      ripple.style.width = `${size}px`;
      ripple.style.height = `${size}px`;
      ripple.style.left = `${event.clientX - rect.left - size / 2}px`;
      ripple.style.top = `${event.clientY - rect.top - size / 2}px`;
      button.appendChild(ripple);
      ripple.addEventListener("animationend", () => ripple.remove(), { once: true });
    };
    root.addEventListener("pointerdown", rippleHandler);

    // Info tooltip ("About authentication success rate"): the original used a
    // body portal shown on hover/focus; the ported `dashboardAuthRatePortal`
    // + [role=tooltip] styles handle the visuals.
    const tipText =
      "Authentication success across all projects in the last 24 hours. Successful authentications are divided by successful plus failed authentications. No attempts shows 0%.";
    const showTip = (btn: HTMLElement) => {
      let tip = document.getElementById("dashboard-auth-rate-help");
      if (!tip) {
        tip = document.createElement("span");
        tip.id = "dashboard-auth-rate-help";
        tip.setAttribute("role", "tooltip");
        tip.className = "dashboardAuthRatePortal";
        tip.textContent = tipText;
        document.body.appendChild(tip);
      }
      const r = btn.getBoundingClientRect();
      tip.style.left = `${Math.round(r.left + r.width / 2)}px`;
      tip.style.top = `${Math.round(r.bottom + 8)}px`;
      btn.setAttribute("aria-describedby", "dashboard-auth-rate-help");
    };
    const hideTip = (btn: HTMLElement) => {
      document.getElementById("dashboard-auth-rate-help")?.remove();
      btn.removeAttribute("aria-describedby");
    };
    const tipTarget = (node: EventTarget | null): HTMLElement | null => {
      const el = node as HTMLElement | null;
      return el?.closest?.(".dashboardAuthRateInfo") ?? null;
    };
    const overHandler = (event: Event) => {
      const btn = tipTarget(event.target);
      if (btn) showTip(btn);
    };
    const outHandler = (event: Event) => {
      const btn = tipTarget(event.target);
      const to = (event as MouseEvent).relatedTarget as Node | null;
      if (btn && (!to || !btn.contains(to))) hideTip(btn);
    };
    const focusInHandler = (event: Event) => {
      const btn = tipTarget(event.target);
      if (btn) showTip(btn);
    };
    const focusOutHandler = (event: Event) => {
      const btn = tipTarget(event.target);
      if (btn) hideTip(btn);
    };
    root.addEventListener("mouseover", overHandler);
    root.addEventListener("mouseout", outHandler);
    root.addEventListener("focusin", focusInHandler);
    root.addEventListener("focusout", focusOutHandler);

    // Script enable/disable switch: the original component applied the
    // `cardOff` modifier (veil overlay + dimmed name) when the toggle went
    // off; our port keeps that DOM contract in sync.
    const changeHandler = (event: Event) => {
      const input = event.target as HTMLInputElement | null;
      if (!input || !root.contains(input)) return;
      if (!input.classList.contains("toggle-module__BAu5xq__input")) return;
      // Profile dark mode: the original Appearance toggle (decompiled handler
      // sets dataset.theme + style.colorScheme + persisted storage).
      if (input.id === "profile-dark-mode") {
        const theme = input.checked ? "dark" : "light";
        document.documentElement.dataset.theme = theme;
        document.documentElement.style.colorScheme = theme;
        try {
          localStorage.setItem("switzauth-theme", theme);
        } catch {
          /* storage unavailable */
        }
        const desc = root.querySelector<HTMLElement>("[id='profile-dark-mode-description']");
        if (desc) desc.textContent = input.checked ? "Dark appearance is on" : "Light appearance is on";
        return;
      }
      const label = input.getAttribute("aria-label") || "";
      if (!/^disable script/i.test(label.trim())) return;
      const card = input.closest<HTMLElement>(".script-list-module__tJ-lpW__card");
      if (!card) return;
      const name =
        card.querySelector<HTMLElement>(".script-list-module__tJ-lpW__name")?.textContent?.trim() ||
        "script";
      const off = !input.checked;
      card.classList.toggle("script-list-module__tJ-lpW__cardOff", off);
      card.setAttribute("data-enabled", off ? "false" : "true");
      mutateWorkspaceState((state) => {
        state.disabled = off
          ? [...new Set([...state.disabled, name])]
          : state.disabled.filter((n) => n !== name);
      });
      push(
        off ? "warning" : "success",
        off ? "Script disabled" : "Script enabled",
        off
          ? `${name} no longer serves until it is re-enabled.`
          : `${name} is live again.`,
      );
    };
    root.addEventListener("change", changeHandler);

    // Profile "Redeem invitation" form: the decompiled flow writes the
    // formMessage line ("Enter an invitation key first." / "Invitation
    // redeemed.") and shows "Checking…" on the submit button while busy.
    const enableRedeem = (event: Event) => {
      const input = event.target as HTMLInputElement | null;
      if (!(input instanceof HTMLInputElement) || input.id !== "profile-invite-key") return;
      const button = input.parentElement?.querySelector<HTMLButtonElement>("button[type=submit]");
      if (!button) return;
      if (input.value.trim()) button.removeAttribute("disabled");
      else button.setAttribute("disabled", "");
    };
    const submitHandler = (event: Event) => {
      const form = event.target as HTMLFormElement | null;
      if (
        !(form instanceof HTMLFormElement) ||
        !form.classList.contains("profile-workspace-module___Z1n5q__inviteForm")
      )
        return;
      event.preventDefault();
      const input = form.querySelector<HTMLInputElement>("#profile-invite-key");
      const button = form.querySelector<HTMLButtonElement>("button[type=submit]");
      const message = form.querySelector<HTMLElement>("[class*='__formMessage']");
      const value = input?.value.trim() ?? "";
      if (!value) {
        if (message) message.textContent = "Enter an invitation key first.";
        return;
      }
      if (message) message.textContent = "";
      if (button) {
        button.setAttribute("disabled", "");
        button.textContent = "Checking…";
      }
      window.setTimeout(() => {
        if (button) {
          button.removeAttribute("disabled");
          button.textContent = "Redeem";
        }
        if (input) input.value = "";
        if (message) message.textContent = "Invitation redeemed.";
      }, 700);
    };
    root.addEventListener("input", enableRedeem);
    root.addEventListener("submit", submitHandler);

    return () => {
      root.removeEventListener("click", handler);
      root.removeEventListener("pointerdown", rippleHandler);
      root.removeEventListener("mouseover", overHandler);
      root.removeEventListener("mouseout", outHandler);
      root.removeEventListener("focusin", focusInHandler);
      root.removeEventListener("focusout", focusOutHandler);
      root.removeEventListener("change", changeHandler);
      root.removeEventListener("input", enableRedeem);
      root.removeEventListener("submit", submitHandler);
      document.getElementById("dashboard-auth-rate-help")?.remove();
    };
  }, [onNavigate, onExitToLanding, view, copyFromButton, askConfirm, showNotice, push, runObfuscate]);

  /** Append a provider step to the Rewards "Steps in this option" list. */
  const appendStepRow = useCallback(
    (root: HTMLElement, name: string, provider: string) => {
      // The original rendered the <ul> only once a step existed; our static
      // port ships the empty state, so create the list on first append.
      let stepsList = root.querySelector<HTMLElement>(
        ".rewards-workspace-module__dA4VLG__steps",
      );
      if (!stepsList) {
        const empty = root.querySelector<HTMLElement>(
          ".rewards-workspace-module__dA4VLG__emptySteps",
        );
        if (!empty?.parentElement) return;
        stepsList = document.createElement("ul");
        stepsList.className = "rewards-workspace-module__dA4VLG__steps";
        empty.parentElement.insertBefore(stepsList, empty);
      }
      const existing = stepsList.querySelectorAll(".rewards-workspace-module__dA4VLG__step").length;
      const li = document.createElement("li");
      li.className = "rewards-workspace-module__dA4VLG__step";
      li.innerHTML =
        '<div class="rewards-workspace-module__dA4VLG__stepMain">' +
        '<span class="rewards-workspace-module__dA4VLG__providerMark">' +
        '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 7v14" /><path d="M20 11v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8" /><path d="M7.5 7a1 1 0 0 1 0-5A4.8 8 0 0 1 12 7a4.8 8 0 0 1 4.5-5 1 1 0 0 1 0 5" /><rect x="3" y="7" width="18" height="4" rx="1" /></svg>' +
        '</span>' +
        '<span class="rewards-workspace-module__dA4VLG__stepIdentity">' +
        `<strong></strong><span></span>` +
        '</span>' +
        `<span class="rewards-workspace-module__dA4VLG__stepStatus">Connected</span>` +
        '</div>' +
        `<span class="rewards-workspace-module__dA4VLG__stepOrder">Step ${existing + 1}</span>`;
      const strong = li.querySelector("strong");
      const span = li.querySelector(".rewards-workspace-module__dA4VLG__stepIdentity span");
      if (strong) strong.textContent = name;
      if (span) span.textContent = provider;
      stepsList.appendChild(li);
      root.querySelector(".rewards-workspace-module__dA4VLG__emptySteps")?.remove();
      // The hint under the share box ("Add your first step…") only makes sense
      // while the option has no steps — the original removed it once a step
      // existed and the link became ready to share.
      root.querySelector(".rewards-workspace-module__dA4VLG__hint")?.remove();
      // The share link becomes ready once a step exists (the original kept
      // "Copy link" disabled until then).
      const copyBtn = Array.from(root.querySelectorAll<HTMLButtonElement>("button")).find(
        (b) => b.textContent?.includes("Copy link"),
      );
      copyBtn?.removeAttribute("disabled");
    },
    [],
  );

  const addRewardStep = useCallback(
    (name: string, provider: string) => {
      setProviderOpen(false);
      const root = wrapRef.current;
      if (!root) return;
      appendStepRow(root, name, provider);
      mutateWorkspaceState((state) => {
        state.steps = [...state.steps, { name, provider }];
      });
      push("success", "Step added", `${name} (${provider}) is part of this option.`);
    },
    [appendStepRow, push],
  );

  // Restore persisted workspace state when a view mounts (reload parity:
  // the API key, starred/disabled scripts and reward steps come back).
  useEffect(() => {
    const root = wrapRef.current;
    if (!root) return;
    const state = loadWorkspaceState();
    if (state.apiKey) {
      const out = root.querySelector<HTMLElement>(".apiCard .keyOutput");
      if (out && /hidden until reset/i.test(out.textContent || "")) {
        out.textContent = state.apiKey;
      }
      // Profile developer credential mirrors the same key.
      const cred = root.querySelector<HTMLElement>(
        ".profile-workspace-module___Z1n5q__credential code",
      );
      if (cred && /hidden until reset/i.test(cred.textContent || "")) {
        cred.textContent = state.apiKey;
      }
    }
    if (view === "projects" && state.loaderName) {
      root.querySelectorAll("code").forEach((code) => {
        const text = code.textContent || "";
        if (text.includes("/v1/loaders/")) {
          code.textContent = `loadstring(game:HttpGet("https://switzauth.net/v1/loaders/${state.loaderName}.lua"))()`;
        }
      });
    }
    if (state.pinned.length || state.disabled.length) {
      root
        .querySelectorAll<HTMLElement>(".script-list-module__tJ-lpW__card")
        .forEach((card) => {
          const name =
            card
              .querySelector<HTMLElement>(".script-list-module__tJ-lpW__name")
              ?.textContent?.trim() || "";
          if (state.pinned.includes(name)) {
            card.setAttribute("data-pinned", "true");
            card
              .querySelector<HTMLElement>(".script-list-module__tJ-lpW__pinButton")
              ?.setAttribute("aria-pressed", "true");
          }
          if (state.disabled.includes(name)) {
            card.classList.add("script-list-module__tJ-lpW__cardOff");
            card.setAttribute("data-enabled", "false");
            const input = card.querySelector<HTMLInputElement>(
              '.toggle-module__BAu5xq__input[aria-label^="Disable script"]',
            );
            if (input) input.checked = false;
          }
        });
      const grids = root.querySelectorAll<HTMLElement>(
        ".script-list-module__tJ-lpW__grid, .script-list-module__tJ-lpW__cards",
      );
      grids.forEach((grid) => {
        const addCard = grid.querySelector<HTMLElement>(
          ":scope > .script-list-module__tJ-lpW__addCard",
        );
        const cards = Array.from(
          grid.querySelectorAll<HTMLElement>(":scope > .script-list-module__tJ-lpW__card"),
        );
        cards
          .sort(
            (a, b) =>
              (a.getAttribute("data-pinned") === "true" ? 0 : 1) -
              (b.getAttribute("data-pinned") === "true" ? 0 : 1),
          )
          .forEach((c) => grid.insertBefore(c, addCard));
      });
    }
    if (view === "rewards" && state.steps.length) {
      state.steps.forEach((step) => appendStepRow(root, step.name, step.provider));
    }
  }, [view, appendStepRow]);

  // Keep the account trigger's data-state in sync with the dropdown (the CSS
  // rotates the chevron while [data-state=open]).
  useEffect(() => {
    const trigger = wrapRef.current?.querySelector<HTMLElement>(
      ".account-menu-module__u2BZwG__trigger",
    );
    if (!trigger) return;
    trigger.setAttribute("aria-expanded", accountMenuOpen ? "true" : "false");
    trigger.setAttribute("data-state", accountMenuOpen ? "open" : "closed");
  }, [accountMenuOpen, view]);

  // Obfuscator view wiring: mode swap (Upload ⇄ Paste), file input, drag&drop,
  // paste textarea input, and the enable state of the run button.
  useEffect(() => {
    if (view !== "obfuscator") return;
    const root = wrapRef.current;
    if (!root) return;

    // Restore the plan-usage counter from the store (static markup ships the
    // captured "4 / 1000"; the dashboard gauge and this line stay in step).
    const usageLine = Array.from(root.querySelectorAll<HTMLElement>("p.muted")).find((p) =>
      p.textContent?.includes("used this month"),
    );
    if (usageLine) {
      usageLine.textContent = usageLine.textContent?.replace(
        /\d+ \/ 1000 used this month/,
        `${readObfuscationCount()} / 1000 used this month`,
      );
    }

    const inputBody = root.querySelector<HTMLElement>(".divineInputBody");
    if (inputBody && !inputBody.dataset.wired) {
      inputBody.dataset.wired = "1";
      const dropzone = inputBody.querySelector<HTMLElement>(".uploadDropzone");
      const pasteArea = document.createElement("div");
      pasteArea.className = "editorBody";
      pasteArea.style.display = "none";
      pasteArea.innerHTML =
        '<textarea class="obfPasteArea" spellcheck="false" style="width:100%;min-height:180px;resize:vertical;background:transparent;border:0;outline:none;color:inherit;font:var(--fl-mono, 13px/1.6 var(--font-mono, monospace));padding:12px 14px;"></textarea>';
      dropzone?.parentElement?.insertBefore(pasteArea, dropzone.nextSibling);
    }

    const syncMode = () => {
      const dropzone = root.querySelector<HTMLElement>(".uploadDropzone");
      const pasteArea = root.querySelector<HTMLElement>(".obfPasteArea")?.parentElement;
      if (dropzone) dropzone.style.display = obfMode === "upload" ? "" : "none";
      if (pasteArea) pasteArea.style.display = obfMode === "paste" ? "" : "none";
    };
    syncMode();

    const fileInput = root.querySelector<HTMLInputElement>(".hiddenFileInput");
    const onFile = () => {
      const file = fileInput?.files?.[0];
      if (!file) return;
      if (file.size > OBFUSCATE_LIMIT) {
        push("warning", "File is too large", "Limit is 2048.0 KB.");
        if (fileInput) fileInput.value = "";
        return;
      }
      void file.text().then((text) => {
        setObfSource(text);
        setObfFileName(file.name || "source.lua");
        const strong = root.querySelector<HTMLElement>(".uploadDropzone strong");
        const sizeSpan = root.querySelector<HTMLElement>(".uploadDropzone span:last-child");
        if (strong) strong.textContent = file.name || "source.lua";
        if (sizeSpan) sizeSpan.textContent = `${(file.size / 1024).toFixed(1)} KB - ready to protect`;
        push("info", "Source loaded", `${file.name} is ready to obfuscate.`);
      });
      if (fileInput) fileInput.value = "";
    };
    fileInput?.addEventListener("change", onFile);

    const dropzone = root.querySelector<HTMLElement>(".uploadDropzone");
    const onDragOver = (event: DragEvent) => {
      event.preventDefault();
    };
    const onDrop = (event: DragEvent) => {
      event.preventDefault();
      const file = event.dataTransfer?.files?.[0];
      if (!file || !fileInput) return;
      const transfer = new DataTransfer();
      transfer.items.add(file);
      fileInput.files = transfer.files;
      fileInput.dispatchEvent(new Event("change"));
    };
    dropzone?.addEventListener("dragover", onDragOver);
    dropzone?.addEventListener("drop", onDrop);

    const pasteArea = root.querySelector<HTMLTextAreaElement>(".obfPasteArea");
    const onPasteInput = () => {
      setObfSource(pasteArea?.value ?? "");
      if (pasteArea && pasteArea.value.trim() && !obfFileName) setObfFileName("");
    };
    pasteArea?.addEventListener("input", onPasteInput);

    return () => {
      fileInput?.removeEventListener("change", onFile);
      dropzone?.removeEventListener("dragover", onDragOver);
      dropzone?.removeEventListener("drop", onDrop);
      pasteArea?.removeEventListener("input", onPasteInput);
    };
  }, [view, obfMode, obfFileName, push]);

  // Keep the obfuscator header counter live while the view is open — a run in
  // this tab dispatches `switzauth-obf-runs-changed`, a run in another tab
  // fires the native `storage` event (same dual-channel as the key metrics).
  useEffect(() => {
    if (view !== "obfuscator") return;
    const root = wrapRef.current;
    if (!root) return;
    const syncUsageLine = () => {
      const usageLine = Array.from(root.querySelectorAll<HTMLElement>("p.muted")).find((p) =>
        p.textContent?.includes("used this month"),
      );
      if (usageLine) {
        usageLine.textContent = usageLine.textContent?.replace(
          /\d+ \/ 1000 used this month/,
          `${readObfuscationCount()} / 1000 used this month`,
        );
      }
    };
    window.addEventListener(OBF_RUNS_CHANGED_EVENT, syncUsageLine);
    window.addEventListener("storage", syncUsageLine);
    return () => {
      window.removeEventListener(OBF_RUNS_CHANGED_EVENT, syncUsageLine);
      window.removeEventListener("storage", syncUsageLine);
    };
  }, [view]);

  // Enable the run button only when there is source to protect.
  useEffect(() => {
    if (view !== "obfuscator") return;
    const root = wrapRef.current;
    const button = Array.from(root?.querySelectorAll<HTMLButtonElement>("button") ?? []).find(
      (b) => b.textContent?.includes("Obfuscate script"),
    );
    if (!button || obfBusy) return;
    if (obfSource.trim()) button.removeAttribute("disabled");
    else button.setAttribute("disabled", "");
  }, [view, obfSource, obfBusy]);

  // Profile Appearance toggle mirrors the active theme on mount (the original
  // toggle is checked whenever the dark stylesheet is active).
  useEffect(() => {
    if (view !== "profile") return;
    const root = wrapRef.current;
    const input = root?.querySelector<HTMLInputElement>("#profile-dark-mode");
    if (!input) return;
    const dark = document.documentElement.dataset.theme === "dark";
    input.checked = dark;
    const desc = root?.querySelector<HTMLElement>("[id='profile-dark-mode-description']");
    if (desc) desc.textContent = dark ? "Dark appearance is on" : "Light appearance is on";
  }, [view]);

  /** Apply a loader rename: swap the loader-command code. An empty name maps
   * to the original `loader_name: null` submit — a fresh 32-hex hash is
   * minted ("Use generated name"). */
  const applyLoaderRename = useCallback(
    (name: string) => {
      setRenameOpen(false);
      const root = wrapRef.current;
      if (!root) return;
      let loader = name;
      if (!loader) {
        const bytes = new Uint8Array(16);
        if (typeof crypto !== "undefined" && crypto.getRandomValues) {
          crypto.getRandomValues(bytes);
        }
        loader = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
      }
      root.querySelectorAll("code").forEach((code) => {
        const text = code.textContent || "";
        if (text.includes("/v1/loaders/")) {
          code.textContent = `loadstring(game:HttpGet("https://switzauth.net/v1/loaders/${loader}.lua"))()`;
        }
      });
      mutateWorkspaceState((state) => {
        state.loaderName = loader;
      });
      push(
        "success",
        "Loader URL renamed",
        name
          ? `Loaders now serve from /v1/loaders/${loader}.lua`
          : `A fresh loader hash was generated: /v1/loaders/${loader}.lua`,
      );
    },
    [push],
  );

  const drawerItems = buildDrawerNavItems(NAV_MAP, DISABLED_SECTIONS);

  return (
    <div ref={wrapRef}>
      {view === "keys" ? (
        <KeysBody key={view} onToast={push as ToastFn} />
      ) : view === "decompiler" ? (
        <DecompilerBody key={view} />
      ) : view === "rewards" ? (
        <RewardsBody key={view} onToast={push as ToastFn} onNotice={showNotice} />
      ) : (
        <Body key={view} />
      )}
      {drawerOpen ? (
        <MobileDrawer
          open
          sectionLabel={view}
          activeView={view}
          items={drawerItems}
          onClose={() => setDrawerOpen(false)}
          onNavigate={onNavigate}
          onLogout={onLogout}
        />
      ) : null}
      {paletteOpen ? (
        <CommandPalette
          onClose={() => setPaletteOpen(false)}
          onNavigate={onNavigate}
          activeView={view}
        />
      ) : null}
      {publishOpen ? <PublishScriptModal onClose={() => setPublishOpen(false)} /> : null}
      {newProjectOpen ? <NewProjectModal onClose={() => setNewProjectOpen(false)} /> : null}
      {providerOpen ? <AddProviderModal onClose={() => setProviderOpen(false)} onCreate={addRewardStep} /> : null}
      {inboxOpen ? <InvitationsInbox onClose={() => setInboxOpen(false)} /> : null}
      {collabOpen ? <CollaboratorsModal onClose={() => setCollabOpen(false)} /> : null}
      {renameOpen ? <RenameLoaderModal onClose={() => setRenameOpen(false)} onSave={applyLoaderRename} /> : null}
      {configOpen ? <ConfigureProjectModal onClose={() => setConfigOpen(false)} onToast={push as ToastFn} /> : null}
      {historyScript ? <ScriptHistoryModal scriptName={historyScript} onClose={() => setHistoryScript(null)} /> : null}
      {popupNode}
      {accountMenuOpen && accountAnchor ? (
        <AccountMenu
          anchor={accountAnchor}
          onClose={() => setAccountMenuOpen(false)}
          onNavigate={(next) => {
            setAccountMenuOpen(false);
            onNavigate(next);
          }}
          onLogout={() => {
            setAccountMenuOpen(false);
            onLogout();
          }}
        />
      ) : null}
      <Toaster toasts={toasts} onDismiss={dismiss} />
      {obfShow
        ? createPortal(
            <CenturionRunOverlay
              key={obfShowKey}
              fileName={obfShow.fileName}
              bytes={obfShow.bytes}
              lines={obfShow.lines}
              seed={obfShow.seed}
              onFinish={handleShowFinish}
              onAbort={handleShowAbort}
            />,
            obfShow.host,
          )
        : null}
    </div>
  );
}
