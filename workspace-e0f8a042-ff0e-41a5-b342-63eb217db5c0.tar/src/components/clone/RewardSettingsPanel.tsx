"use client";

import { useEffect, useRef, useState } from "react";
import FaToggle from "./FaToggle";
import type { ToastFn } from "./KeysBody";

/**
 * "Appearance & access rules" panel — direct port of the decompiled
 * RewardSettings component (function R) in compiled chunk 2bl02kavwsyc3.js,
 * lazily mounted inside the Rewards `<details class=…__settings>` body on
 * first open (the original `Z && <div class=…__settingsBody>` contract).
 *
 * Branding preview, brand label, logo/background asset rows (with the full
 * decompiled image-processing pipeline: type sniffing, GIF header check,
 * dimension guard, canvas upscale-to-4x and WebP quality ladder), accent
 * color, background shade slider, the three numeric rules, the three toggle
 * rules, country blocks, and the save action. Every string is the decompiled
 * copy with only the brand word swapped (FlowAuth → Switzauth).
 *
 * State contract from the chunk: defaults P, clamped numeric setter E, the
 * upload handler V with Preparing/Uploading/progress feedback, the remove
 * handler H, and the country commit O. Uploads resolve locally (single-tenant
 * clone — the processed dataUrl is the "published" asset), and settings
 * persist to localStorage under "switzauth-reward-settings-v1".
 */

export interface RewardSettingsValue {
  maxKeys: number;
  allowExtending: boolean;
  cooldownHours: number;
  allowForgetting: boolean;
  maxHours: number;
  blockIncognito: boolean;
  blockVpns: boolean;
  autoBlacklist: boolean;
  blockedCountries: string[];
  brandName: string;
  brandIconUrl: string;
  backgroundImageUrl: string;
  accentColor: string;
  backgroundDim: number;
}

/** Decompiled defaults P (brand label brand-swapped). */
const DEFAULTS: RewardSettingsValue = {
  maxKeys: 1,
  allowExtending: false,
  cooldownHours: 0,
  allowForgetting: false,
  maxHours: 0,
  blockIncognito: false,
  blockVpns: false,
  autoBlacklist: false,
  blockedCountries: [],
  brandName: "Switzauth Rewards",
  brandIconUrl: "",
  backgroundImageUrl: "",
  accentColor: "",
  backgroundDim: 58,
};

const STORAGE_KEY = "switzauth-reward-settings-v1";

function loadSettings(): RewardSettingsValue {
  if (typeof window === "undefined") return DEFAULTS;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULTS, ...JSON.parse(raw) } : DEFAULTS;
  } catch {
    return DEFAULTS;
  }
}

/** Decompiled E — empty stays empty, otherwise clamp into [min,max]. */
function clamp(value: string | number, min: number, max: number): number | string {
  if (value === "") return "";
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return min;
  return Math.max(min, Math.min(max, parsed));
}

/** Decompiled B — file to data URL. */
function readAsDataUrl(file: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(Error("Could not read this image."));
    reader.onload = () => resolve(String(reader.result || ""));
    reader.readAsDataURL(file);
  });
}

/** Decompiled G — supported dimension guard (1..8192 per side, ≤36MP). */
function dimensionsOk(width: number, height: number): boolean {
  return (
    Number.isSafeInteger(width) &&
    Number.isSafeInteger(height) &&
    width >= 1 &&
    height >= 1 &&
    width <= 8192 &&
    height <= 8192 &&
    width * height <= 36e6
  );
}

/** Decompiled M — byte size label. */
function megaBytes(size: number): string {
  const value = Number(size || 0) / 1e6;
  return `${value >= 10 ? value.toFixed(1) : value.toFixed(2)} MB`;
}

/** Decompiled T — the canvas resize fallback (the WASM fast path is skipped;
 * the fallback output is visually identical). */
async function drawResized(img: HTMLImageElement, canvas: HTMLCanvasElement): Promise<void> {
  const ctx = canvas.getContext("2d");
  if (!ctx) throw Error("This browser cannot optimize images.");
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
}

/** Decompiled F — the full asset pipeline. Limits: icon 1.9 MB / background
 * 7.75 MB static, 8 MB / 16 MB GIF; targets icon 1024², background 4K. */
async function processAsset(
  file: File,
  kind: "icon" | "background",
): Promise<{
  dataUrl: string;
  width: number;
  height: number;
  sourceWidth: number;
  sourceHeight: number;
  animated: boolean;
  upscaled: boolean;
}> {
  const byExtension = ({ gif: "image/gif", jpeg: "image/jpeg", jpg: "image/jpeg", png: "image/png", webp: "image/webp" } as Record<string, string>)[
    String(file?.name || "").split(".").pop()?.toLowerCase() || ""
  ];
  const mime = String(file?.type || "").toLowerCase();
  const type = ["image/gif", "image/jpeg", "image/png", "image/webp"].includes(mime) ? mime : byExtension || "";
  if (!type) throw Error("Choose a GIF, PNG, JPG, or WebP image.");

  const normalized = file.type === type ? file : file.slice(0, file.size, type);

  // GIF branch — animation preserved, header + dimension checks.
  if (type === "image/gif") {
    const gifLimit = kind === "icon" ? 8e6 : 16e6;
    if (normalized.size > gifLimit) {
      throw Error(`${kind === "icon" ? "Logo" : "Background"} GIF is ${megaBytes(normalized.size)}. The limit is ${megaBytes(gifLimit)}.`);
    }
    const header = parseGifSize(new Uint8Array(await normalized.slice(0, 10).arrayBuffer()));
    if (!header || !dimensionsOk(header.width, header.height)) {
      throw Error("This GIF has an invalid header or unsupported dimensions.");
    }
    return {
      dataUrl: await readAsDataUrl(normalized),
      width: header.width,
      height: header.height,
      sourceWidth: header.width,
      sourceHeight: header.height,
      animated: true,
      upscaled: false,
    };
  }

  // Static branch — size limits from the decompiled L map.
  const sizeLimit = kind === "icon" ? 1.9e6 : 7.75e6;
  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const url = URL.createObjectURL(normalized);
    const image = new Image();
    image.onload = () => {
      URL.revokeObjectURL(url);
      resolve(image);
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(Error("This image could not be opened."));
    };
    image.src = url;
  });
  if (!dimensionsOk(img.naturalWidth, img.naturalHeight)) {
    throw Error("This image has unsupported dimensions.");
  }

  // Decompiled upscale planner: fit into the kind's target, scale up to 4x.
  const target = kind === "icon" ? { width: 1024, height: 1024 } : { width: 3840, height: 2160 };
  const fit = Math.min(target.width / img.naturalWidth, target.height / img.naturalHeight);
  const scale = fit < 1 ? fit : Math.min(fit, 4);
  const width = Math.max(1, Math.min(target.width, Math.round(img.naturalWidth * scale)));
  const height = Math.max(1, Math.min(target.height, Math.round(img.naturalHeight * scale)));
  const plan = {
    width,
    height,
    scale,
    upscaled: width > img.naturalWidth || height > img.naturalHeight,
    resized: width !== img.naturalWidth || height !== img.naturalHeight,
  };

  if (file.size <= sizeLimit && !plan.resized && img.naturalWidth <= 8192 && img.naturalHeight <= 8192) {
    return {
      dataUrl: await readAsDataUrl(normalized),
      width: img.naturalWidth,
      height: img.naturalHeight,
      sourceWidth: img.naturalWidth,
      sourceHeight: img.naturalHeight,
      animated: false,
      upscaled: false,
    };
  }

  const canvas = document.createElement("canvas");
  canvas.width = plan.width;
  canvas.height = plan.height;
  await drawResized(img, canvas);

  // Decompiled WebP quality ladder.
  let blob: Blob | null = null;
  for (const quality of [0.94, 0.9, 0.84, 0.76, 0.68]) {
    blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/webp", quality));
    if (blob && blob.size <= sizeLimit) break;
  }
  if (!blob || blob.size > sizeLimit) {
    throw Error("The image is still too large after optimization.");
  }
  return {
    dataUrl: await readAsDataUrl(blob),
    width: plan.width,
    height: plan.height,
    sourceWidth: img.naturalWidth,
    sourceHeight: img.naturalHeight,
    animated: false,
    upscaled: plan.upscaled,
  };
}

/** Decompiled GIF header probe (GIF87a/GIF89a → little-endian size). */
function parseGifSize(bytes: Uint8Array): { width: number; height: number } | null {
  if (bytes.length < 10) return null;
  const signature = String.fromCharCode(...bytes.subarray(0, 6));
  if (signature !== "GIF87a" && signature !== "GIF89a") return null;
  const width = bytes[6] | (bytes[7] << 8);
  const height = bytes[8] | (bytes[9] << 8);
  if (width < 1 || height < 1) return null;
  return { width, height };
}

type Feedback = { kind: string; message: string; tone: "info" | "success" | "error" };
type Busy = "" | "icon" | "background";

/** Decompiled W — numeric rule rows. */
const NUMERIC_RULES = [
  { key: "maxKeys", title: "Max keys", help: "Keys one visitor can hold at once.", min: 1, max: 50, step: 1 },
  { key: "cooldownHours", title: "Cooldown", help: "Hours before the same visitor can earn again.", min: 0, max: 168, step: 0.05 },
  { key: "maxHours", title: "Max key time", help: "Extension cap in hours. 0 means no cap.", min: 0, max: 8760, step: 1 },
] as const;

/** Decompiled toggle rows (allowExtending / autoBlacklist / allowForgetting). */
const TOGGLE_RULES = [
  { key: "allowExtending", title: "Allow extensions", help: "Repeat the reward to add time to the current key.", warn: false },
  { key: "autoBlacklist", title: "Block bypass attempts", help: "Temporarily block obvious bypass attempts for 24 hours.", warn: false },
  { key: "allowForgetting", title: "Allow reset", help: "Let users reset their browser binding and start over.", warn: true },
] as const;

const PROJECT_NAME = "jh9iu";

export default function RewardSettingsPanel({
  onToast,
  onNotice,
}: {
  onToast?: ToastFn;
  onNotice?: (message: string, options?: { title?: string; tone?: "default" | "danger" | "success" | "warning"; confirmLabel?: string }) => Promise<boolean>;
}) {
  // Lazy initializer mirrors the decompiled `useState({...P, ...(value||{})})`
  // + parent value load (hydration-safe: the panel mounts client-side only).
  const [settings, setSettings] = useState<RewardSettingsValue>(() => loadSettings());
  const [countryDraft, setCountryDraft] = useState("");
  const [feedback, setFeedback] = useState<Feedback>({ kind: "", message: "", tone: "info" });
  const [busy, setBusy] = useState<Busy>("");
  const [bgFailed, setBgFailed] = useState(false);
  const [saving, setSaving] = useState(false);
  const iconInputRef = useRef<HTMLInputElement | null>(null);
  const backgroundInputRef = useRef<HTMLInputElement | null>(null);

  // Decompiled: reset the background error flag whenever the URL changes.
  useEffect(() => {
    setBgFailed(false);
  }, [settings.backgroundImageUrl]);

  const set = <K extends keyof RewardSettingsValue>(key: K, value: RewardSettingsValue[K]) => {
    setSettings((current) => ({ ...current, [key]: value }));
  };

  /** Decompiled O — commit the country draft (split, uppercase, dedupe, cap 250). */
  const commitCountries = () => {
    const codes = countryDraft
      .split(/[\s,]+/)
      .map((code) => code.trim().toUpperCase())
      .filter((code) => /^[A-Z]{2}$/.test(code));
    if (codes.length) {
      set("blockedCountries", [...new Set([...(settings.blockedCountries || []), ...codes])].slice(0, 250));
    }
    setCountryDraft("");
  };

  /** Decompiled V — process + "upload" an asset, then point the field at it. */
  const uploadAsset = async (kind: Exclude<Busy, "">, file?: File | null) => {
    if (!file) return;
    setBusy(kind);
    setFeedback({ kind, message: `Preparing ${String(file.name || "image").slice(0, 80)}…`, tone: "info" });
    try {
      const processed = await processAsset(file, kind);
      setFeedback({ kind, message: `Uploading ${kind === "icon" ? "logo" : "background"}…`, tone: "info" });
      // Single-tenant clone: the processed dataUrl is the published asset
      // (the original stored it server-side and returned a CDN URL).
      const url = processed.dataUrl;
      set(kind === "icon" ? "brandIconUrl" : "backgroundImageUrl", url);
      const label = kind === "icon" ? "Logo" : "Background";
      if (processed.animated) {
        setFeedback({ kind, message: `${label} uploaded with animation preserved. Save the settings to publish it.`, tone: "success" });
      } else if (processed.upscaled) {
        setFeedback({ kind, message: `${label} upscaled from ${processed.sourceWidth}×${processed.sourceHeight} to ${processed.width}×${processed.height}. Save the settings to publish it.`, tone: "success" });
      } else {
        setFeedback({ kind, message: `${label} uploaded at ${processed.width}×${processed.height}. Save the settings to publish it.`, tone: "success" });
      }
    } catch (error) {
      setFeedback({ kind, message: error instanceof Error ? error.message : "Image upload failed.", tone: "error" });
    } finally {
      setBusy("");
    }
  };

  const onFilePicked = (kind: Exclude<Busy, "">, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0] ?? null;
    event.currentTarget.value = "";
    void uploadAsset(kind, file);
  };

  /** Decompiled K — reset + open the hidden file input. */
  const openPicker = (ref: React.RefObject<HTMLInputElement | null>) => {
    if (!ref.current) return;
    ref.current.value = "";
    ref.current.click();
  };

  /** Decompiled H — clear an asset and show the reset feedback. */
  const removeAsset = async (kind: Exclude<Busy, "">) => {
    const key = kind === "icon" ? "brandIconUrl" : "backgroundImageUrl";
    setBusy(kind);
    setFeedback({ kind, message: "", tone: "info" });
    try {
      // The original also deleted a stored server asset when the URL pointed
      // at /rewards/public/branding/{kind}; dataUrls never match, so only the
      // field reset runs (identical visible behaviour in the clone).
      set(kind === "icon" ? "brandIconUrl" : "backgroundImageUrl", "");
      setFeedback({ kind, message: `${kind === "icon" ? "Logo" : "Background"} reset to the Switzauth default. Save to publish it.`, tone: "success" });
    } catch (error) {
      setFeedback({ kind, message: error instanceof Error ? error.message : "Could not remove this image.", tone: "error" });
    } finally {
      setBusy("");
    }
  };

  /** Save — the decompiled parent PUT the settings then refreshed (`lv`); the
   * clone persists locally (quota guard drops dataUrl assets first). Any
   * persistence failure — total or the quota-guard partial save — raises the
   * decompiled danger FlowPopup "Failed to save reward settings: …" with
   * title "Reward save failed", so the success toast only ever fires when
   * every rule (and asset) actually stuck. */
  const save = () => {
    if (saving) return;
    setSaving(true);
    setTimeout(() => {
      let saved = true;
      let failureMessage = "Local storage is unavailable in this browser.";
      try {
        try {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
        } catch (quotaError) {
          // Quota exceeded — retry without the heavy dataUrl assets. The
          // rules survive, the branding images did not persist: surfaced
          // through the same popup path the decompiled `lv` used for a
          // failed save (its exact copy format, with the real error).
          const light = {
            ...settings,
            brandIconUrl: settings.brandIconUrl.startsWith("data:") ? "" : settings.brandIconUrl,
            backgroundImageUrl: settings.backgroundImageUrl.startsWith("data:") ? "" : settings.backgroundImageUrl,
          };
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(light));
          saved = false;
          failureMessage = `Failed to save reward settings: ${
            quotaError instanceof Error ? quotaError.message : "local storage quota was exceeded"
          } (the branding images were dropped to fit the quota — the rules were saved).`;
        }
      } catch (error) {
        saved = false;
        failureMessage = `Failed to save reward settings: ${error instanceof Error ? error.message : "storage unavailable"}`;
      }
      setSaving(false);
      if (!saved) {
        // Decompiled `lv` catch — danger popup, title "Reward save failed".
        void onNotice?.(failureMessage, { title: "Reward save failed", tone: "danger" });
        return;
      }
      onToast?.("success", "Reward settings saved", `${PROJECT_NAME} now uses the updated branding and visitor rules.`);
    }, 500);
  };

  const hasIcon = Boolean(settings.brandIconUrl);
  const hasBackground = Boolean(settings.backgroundImageUrl);
  const dim = Math.round(Number(settings.backgroundDim ?? 58));

  return (
    <div className="rewardSettingsPanel">
      <section className="rewardBrandingSection">
        <div className="rewardSettingsHead rewardBrandingHead">
          <div>
            <h3>Gateway appearance</h3>
            <p>Replace the Switzauth presentation with this project’s own identity.</p>
          </div>
          <span className="rewardBrandingStatus">Public gateway</span>
        </div>
        <div
          className="rewardBrandingPreview"
          style={
            {
              "--reward-brand-accent": settings.accentColor || "#7c5cff",
              "--reward-brand-dim": `${dim / 100}`,
            } as React.CSSProperties
          }
        >
          {settings.backgroundImageUrl && !bgFailed ? (
            <img
              className="rewardBrandingPreviewBackground"
              src={settings.backgroundImageUrl}
              alt=""
              onError={() => setBgFailed(true)}
            />
          ) : (
            <div className="rewardBrandingPreviewFallback" />
          )}
          <div className="rewardBrandingPreviewShade" />
          <div className="rewardBrandingPreviewContent">
            <div className="rewardBrandingPreviewIdentity">
              <span className="rewardBrandingPreviewMark">
                <img src={settings.brandIconUrl || "/brand/flowauth-logo.png?v=20260821"} alt="" />
              </span>
              <span>
                <small>{settings.brandName || "Switzauth Rewards"}</small>
                <strong>{PROJECT_NAME || "Your project"}</strong>
              </span>
            </div>
            <div className="rewardBrandingPreviewProgress">
              <span />
              <span />
              <span />
            </div>
          </div>
        </div>
        <div className="rewardBrandingControls">
          <label className="rewardBrandingField rewardBrandingFieldWide">
            <span>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z" />
                <circle cx="13.5" cy="6.5" r=".5" fill="currentColor" />
                <circle cx="17.5" cy="10.5" r=".5" fill="currentColor" />
                <circle cx="6.5" cy="12.5" r=".5" fill="currentColor" />
                <circle cx="8.5" cy="7.5" r=".5" fill="currentColor" />
              </svg>
              <strong>Brand label</strong>
            </span>
            <span className="fa-field fa-field-unlabeled">
              <span className="fa-field-frame">
                <input
                  className="fa-field-input"
                  value={settings.brandName}
                  maxLength={48}
                  placeholder="Switzauth Rewards"
                  onChange={(event) => set("brandName", event.target.value)}
                />
                <span className="fa-field-charge" aria-hidden="true" />
              </span>
            </span>
          </label>

          <div className="rewardBrandingField">
            <span>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                <circle cx="9" cy="9" r="2" />
                <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
              </svg>
              <strong>Main logo</strong>
            </span>
            <span className="fa-field fa-field-unlabeled">
              <span className="fa-field-frame">
                <input
                  className="fa-field-input"
                  value={settings.brandIconUrl}
                  placeholder="https://…/logo.png"
                  onChange={(event) => set("brandIconUrl", event.target.value)}
                />
                <span className="fa-field-charge" aria-hidden="true" />
              </span>
            </span>
            <div className="rewardBrandingAssetActions">
              <input
                ref={iconInputRef}
                type="file"
                accept="image/gif,image/jpeg,image/png,image/webp"
                onChange={(event) => onFilePicked("icon", event)}
              />
              <button
                type="button"
                className={`flow-btn flow-btn-secondary flow-btn-md${busy === "icon" ? " flow-btn-loading" : ""}`}
                onClick={() => openPicker(iconInputRef)}
                disabled={busy !== ""}
              >
                <span className="flow-btn-sweep" aria-hidden="true" />
                <span className="flow-btn-content">
                  {busy === "icon" ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flow-btn-spinner" aria-hidden="true">
                      <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                    </svg>
                  ) : (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21" />
                      <path d="m14 19.5 3-3 3 3" />
                      <path d="M17 22v-5.5" />
                      <circle cx="9" cy="9" r="2" />
                    </svg>
                  )}
                  <span className="flow-btn-label">Upload logo</span>
                </span>
              </button>
              {hasIcon ? (
                <button
                  type="button"
                  className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm"
                  onClick={() => void removeAsset("icon")}
                  disabled={busy !== ""}
                  aria-label="Use the default Switzauth logo"
                  title="Use default logo"
                >
                  <span className="flow-icon-btn-inner">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M10 11v6" />
                      <path d="M14 11v6" />
                      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                      <path d="M3 6h18" />
                      <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                    </svg>
                  </span>
                </button>
              ) : null}
            </div>
            {feedback.kind === "icon" && feedback.message ? (
              <p
                className={`reward-settings-module__po3UEW__assetFeedback reward-settings-module__po3UEW__${feedback.tone}`}
                role={feedback.tone === "error" ? "alert" : "status"}
              >
                {feedback.message}
              </p>
            ) : null}
          </div>

          <div className="rewardBrandingField">
            <span>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                <circle cx="9" cy="9" r="2" />
                <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
              </svg>
              <strong>Page background</strong>
            </span>
            <span className="fa-field fa-field-unlabeled">
              <span className="fa-field-frame">
                <input
                  className="fa-field-input"
                  value={settings.backgroundImageUrl}
                  placeholder="https://…/background.webp"
                  onChange={(event) => set("backgroundImageUrl", event.target.value)}
                />
                <span className="fa-field-charge" aria-hidden="true" />
              </span>
            </span>
            <div className="rewardBrandingAssetActions">
              <input
                ref={backgroundInputRef}
                type="file"
                accept="image/gif,image/jpeg,image/png,image/webp"
                onChange={(event) => onFilePicked("background", event)}
              />
              <button
                type="button"
                className={`flow-btn flow-btn-secondary flow-btn-md${busy === "background" ? " flow-btn-loading" : ""}`}
                onClick={() => openPicker(backgroundInputRef)}
                disabled={busy !== ""}
              >
                <span className="flow-btn-sweep" aria-hidden="true" />
                <span className="flow-btn-content">
                  {busy === "background" ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flow-btn-spinner" aria-hidden="true">
                      <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                    </svg>
                  ) : (
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21" />
                      <path d="m14 19.5 3-3 3 3" />
                      <path d="M17 22v-5.5" />
                      <circle cx="9" cy="9" r="2" />
                    </svg>
                  )}
                  <span className="flow-btn-label">Upload background</span>
                </span>
              </button>
              {hasBackground ? (
                <button
                  type="button"
                  className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm"
                  onClick={() => void removeAsset("background")}
                  disabled={busy !== ""}
                  aria-label="Use the default ASCII background"
                  title="Use default background"
                >
                  <span className="flow-icon-btn-inner">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d="M10 11v6" />
                      <path d="M14 11v6" />
                      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                      <path d="M3 6h18" />
                      <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                    </svg>
                  </span>
                </button>
              ) : null}
            </div>
            {feedback.kind === "background" && feedback.message ? (
              <p
                className={`reward-settings-module__po3UEW__assetFeedback reward-settings-module__po3UEW__${feedback.tone}`}
                role={feedback.tone === "error" ? "alert" : "status"}
              >
                {feedback.message}
              </p>
            ) : null}
          </div>

          <label className="rewardBrandingField rewardBrandingColorField">
            <span>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z" />
                <circle cx="13.5" cy="6.5" r=".5" fill="currentColor" />
                <circle cx="17.5" cy="10.5" r=".5" fill="currentColor" />
                <circle cx="6.5" cy="12.5" r=".5" fill="currentColor" />
                <circle cx="8.5" cy="7.5" r=".5" fill="currentColor" />
              </svg>
              <strong>Accent color</strong>
            </span>
            <div className="rewardBrandingColorControl">
              <input
                type="color"
                value={settings.accentColor || "#7c5cff"}
                onChange={(event) => set("accentColor", event.target.value)}
                aria-label="Reward gateway accent color"
              />
              <span className="fa-field fa-field-unlabeled">
                <span className="fa-field-frame">
                  <input
                    className="fa-field-input"
                    value={settings.accentColor}
                    placeholder="#7c5cff"
                    maxLength={7}
                    onChange={(event) => set("accentColor", event.target.value)}
                  />
                  <span className="fa-field-charge" aria-hidden="true" />
                </span>
              </span>
            </div>
          </label>

          <label className="rewardBrandingField rewardBrandingDimField">
            <span>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                <circle cx="9" cy="9" r="2" />
                <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
              </svg>
              <strong>Background shade</strong>
              <small>{dim}%</small>
            </span>
            <input
              type="range"
              min="20"
              max="88"
              step="1"
              value={dim}
              onChange={(event) => set("backgroundDim", Number(clamp(event.target.value, 20, 88)))}
            />
          </label>
        </div>
        <p className="rewardBrandingMessage">
          GIF, PNG, JPG, or WebP. Static backgrounds auto-upscale up to 4× (max 4K); GIF animation stays untouched.
        </p>
      </section>

      <div className="rewardSettingsHead">
        <h3>Rules</h3>
        <p>Set key limits and basic abuse checks for reward visitors.</p>
      </div>
      <div className="rewardSettingsGrid">
        {NUMERIC_RULES.map((rule) => (
          <div key={rule.key} className="rewardSettingItem">
            <div className="rewardSettingLabel">
              {rule.key === "maxKeys" ? (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z" />
                  <circle cx="16.5" cy="7.5" r=".5" fill="currentColor" />
                </svg>
              ) : (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 6v6l4 2" />
                </svg>
              )}
              <div>
                <strong>{rule.title}</strong>
                <span>{rule.help}</span>
              </div>
            </div>
            <span className="fa-field fa-field-unlabeled rewardNumInput">
              <span className="fa-field-frame">
                <input
                  className="fa-field-input"
                  type="number"
                  min={rule.min}
                  max={rule.max}
                  step={rule.step}
                  value={settings[rule.key] as number}
                  onChange={(event) => set(rule.key, clamp(event.target.value, rule.min, rule.max) as never)}
                  onBlur={(event) => {
                    if (event.target.value === "") set(rule.key, rule.min);
                  }}
                />
                <span className="fa-field-charge" aria-hidden="true" />
              </span>
            </span>
          </div>
        ))}

        {TOGGLE_RULES.map((rule) => (
          <div key={rule.key} className="rewardSettingItem">
            <div className="rewardSettingLabel">
              {rule.key === "allowExtending" ? (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="m17 2 4 4-4 4" />
                  <path d="M3 11v-1a4 4 0 0 1 4-4h14" />
                  <path d="m7 22-4-4 4-4" />
                  <path d="M21 13v1a4 4 0 0 1-4 4H3" />
                </svg>
              ) : rule.key === "autoBlacklist" ? (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M4.929 4.929 19.07 19.071" />
                </svg>
              ) : (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="m18.84 12.25 1.72-1.71h-.02a5.004 5.004 0 0 0-.12-7.07 5.006 5.006 0 0 0-6.95 0l-1.72 1.71" />
                  <path d="m5.17 11.75-1.71 1.71a5.004 5.004 0 0 0 .12 7.07 5.006 5.006 0 0 0 6.95 0l1.71-1.71" />
                  <line x1="8" x2="8" y1="2" y2="5" />
                  <line x1="2" x2="5" y1="8" y2="8" />
                  <line x1="16" x2="16" y1="19" y2="22" />
                  <line x1="19" x2="22" y1="16" y2="16" />
                </svg>
              )}
              <div>
                <strong>
                  {rule.title}
                  {rule.warn ? <em className="rewardWarn"> - use carefully</em> : null}
                </strong>
                <span>{rule.help}</span>
              </div>
            </div>
            <FaToggle
              id={`reward-${rule.key}`}
              label={rule.title}
              checked={Boolean(settings[rule.key])}
              onChange={(next) => set(rule.key, next as never)}
            />
          </div>
        ))}
      </div>

      <div className="rewardCountryBlock">
        <div className="rewardSettingLabel">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M21.54 15H17a2 2 0 0 0-2 2v4.54" />
            <path d="M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17" />
            <path d="M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05" />
            <circle cx="12" cy="12" r="10" />
          </svg>
          <div>
            <strong>Country blocks</strong>
            <span>Two-letter country codes, like US or BR.</span>
          </div>
        </div>
        <div className="rewardCountryTags">
          {(settings.blockedCountries || []).map((code) => (
            <span key={code} className="rewardCountryTag">
              {code}
              <button
                type="button"
                className="flow-icon-btn flow-icon-btn-ghost flow-icon-btn-sm"
                onClick={() => set("blockedCountries", (settings.blockedCountries || []).filter((item) => item !== code))}
                aria-label={`Remove ${code}`}
              >
                <span className="flow-icon-btn-inner">×</span>
              </button>
            </span>
          ))}
          <span className="fa-field fa-field-unlabeled rewardCountryInput">
            <span className="fa-field-frame">
              <input
                className="fa-field-input"
                placeholder={settings.blockedCountries?.length ? "Add code..." : "US, BR..."}
                value={countryDraft}
                onChange={(event) => setCountryDraft(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === ",") {
                    event.preventDefault();
                    commitCountries();
                  }
                }}
                onBlur={commitCountries}
              />
              <span className="fa-field-charge" aria-hidden="true" />
            </span>
          </span>
        </div>
      </div>

      <div className="rewardSettingsActions">
        <button
          type="button"
          className={`flow-btn flow-btn-secondary flow-btn-md rewardSettingsSave${saving ? " flow-btn-loading" : ""}`}
          onClick={save}
          disabled={saving}
        >
          <span className="flow-btn-sweep" aria-hidden="true" />
          <span className="flow-btn-content">
            {saving ? (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="flow-btn-spinner" aria-hidden="true">
                <path d="M21 12a9 9 0 1 1-6.219-8.56" />
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" />
                <path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7" />
                <path d="M7 3v4a1 1 0 0 0 1 1h7" />
              </svg>
            )}
            <span className="flow-btn-label">Save reward settings</span>
          </span>
        </button>
      </div>
    </div>
  );
}
